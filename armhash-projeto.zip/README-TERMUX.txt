ARMHash — Como rodar no Termux (Android) ou em hospedagem Node.js

1) No Termux (Android):
   pkg update -y && pkg install -y nodejs-lts termux-api
   npm install
   npm run build
   termux-wake-lock
   NODE_ENV=production npx tsx server.ts
   Depois abra http://localhost:3000 no Chrome e toque em Menu -> Instalar aplicativo.

2) Render / Koyeb / Cloud Run:
   Build: npm install && npm run build
   Start: npm start (com NODE_ENV=production; PORT e lida automaticamente)
