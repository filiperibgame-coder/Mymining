// Hand-assembled WebAssembly MVP module for Yespower 1.0 smix (N, r, Salsa20/2, pwxformV1).
// Uses native WASM 64-bit integer arithmetic (i64.mul / i64.add / i64.xor) and i32.rotl
// for major speedups on ARM64 and x86_64 devices with zero external build tools.

const PTR_B = 0x0000;       // 4096 bytes (max r = 32)
const PTR_X = 0x1000;       // 4096 bytes
const PTR_SALSA_X = 0x2000; // 64 bytes
const PTR_SALSA_B = 0x2040; // 64 bytes
const PTR_PWX = 0x2080;     // 64 bytes
const PTR_S = 0x4000;       // 98304 bytes (3 * 32768)
const PTR_V = 0x20000;      // 8,388,608 bytes (N = 2048, r = 32)
const INITIAL_PAGES = 140;  // 140 * 65536 = 9,175,040 bytes
const MIN_PAGES = 132;      // 132 * 65536 = 8,650,752 bytes (minimum for N=2048, r=32)

function uleb(n: number): number[] {
  const out: number[] = [];
  let v = n >>> 0;
  do {
    let b = v & 0x7f;
    v >>>= 7;
    if (v !== 0) b |= 0x80;
    out.push(b);
  } while (v !== 0);
  return out;
}

function sleb(n: number): number[] {
  const out: number[] = [];
  let v = n | 0;
  let more = true;
  while (more) {
    let b = v & 0x7f;
    v >>= 7;
    if ((v === 0 && (b & 0x40) === 0) || (v === -1 && (b & 0x40) !== 0)) {
      more = false;
    } else {
      b |= 0x80;
    }
    out.push(b);
  }
  return out;
}

function sleb64(n: bigint): number[] {
  const out: number[] = [];
  let v = n;
  let more = true;
  while (more) {
    let b = Number(v & 0x7fn);
    v >>= 7n;
    if ((v === 0n && (b & 0x40) === 0) || (v === -1n && (b & 0x40) !== 0)) {
      more = false;
    } else {
      b |= 0x80;
    }
    out.push(b);
  }
  return out;
}

function strBytes(s: string): number[] {
  const arr = new TextEncoder().encode(s);
  return [...uleb(arr.length), ...arr];
}

function section(id: number, body: number[]): number[] {
  return [id, ...uleb(body.length), ...body];
}

// WASM opcodes
const OP = {
  unreachable: 0x00,
  block: 0x02,
  loop: 0x03,
  if_: 0x04,
  else_: 0x05,
  end: 0x0b,
  br: 0x0c,
  br_if: 0x0d,
  call: 0x10,
  local_get: 0x20,
  local_set: 0x21,
  local_tee: 0x22,
  global_get: 0x23,
  global_set: 0x24,
  i32_load: 0x28,
  i64_load: 0x29,
  i32_store: 0x36,
  i64_store: 0x37,
  i32_const: 0x41,
  i64_const: 0x42,
  i32_eqz: 0x45,
  i32_eq: 0x46,
  i32_ne: 0x47,
  i32_lt_u: 0x49,
  i32_gt_u: 0x4b,
  i32_le_u: 0x4d,
  i32_ge_u: 0x4f,
  i32_add: 0x6a,
  i32_sub: 0x6b,
  i32_mul: 0x6c,
  i32_and: 0x71,
  i32_or: 0x72,
  i32_xor: 0x73,
  i32_shl: 0x74,
  i32_shr_u: 0x76,
  i32_rotl: 0x77,
  i64_add: 0x7c,
  i64_mul: 0x7e,
  i64_and: 0x83,
  i64_or: 0x84,
  i64_xor: 0x85,
  i64_shl: 0x86,
  i64_shr_u: 0x88,
  i32_wrap_i64: 0xa7,
  i64_extend_i32_u: 0xad,
} as const;

const VOID = 0x40;
const I32 = 0x7f;
const I64 = 0x7e;

const i32c = (n: number) => [OP.i32_const, ...sleb(n)];
const i64c = (n: bigint) => [OP.i64_const, ...sleb64(n)];
const lget = (i: number) => [OP.local_get, ...uleb(i)];
const lset = (i: number) => [OP.local_set, ...uleb(i)];
const ltee = (i: number) => [OP.local_tee, ...uleb(i)];
const gget = (i: number) => [OP.global_get, ...uleb(i)];
const gset = (i: number) => [OP.global_set, ...uleb(i)];
const ld32 = (off = 0) => [OP.i32_load, 2, ...uleb(off)];
const st32 = (off = 0) => [OP.i32_store, 2, ...uleb(off)];
const ld64 = (off = 0) => [OP.i64_load, 3, ...uleb(off)];
const st64 = (off = 0) => [OP.i64_store, 3, ...uleb(off)];

function buildYespowerV1WasmBytes(): Uint8Array {
  // Globals:
  // 0: sOff0 (byte offset inside PTR_S)
  // 1: sOff1
  // 2: sOff2
  // 3: pwxW (byte offset inside sOff0/sOff1)
  // 4: sMask (0x7ff0)
  // 5: sWrapMask (0x7ff8)

  // Functions:
  // 0: salsa20(bPtr: i32, rounds: i32) -> void
  // 1: blockmixSalsa(bPtr: i32, rounds: i32) -> void
  // 2: pwxformV1(bPtr: i32) -> void
  // 3: blockmixPwxform(bPtr: i32, r: i32) -> void
  // 4: smix1(r: i32, N: i32, vPtr: i32, isSInit: i32) -> void
  // 5: smix2(r: i32, N: i32, Nloop: i32, vPtr: i32) -> void
  // 6: smixAll(N: i32, r: i32, nLoopRw: i32, nLoopRo: i32, sN: i32) -> void

  // Types:
  // 0: (i32, i32) -> void
  // 1: (i32) -> void
  // 2: (i32, i32, i32, i32) -> void
  // 3: (i32, i32, i32, i32, i32) -> void
  const typeSec = section(1, [
    ...uleb(4),
    0x60, 2, I32, I32, 0,
    0x60, 1, I32, 0,
    0x60, 4, I32, I32, I32, I32, 0,
    0x60, 5, I32, I32, I32, I32, I32, 0,
  ]);

  // Import env.memory (shared JS-allocated WebAssembly.Memory)
  const importSec = section(2, [
    ...uleb(1),
    ...strBytes('env'),
    ...strBytes('memory'),
    0x02, // mem
    0x00, // min only
    ...uleb(MIN_PAGES),
  ]);

  const funcSec = section(3, [...uleb(7), 0, 0, 1, 0, 2, 2, 3]);

  const globalSec = section(6, [
    ...uleb(6),
    I32, 1, ...i32c(0), OP.end,
    I32, 1, ...i32c(32768), OP.end,
    I32, 1, ...i32c(65536), OP.end,
    I32, 1, ...i32c(0), OP.end,
    I32, 1, ...i32c(0x7ff0), OP.end,
    I32, 1, ...i32c(0x7ff8), OP.end,
  ]);

  const exportSec = section(7, [
    ...uleb(1),
    ...strBytes('smixAll'),
    0x00,
    ...uleb(6),
  ]);

  // --- Func 0: salsa20(bPtr: 0, rounds: 1) ---
  // Locals 2..17: x0..x15, 18: i, 19: t
  const f0: number[] = [
    ...uleb(1),
    ...uleb(18), I32,
  ];
  for (let i = 0; i < 16; i++) {
    const xi = 2 + ((i * 5) & 15);
    f0.push(...lget(0), ...ld32(i * 4), ...lset(xi));
  }
  const qr = (a: number, b: number, c: number, d: number) => {
    const la = 2 + a, lb = 2 + b, lc = 2 + c, ld = 2 + d;
    return [
      ...lget(la), ...lget(ld), OP.i32_add, i32c(7)[0], i32c(7)[1], OP.i32_rotl, ...lget(lb), OP.i32_xor, ...lset(lb),
      ...lget(lb), ...lget(la), OP.i32_add, ...i32c(9), OP.i32_rotl, ...lget(lc), OP.i32_xor, ...lset(lc),
      ...lget(lc), ...lget(lb), OP.i32_add, ...i32c(13), OP.i32_rotl, ...lget(ld), OP.i32_xor, ...lset(ld),
      ...lget(ld), ...lget(lc), OP.i32_add, ...i32c(18), OP.i32_rotl, ...lget(la), OP.i32_xor, ...lset(la),
    ];
  };
  f0.push(
    ...i32c(0), ...lset(18),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(18), ...lget(1), OP.i32_ge_u, OP.br_if, 1,
    ...qr(0, 4, 8, 12),
    ...qr(5, 9, 13, 1),
    ...qr(10, 14, 2, 6),
    ...qr(15, 3, 7, 11),
    ...qr(0, 1, 2, 3),
    ...qr(5, 6, 7, 4),
    ...qr(10, 11, 8, 9),
    ...qr(15, 12, 13, 14),
    ...lget(18), ...i32c(2), OP.i32_add, ...lset(18),
    OP.br, 0,
    OP.end,
    OP.end,
  );
  for (let i = 0; i < 16; i++) {
    const xi = 2 + ((i * 5) & 15);
    f0.push(...lget(0), ...lget(0), ...ld32(i * 4), ...lget(xi), OP.i32_add, ...st32(i * 4));
  }
  f0.push(OP.end);

  // --- Func 1: blockmixSalsa(bPtr: 0, rounds: 1) ---
  // Locals: 2: k, 3: i, 4: off
  const f1: number[] = [
    ...uleb(1),
    ...uleb(3), I32,
  ];
  // X (PTR_SALSA_B) = B[64..128]
  for (let w = 0; w < 8; w++) {
    f1.push(...i32c(PTR_SALSA_B), ...lget(0), ...ld64(64 + w * 8), ...st64(w * 8));
  }
  for (let i = 0; i < 2; i++) {
    const off = i * 64;
    for (let w = 0; w < 8; w++) {
      f1.push(
        ...i32c(PTR_SALSA_B),
        ...i32c(PTR_SALSA_B), ...ld64(w * 8),
        ...lget(0), ...ld64(off + w * 8),
        OP.i64_xor,
        ...st64(w * 8)
      );
    }
    f1.push(...i32c(PTR_SALSA_B), ...lget(1), OP.call, 0);
    for (let w = 0; w < 8; w++) {
      f1.push(...lget(0), ...i32c(PTR_SALSA_B), ...ld64(w * 8), ...st64(off + w * 8));
    }
  }
  f1.push(OP.end);

  // --- Func 2: pwxformV1(bPtr: 0) ---
  // Locals:
  // i32: 1=sOff0, 2=sOff1, 3=sMask, 4=w, 5=i, 6=s0Ptr, 7=s1Ptr
  // i64: 8..15=x0..x7 (8 x i64 = 16 x u32!), 16=xl, 17=xh, 18=prod, 19=tmp64
  const f2: number[] = [
    ...uleb(2),
    ...uleb(7), I32,
    ...uleb(12), I64,
    ...gget(0), ...i32c(PTR_S), OP.i32_add, ...lset(1),
    ...gget(1), ...i32c(PTR_S), OP.i32_add, ...lset(2),
    ...gget(4), ...lset(3),
    ...gget(3), ...lset(4),
  ];
  // Load B[0..63] as 8 i64s into locals 8..15
  for (let w = 0; w < 8; w++) {
    f2.push(...lget(0), ...ld64(w * 8), ...lset(8 + w));
  }

  const pwxStep = (j: number, doWrite: boolean) => {
    const xBase = 8 + j * 2;
    const out: number[] = [
      // p0Byte = i32_wrap(xBase) & sMask; s0Ptr = sOff0 + p0Byte
      ...lget(xBase), OP.i32_wrap_i64, ...lget(3), OP.i32_and, ...lget(1), OP.i32_add, ...lset(6),
      // p1Byte = i32_wrap(xBase >> 32) & sMask; s1Ptr = sOff1 + p1Byte
      ...lget(xBase), ...i64c(32n), OP.i64_shr_u, OP.i32_wrap_i64, ...lget(3), OP.i32_and, ...lget(2), OP.i32_add, ...lset(7),
    ];
    for (let k = 0; k < 2; k++) {
      const xk = xBase + k;
      const sOff = k * 8;
      out.push(
        ...lget(xk), ...i64c(0xffffffffn), OP.i64_and,
        ...lget(xk), ...i64c(32n), OP.i64_shr_u,
        OP.i64_mul,
        ...lget(6), ...ld64(sOff),
        OP.i64_add,
        ...lget(7), ...ld64(sOff),
        OP.i64_xor,
        ...lset(xk)
      );
    }
    if (doWrite) {
      if ((j & 1) === 0) {
        out.push(
          ...lget(1), ...lget(4), OP.i32_add, ...lget(xBase), ...st64(0),
          ...lget(1), ...lget(4), OP.i32_add, ...lget(xBase + 1), ...st64(8)
        );
      } else {
        out.push(
          ...lget(2), ...lget(4), OP.i32_add, ...lget(xBase), ...st64(0),
          ...lget(2), ...lget(4), OP.i32_add, ...lget(xBase + 1), ...st64(8),
          ...lget(4), ...i32c(16), OP.i32_add, ...lset(4)
        );
      }
    }
    return out;
  };

  // Unrolled 3 rounds (i = 0, 1, 2): i=0 writes all 4, i=1..2 write only j=0,1
  f2.push(
    ...pwxStep(0, true),
    ...pwxStep(1, true),
    ...pwxStep(2, true),
    ...pwxStep(3, true),
    ...pwxStep(0, true),
    ...pwxStep(1, true),
    ...pwxStep(2, false),
    ...pwxStep(3, false),
    ...pwxStep(0, true),
    ...pwxStep(1, true),
    ...pwxStep(2, false),
    ...pwxStep(3, false)
  );

  for (let w = 0; w < 8; w++) {
    f2.push(...lget(0), ...lget(8 + w), ...st64(w * 8));
  }
  // Rotate sOff0/sOff1/sOff2 and wrap pwxW
  f2.push(
    ...gget(0), // save old sOff0 on stack
    ...gget(2), ...gset(0), // sOff0 = sOff2
    ...gget(1), ...gset(2), // sOff2 = sOff1
    ...gset(1),             // sOff1 = old sOff0
    ...lget(4), ...gget(5), OP.i32_and, ...gset(3),
    OP.end
  );

  // --- Func 3: blockmixPwxform(bPtr: 0, r: 1) ---
  // Locals: 2: r1, 3: i, 4: curOff, 5: k, 6: r2
  const f3: number[] = [
    ...uleb(1),
    ...uleb(5), I32,
    // r1 = 2 * r (since 128 * r / 64 = 2 * r)
    ...lget(1), ...i32c(1), OP.i32_shl, ...ltee(2),
    // curOff = bPtr + (r1 - 1) * 64
    ...i32c(1), OP.i32_sub, ...i32c(6), OP.i32_shl, ...lget(0), OP.i32_add, ...lset(4),
  ];
  // X (PTR_PWX) = B[lastOff]
  for (let w = 0; w < 8; w++) {
    f3.push(...i32c(PTR_PWX), ...lget(4), ...ld64(w * 8), ...st64(w * 8));
  }
  // for i = 0..r1-1
  f3.push(
    ...i32c(0), ...lset(3),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(3), ...lget(2), OP.i32_ge_u, OP.br_if, 1,
    ...lget(0), ...lget(3), ...i32c(6), OP.i32_shl, OP.i32_add, ...lset(4),
    ...lget(2), ...i32c(1), OP.i32_gt_u,
    OP.if_, VOID,
    ...(() => {
      const xs: number[] = [];
      for (let w = 0; w < 8; w++) {
        xs.push(
          ...i32c(PTR_PWX),
          ...i32c(PTR_PWX), ...ld64(w * 8),
          ...lget(4), ...ld64(w * 8),
          OP.i64_xor,
          ...st64(w * 8)
        );
      }
      return xs;
    })(),
    OP.end,
    ...i32c(PTR_PWX), OP.call, 2, // pwxformV1(PTR_PWX)
    ...(() => {
      const ws: number[] = [];
      for (let w = 0; w < 8; w++) {
        ws.push(...lget(4), ...i32c(PTR_PWX), ...ld64(w * 8), ...st64(w * 8));
      }
      return ws;
    })(),
    ...lget(3), ...i32c(1), OP.i32_add, ...lset(3),
    OP.br, 0,
    OP.end,
    OP.end,
    // i = r1 - 1; salsa20(bPtr + i * 64, 2)
    ...lget(2), ...i32c(1), OP.i32_sub, ...ltee(3),
    ...i32c(6), OP.i32_shl, ...lget(0), OP.i32_add, ...i32c(2), OP.call, 0,
    // r2 = 2 * r; for (i++; i < r2; i++)
    ...lget(2), ...lset(6),
    ...lget(3), ...i32c(1), OP.i32_add, ...lset(3),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(3), ...lget(6), OP.i32_ge_u, OP.br_if, 1,
    ...lget(0), ...lget(3), ...i32c(6), OP.i32_shl, OP.i32_add, ...lset(4),
    ...(() => {
      const xs: number[] = [];
      for (let w = 0; w < 8; w++) {
        xs.push(
          ...lget(4),
          ...lget(4), ...ld64(w * 8),
          ...lget(4), ...i32c(64), OP.i32_sub, ...ld64(w * 8),
          OP.i64_xor,
          ...st64(w * 8)
        );
      }
      return xs;
    })(),
    ...lget(4), ...i32c(2), OP.call, 0,
    ...lget(3), ...i32c(1), OP.i32_add, ...lset(3),
    OP.br, 0,
    OP.end,
    OP.end,
    OP.end
  );

  // Helper to copy `bytes` (multiple of 64) from srcPtr to dstPtr using 64-byte unrolled loop
  const copyLoop = (srcLocal: number, dstLocal: number, sBytesLocal: number, idxLocal: number) => {
    const ops: number[] = [
      ...i32c(0), ...lset(idxLocal),
      OP.block, VOID,
      OP.loop, VOID,
      ...lget(idxLocal), ...lget(sBytesLocal), OP.i32_ge_u, OP.br_if, 1,
    ];
    for (let w = 0; w < 8; w++) {
      ops.push(
        ...lget(dstLocal), ...lget(idxLocal), OP.i32_add,
        ...lget(srcLocal), ...lget(idxLocal), OP.i32_add, ...ld64(w * 8),
        ...st64(w * 8)
      );
    }
    ops.push(
      ...lget(idxLocal), ...i32c(64), OP.i32_add, ...lset(idxLocal),
      OP.br, 0,
      OP.end,
      OP.end
    );
    return ops;
  };
  const xorLoop = (dstLocal: number, srcLocal: number, sBytesLocal: number, idxLocal: number) => {
    const ops: number[] = [
      ...i32c(0), ...lset(idxLocal),
      OP.block, VOID,
      OP.loop, VOID,
      ...lget(idxLocal), ...lget(sBytesLocal), OP.i32_ge_u, OP.br_if, 1,
    ];
    for (let w = 0; w < 8; w++) {
      ops.push(
        ...lget(dstLocal), ...lget(idxLocal), OP.i32_add,
        ...lget(dstLocal), ...lget(idxLocal), OP.i32_add, ...ld64(w * 8),
        ...lget(srcLocal), ...lget(idxLocal), OP.i32_add, ...ld64(w * 8),
        OP.i64_xor,
        ...st64(w * 8)
      );
    }
    ops.push(
      ...lget(idxLocal), ...i32c(64), OP.i32_add, ...lset(idxLocal),
      OP.br, 0,
      OP.end,
      OP.end
    );
    return ops;
  };

  // --- Func 4: smix1(r: 0, N: 1, vPtr: 2, isSInit: 3) ---
  // Locals:
  // 4: sBytes (128 * r), 5: k, 6: i, 7: intByteOff ((2*r-1)*64), 8: dstPtr, 9: srcPtr, 10: j, 11: nTmp, 12: yTmp, 13: xVal, 14: r2 (2*r)
  const f4: number[] = [
    ...uleb(1),
    ...uleb(11), I32,
    ...lget(0), ...i32c(7), OP.i32_shl, ...lset(4),          // sBytes = 128 * r
    ...lget(0), ...i32c(1), OP.i32_shl, ...ltee(14),         // r2 = 2 * r
    ...i32c(1), OP.i32_sub, ...i32c(6), OP.i32_shl, ...lset(7), // intByteOff = (2*r - 1) * 64

    // Permute B -> X: for k=0..2*r-1, for i=0..15: X[k*64 + i*4] = B[k*64 + ((i*5)&15)*4]
    ...i32c(0), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(14), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(6), OP.i32_shl, ...lset(9), // srcBase = k*64
    ...lget(9), ...i32c(PTR_X), OP.i32_add, ...lset(8),
    ...(() => {
      const ps: number[] = [];
      for (let i = 0; i < 16; i++) {
        const bOff = ((i * 5) & 15) * 4;
        ps.push(...lget(8), ...lget(9), ...ld32(bOff), ...st32(i * 4));
      }
      return ps;
    })(),
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,

    // Version 10 initial r expansion: for k=1..r-1: X[k*128 ..] = X[(k-1)*128..]; blockmixPwxform(X + k*128, 1)
    ...i32c(1), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(0), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(7), OP.i32_shl, ...i32c(PTR_X), OP.i32_add, ...ltee(8),
    ...i32c(128), OP.i32_sub, ...lset(9),
    ...i32c(128), ...lset(10), // 128 bytes
    ...copyLoop(9, 8, 10, 6),
    ...lget(8), ...i32c(1), OP.call, 3,
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,

    // Main N loop: for i = 0..N-1
    ...i32c(0), ...lset(6),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(6), ...lget(1), OP.i32_ge_u, OP.br_if, 1,
    // V[i * sBytes] = X
    ...i32c(PTR_X), ...lset(9),
    ...lget(2), ...lget(6), ...lget(4), OP.i32_mul, OP.i32_add, ...lset(8),
    ...copyLoop(9, 8, 4, 5),

    // if (i > 1)
    ...lget(6), ...i32c(1), OP.i32_gt_u,
    OP.if_, VOID,
    // j = wrap(X[intByteOff], i)
    ...lget(6), ...lset(11),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(11), ...lget(11), ...i32c(1), OP.i32_sub, OP.i32_and, ...ltee(12),
    OP.i32_eqz, OP.br_if, 1,
    ...lget(12), ...lset(11),
    OP.br, 0,
    OP.end,
    OP.end,
    // j = (X[intByteOff] & (nTmp - 1)) + (i - nTmp)
    ...lget(7), ...i32c(PTR_X), OP.i32_add, ...ld32(0),
    ...lget(11), ...i32c(1), OP.i32_sub, OP.i32_and,
    ...lget(6), ...lget(11), OP.i32_sub, OP.i32_add,
    // srcPtr = vPtr + j * sBytes
    ...lget(4), OP.i32_mul, ...lget(2), OP.i32_add, ...lset(9),
    ...i32c(PTR_X), ...lset(8),
    ...xorLoop(8, 9, 4, 5),
    OP.end,

    // if (!isSInit) blockmixPwxform(PTR_X, r) else blockmixSalsa(PTR_X, 2)
    ...lget(3), OP.i32_eqz,
    OP.if_, VOID,
    ...i32c(PTR_X), ...lget(0), OP.call, 3,
    OP.else_,
    ...i32c(PTR_X), ...i32c(2), OP.call, 1,
    OP.end,

    ...lget(6), ...i32c(1), OP.i32_add, ...lset(6),
    OP.br, 0,
    OP.end,
    OP.end,

    // Unpermute X -> B
    ...i32c(0), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(14), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(6), OP.i32_shl, ...ltee(8),
    ...i32c(PTR_X), OP.i32_add, ...lset(9),
    ...(() => {
      const ps: number[] = [];
      for (let i = 0; i < 16; i++) {
        const bOff = ((i * 5) & 15) * 4;
        ps.push(...lget(8), ...lget(9), ...ld32(i * 4), ...st32(bOff));
      }
      return ps;
    })(),
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,
    OP.end,
  ];

  // --- Func 5: smix2(r: 0, N: 1, Nloop: 2, vPtr: 3) ---
  // Locals: 4: sBytes, 5: k, 6: i, 7: intByteOff, 8: dstPtr, 9: srcPtr, 10: nMask, 11: r2, 12: writeBack
  const f5: number[] = [
    ...uleb(1),
    ...uleb(9), I32,
    ...lget(0), ...i32c(7), OP.i32_shl, ...lset(4),
    ...lget(0), ...i32c(1), OP.i32_shl, ...ltee(11),
    ...i32c(1), OP.i32_sub, ...i32c(6), OP.i32_shl, ...lset(7),
    ...lget(1), ...i32c(1), OP.i32_sub, ...lset(10),
    ...lget(2), ...i32c(2), OP.i32_ne, ...lset(12),

    // Permute B -> X
    ...i32c(0), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(11), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(6), OP.i32_shl, ...lset(9),
    ...lget(9), ...i32c(PTR_X), OP.i32_add, ...lset(8),
    ...(() => {
      const ps: number[] = [];
      for (let i = 0; i < 16; i++) {
        const bOff = ((i * 5) & 15) * 4;
        ps.push(...lget(8), ...lget(9), ...ld32(bOff), ...st32(i * 4));
      }
      return ps;
    })(),
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,

    // for i = 0..Nloop-1
    ...i32c(0), ...lset(6),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(6), ...lget(2), OP.i32_ge_u, OP.br_if, 1,
    // j = X[intByteOff] & nMask; srcPtr = vPtr + j * sBytes
    ...lget(7), ...i32c(PTR_X), OP.i32_add, ...ld32(0), ...lget(10), OP.i32_and,
    ...lget(4), OP.i32_mul, ...lget(3), OP.i32_add, ...lset(9),
    ...i32c(PTR_X), ...lset(8),
    ...xorLoop(8, 9, 4, 5),
    ...lget(12),
    OP.if_, VOID,
    ...copyLoop(8, 9, 4, 5),
    OP.end,
    ...i32c(PTR_X), ...lget(0), OP.call, 3,
    ...lget(6), ...i32c(1), OP.i32_add, ...lset(6),
    OP.br, 0,
    OP.end,
    OP.end,

    // Unpermute X -> B
    ...i32c(0), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(11), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(6), OP.i32_shl, ...ltee(8),
    ...i32c(PTR_X), OP.i32_add, ...lset(9),
    ...(() => {
      const ps: number[] = [];
      for (let i = 0; i < 16; i++) {
        const bOff = ((i * 5) & 15) * 4;
        ps.push(...lget(8), ...lget(9), ...ld32(i * 4), ...st32(bOff));
      }
      return ps;
    })(),
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,
    OP.end,
  ];

  // --- Func 6: smixAll(N: 0, r: 1, nLoopRw: 2, nLoopRo: 3, sN: 4) ---
  const f6: number[] = [
    ...uleb(0),
    // Reset pwx state globals
    ...i32c(0), ...gset(0),
    ...i32c(32768), ...gset(1),
    ...i32c(65536), ...gset(2),
    ...i32c(0), ...gset(3),
    // smix1(1, sN, PTR_S, 1)
    ...i32c(1), ...lget(4), ...i32c(PTR_S), ...i32c(1), OP.call, 4,
    // smix1(r, N, PTR_V, 0)
    ...lget(1), ...lget(0), ...i32c(PTR_V), ...i32c(0), OP.call, 4,
    // smix2(r, N, nLoopRw, PTR_V)
    ...lget(1), ...lget(0), ...lget(2), ...i32c(PTR_V), OP.call, 5,
    // smix2(r, N, nLoopRo, PTR_V)
    ...lget(1), ...lget(0), ...lget(3), ...i32c(PTR_V), OP.call, 5,
    OP.end,
  ];

  const bodies = [f0, f1, f2, f3, f4, f5, f6];
  const codeBody: number[] = [...uleb(bodies.length)];
  for (const b of bodies) {
    codeBody.push(...uleb(b.length), ...b);
  }
  const codeSec = section(10, codeBody);

  return new Uint8Array([
    0x00, 0x61, 0x73, 0x6d, // \0asm
    0x01, 0x00, 0x00, 0x00, // version 1
    ...typeSec,
    ...importSec,
    ...funcSec,
    ...globalSec,
    ...exportSec,
    ...codeSec,
  ]);
}

let cachedModule: WebAssembly.Module | null = null;

export interface YespowerWasmSmix {
  memU8: Uint8Array;
  smixAll: (N: number, r: number, nLoopRw: number, nLoopRo: number, sN: number) => void;
}

export function createYespowerV1Wasm(targetPages = INITIAL_PAGES): YespowerWasmSmix | null {
  try {
    if (typeof WebAssembly === 'undefined') return null;
    if (!cachedModule) {
      const bytes = buildYespowerV1WasmBytes();
      cachedModule = new WebAssembly.Module(bytes as unknown as BufferSource);
    }
    const desired = Math.max(MIN_PAGES, Math.round(targetPages));
    const candidates = [desired, MIN_PAGES].filter(
      (p, idx, arr) => p <= desired && arr.indexOf(p) === idx
    );
    for (const pages of candidates) {
      try {
        const memory = new WebAssembly.Memory({ initial: pages });
        const instance = new WebAssembly.Instance(cachedModule, { env: { memory } });
        const smixAll = instance.exports.smixAll as (
          N: number,
          r: number,
          nLoopRw: number,
          nLoopRo: number,
          sN: number
        ) => void;
        return {
          memU8: new Uint8Array(memory.buffer),
          smixAll,
        };
      } catch {
        // Step down on OOM
      }
    }
    return null;
  } catch {
    return null;
  }
}
