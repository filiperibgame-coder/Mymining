import type { MiningAlgorithm } from '../workers/miner.worker';

export interface AlgorithmSpec {
  id: MiningAlgorithm;
  name: string;
  shortName: string;
  cacheUse: string;
  armBenefit: string;
  stratumReady: boolean;
  description: string;
  wattsPerThread: number;
}

export const ALGORITHM_SPECS: Record<MiningAlgorithm, AlgorithmSpec> = {
  yespower_advc: {
    id: 'yespower_advc',
    name: 'Yespower-ADVC (CPU Real → BTC/LTC/DASH/VRSC)',
    shortName: 'Yespower-ADVC',
    cacheUse: '16 MB RAM Cache / thread (WASM SIMD v128)',
    armBenefit: 'Resistente a ASICs; ideal para CPU ARM no celular',
    stratumReady: true,
    description:
      'Implementação exata do Yespower 1.0 (N=2048, r=32) com aceleração WASM SIMD v128 + arena de cache RAM pré-aquecida de 16 MB/thread compatível com Zpool Stratum v1.',
    wattsPerThread: 0.42,
  },
  yespower_sugar: {
    id: 'yespower_sugar',
    name: 'Yespower-SUGAR (Sugarchain CPU Real)',
    shortName: 'Yespower-SUGAR',
    cacheUse: '16 MB RAM Cache / thread (WASM SIMD v128)',
    armBenefit: 'Dificuldade baixa (0.006) · saque mínimo atingido rápido',
    stratumReady: true,
    description:
      'Yespower 1.0 SIMD v128 com personalização Sugarchain para mineração CPU direta na Zpool, atingindo o mínimo de 0.05 SUGAR rapidamente em celulares.',
    wattsPerThread: 0.42,
  },
  yespower_arm: {
    id: 'yespower_arm',
    name: 'Yespower 1.0 Genérico (Stratum v1)',
    shortName: 'Yespower 1.0',
    cacheUse: '16 MB RAM Cache / thread (WASM SIMD v128)',
    armBenefit: 'Alta eficiência H/W contra GPUs e ASICs',
    stratumReady: true,
    description:
      'Yespower 1.0 padrão (N=2048, r=32) SIMD v128 para pools Yespower genéricos (BELL, VECO e nós personalizados).',
    wattsPerThread: 0.42,
  },
  blake3_eco: {
    id: 'blake3_eco',
    name: 'BLAKE3-Eco (Benchmark Local ARX)',
    shortName: 'BLAKE3-Eco',
    cacheUse: '64 B (somente registradores)',
    armBenefit: 'Operações ARX puras sem multiplicações pesadas',
    stratumReady: false,
    description:
      'Modo de benchmark local para medir velocidade pura de registradores ARM64 sem envio ao pool.',
    wattsPerThread: 0.42,
  },
  sha256d: {
    id: 'sha256d',
    name: 'SHA-256d Midstate (Stratum v1 ASIC/Solo)',
    shortName: 'SHA-256d',
    cacheUse: '256 B (Midstate pré-computado)',
    armBenefit: 'Corta pela metade o trabalho por nonce',
    stratumReady: true,
    description:
      'Duplo SHA-256 compatível com pools BTC/unMineable SHA-256 (exige dificuldade alta de ASIC; para shares rápidos no celular, prefira Yespower).',
    wattsPerThread: 0.48,
  },
};

export type PowerProfileId = 'eco' | 'balanced' | 'max';

export const POWER_PROFILES: Record<
  PowerProfileId,
  { id: PowerProfileId; label: string; dutyCycle: number; threadRatio: number; note: string }
> = {
  eco: {
    id: 'eco',
    label: 'Eco / Frio',
    dutyCycle: 65,
    threadRatio: 0.5,
    note: '65% duty-cycle · núcleos de eficiência (não esquenta)',
  },
  balanced: {
    id: 'balanced',
    label: 'Equilibrado',
    dutyCycle: 80,
    threadRatio: 0.75,
    note: '80% duty-cycle · 75% dos núcleos (shares rápidos sem superaquecer)',
  },
  max: {
    id: 'max',
    label: 'Máximo',
    dutyCycle: 95,
    threadRatio: 1,
    note: '95% duty-cycle · todos os núcleos (use no carregador)',
  },
};

export interface ZpoolCoinSpec {
  code: 'BTC' | 'LTC' | 'SUGAR' | 'ADVC' | 'VRSC' | 'DASH' | 'BCH';
  label: string;
  host: string;
  port: string;
  algo: MiningAlgorithm;
  minPayout: string;
  minPayoutNum: number;
  placeholder: string;
  note: string;
}

export const ZPOOL_COINS: ZpoolCoinSpec[] = [
  {
    code: 'LTC',
    label: 'Litecoin (LTC)',
    host: 'yespowerADVC.na.mine.zpool.ca',
    port: '6248',
    algo: 'yespower_advc',
    minPayout: '0.05 LTC',
    minPayoutNum: 0.05,
    placeholder: 'Cole sua carteira LTC (ltc1..., L... ou M...)',
    note: 'Conversão automática na Zpool (saque mínimo 0.05 LTC). Aceita carteiras ltc1..., L... ou M...',
  },
  {
    code: 'BTC',
    label: 'Bitcoin (BTC)',
    host: 'yespowerADVC.na.mine.zpool.ca',
    port: '6248',
    algo: 'yespower_advc',
    minPayout: '0.0015 BTC',
    minPayoutNum: 0.0015,
    placeholder: 'Cole sua carteira BTC (bc1..., 1... ou 3...)',
    note: 'Conversão automática de Yespower para Bitcoin na Zpool (saque mínimo 0.0015 BTC). Aceita bc1..., 1... ou 3...',
  },
  {
    code: 'SUGAR',
    label: 'Sugarchain (SUGAR)',
    host: 'yespowerSUGAR.na.mine.zpool.ca',
    port: '6241',
    algo: 'yespower_sugar',
    minPayout: '0.05 SUGAR',
    minPayoutNum: 0.05,
    placeholder: 'Cole sua carteira SUGAR (sugar1...)',
    note: 'Mineração direta Yespower-SUGAR (saque mínimo 0.05 SUGAR — atinge o saque mais rápido em celulares).',
  },
  {
    code: 'ADVC',
    label: 'AdventureCoin (ADVC)',
    host: 'yespowerADVC.na.mine.zpool.ca',
    port: '6248',
    algo: 'yespower_advc',
    minPayout: '0.05 ADVC',
    minPayoutNum: 0.05,
    placeholder: 'Cole sua carteira ADVC (A... ou advc1...)',
    note: 'Mineração direta Yespower-ADVC sem conversão (saque mínimo 0.05 ADVC).',
  },
  {
    code: 'VRSC',
    label: 'VerusCoin (VRSC)',
    host: 'yespowerADVC.na.mine.zpool.ca',
    port: '6248',
    algo: 'yespower_advc',
    minPayout: '0.05 VRSC',
    minPayoutNum: 0.05,
    placeholder: 'Cole sua carteira VRSC (R...)',
    note: 'Conversão automática na Zpool para VerusCoin (saque mínimo 0.05 VRSC). Carteiras R...',
  },
  {
    code: 'DASH',
    label: 'Dash (DASH)',
    host: 'yespowerADVC.na.mine.zpool.ca',
    port: '6248',
    algo: 'yespower_advc',
    minPayout: '0.05 DASH',
    minPayoutNum: 0.05,
    placeholder: 'Cole sua carteira DASH (X...)',
    note: 'Conversão automática na Zpool (saque mínimo 0.05 DASH). Carteiras iniciando com X...',
  },
  {
    code: 'BCH',
    label: 'Bitcoin Cash (BCH)',
    host: 'yespowerADVC.na.mine.zpool.ca',
    port: '6248',
    algo: 'yespower_advc',
    minPayout: '0.05 BCH',
    minPayoutNum: 0.05,
    placeholder: 'Cole sua carteira BCH (bitcoincash:q... ou q... ou 1...)',
    note: 'Conversão automática na Zpool (saque mínimo 0.05 BCH).',
  },
];

export function validateZpoolWalletAddress(
  coin: string,
  rawAddress: string
): { valid: boolean; clean: string; error?: string } {
  const clean = rawAddress.trim();
  if (!clean) {
    return { valid: false, clean, error: `Informe o endereço da sua carteira ${coin} para receber os ganhos.` };
  }
  if (/\s/.test(clean) || clean.length < 20) {
    return { valid: false, clean, error: 'Endereço de carteira inválido ou incompleto (não deve conter espaços).' };
  }
  if (/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(clean)) {
    return {
      valid: false,
      clean,
      error:
        'Esse endereço começa com "T" (rede TRON / USDT-TRC20 / TRX). A Zpool paga em BTC, LTC, SUGAR, ADVC, VRSC, DASH ou BCH — cole uma carteira dessa moeda, ou use a aba unMineable para TRX/USDT/XMR/TON.',
    };
  }
  if (/^0x[0-9a-fA-F]{40}$/.test(clean)) {
    return {
      valid: false,
      clean,
      error:
        'Esse endereço começa com "0x" (Ethereum / ERC20 / BEP20). Para receber na Zpool, use um endereço da moeda selecionada (ex: BTC bc1..., LTC ltc1..., SUGAR sugar1...).',
    };
  }
  switch (coin) {
    case 'BTC':
      if (!/^(bc1[a-z0-9]{25,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(clean)) {
        return { valid: false, clean, error: 'Endereço Bitcoin (BTC) inválido. Deve iniciar com bc1, 1 ou 3.' };
      }
      break;
    case 'LTC':
      if (!/^(ltc1[a-z0-9]{25,87}|[LM3][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(clean)) {
        return { valid: false, clean, error: 'Endereço Litecoin (LTC) inválido. Deve iniciar com ltc1, L, M ou 3.' };
      }
      break;
    case 'SUGAR':
      if (!/^sugar1[a-z0-9]{25,87}$/.test(clean)) {
        return { valid: false, clean, error: 'Endereço Sugarchain inválido. Deve iniciar com sugar1...' };
      }
      break;
    case 'VRSC':
      if (!/^R[a-km-zA-HJ-NP-Z1-9]{25,36}$/.test(clean)) {
        return { valid: false, clean, error: 'Endereço VerusCoin (VRSC) inválido. Deve iniciar com R...' };
      }
      break;
    case 'DASH':
      if (!/^[X7][a-km-zA-HJ-NP-Z1-9]{25,36}$/.test(clean)) {
        return { valid: false, clean, error: 'Endereço Dash inválido. Deve iniciar com X...' };
      }
      break;
    default:
      if (!/^[a-zA-Z0-9:]{20,90}$/.test(clean)) {
        return { valid: false, clean, error: `Formato de carteira ${coin} inválido.` };
      }
  }
  return { valid: true, clean };
}

export interface DeviceHardware {
  cores: number;
  isAndroid: boolean;
  arch: string;
  deviceLabel: string;
}

export function getDeviceHardware(): DeviceHardware {
  const nav = typeof navigator !== 'undefined' ? navigator : null;
  const ua = nav?.userAgent ?? '';
  const cores = Math.max(1, nav?.hardwareConcurrency ?? 4);
  const isAndroid = /Android/i.test(ua);
  const isArm = /arm|aarch64|android/i.test(ua);

  let arch = isArm ? 'ARM64 / AArch64' : 'CPU Multi-Core';
  if (/aarch64|arm64/i.test(ua)) arch = 'ARM64 (AArch64)';
  else if (isAndroid) arch = 'Android ARM';

  let deviceLabel = 'Navegador Desktop';
  if (isAndroid) {
    const match = ua.match(/Android\s+([\d.]+);\s*([^;)]+)/i);
    deviceLabel = match ? `Android ${match[1]} · ${match[2].trim()}` : 'Smartphone Android';
  } else if (/Mac/i.test(ua)) {
    deviceLabel = 'Apple Silicon / macOS';
  } else if (/Linux/i.test(ua)) {
    deviceLabel = 'Linux';
  } else if (/Windows/i.test(ua)) {
    deviceLabel = 'Windows';
  }

  return { cores, isAndroid, arch, deviceLabel };
}

export function createBlockHeader(height: number, diffBits: number): {
  headerHex: string;
  jobId: string;
} {
  const prev = new Uint8Array(32);
  const merkle = new Uint8Array(32);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(prev);
    crypto.getRandomValues(merkle);
  }
  const hex = (arr: Uint8Array) =>
    Array.from(arr)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');

  const ntime = Math.floor(Date.now() / 1000) >>> 0;
  const ntimeLE =
    (ntime & 0xff).toString(16).padStart(2, '0') +
    ((ntime >>> 8) & 0xff).toString(16).padStart(2, '0') +
    ((ntime >>> 16) & 0xff).toString(16).padStart(2, '0') +
    ((ntime >>> 24) & 0xff).toString(16).padStart(2, '0');
  const nbits = (0x1d00ffff - Math.min(24, diffBits)).toString(16).padStart(8, '0');

  return {
    headerHex: ('20000000' + hex(prev) + hex(merkle) + ntimeLE + nbits + '00000000').slice(0, 160),
    jobId: `blk-${height}`,
  };
}

export function formatHashrate(hps: number): string {
  if (!Number.isFinite(hps) || hps <= 0) return '0 H/s';
  if (hps >= 1_000_000) return `${(hps / 1_000_000).toFixed(2)} MH/s`;
  if (hps >= 1_000) return `${(hps / 1_000).toFixed(2)} kH/s`;
  return `${Math.round(hps)} H/s`;
}

export function formatClock(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`;
}

export function difficultyToZeroBits(difficulty: number, algo: MiningAlgorithm = 'sha256d'): number {
  if (!Number.isFinite(difficulty) || difficulty <= 0) return 16;
  const baseBits = algo === 'sha256d' ? 32 : 16;
  return Math.max(4, Math.min(64, Math.round(baseBits + Math.log2(difficulty))));
}

