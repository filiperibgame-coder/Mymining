import { createYespowerV1Wasm, type YespowerWasmSmix } from './yespowerWasm.ts';
import { createYespowerV1WasmSimd } from './yespowerWasmSimd.ts';

const EMPTY_U8 = new Uint8Array(0);

export type YespowerVersion = 5 | 10;

export interface YespowerParams {
  version: YespowerVersion;
  N: number;
  r: number;
  pers?: Uint8Array | string | null;
}

const SHA256_K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);

const SHA256_IV = new Uint32Array([
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
  0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]);

const PWXsimple = 2;
const PWXgather = 4;
const PWXbytes = PWXgather * PWXsimple * 8; // 64
const PWXwords = PWXbytes >>> 2; // 16

export class YespowerWorkspace {
  private readonly shaW = new Uint32Array(64);
  private readonly shaState = new Uint32Array(8);
  private readonly hmacIpad = new Uint8Array(64);
  private readonly hmacOpad = new Uint8Array(64);
  private readonly hmacInnerMid = new Uint32Array(8);
  private readonly hmacOuterMid = new Uint32Array(8);
  private readonly hmacTmp = new Uint8Array(32);
  private readonly hmacTail = new Uint8Array(64);
  private readonly shaPadBuf = new Uint8Array(128);
  private readonly pbkdfSaltIdx = new Uint8Array(4);
  private readonly salsaX = new Uint32Array(16);
  private readonly salsaB = new Uint32Array(16);
  private readonly pwxBlock = new Uint32Array(PWXwords);

  private V = new Uint32Array(0);
  private BBytes = new Uint8Array(0);
  private X = new Uint32Array(0);
  private S = new Uint32Array(0);
  private shaPass = new Uint8Array(32);
  private firstBlockCopy = new Uint8Array(32);

  private cachedHdrPrefix = new Uint8Array(64);
  private cachedHdrMidstate = new Uint32Array(8);
  private hasCachedHdr = false;

  private sOff0 = 0;
  private sOff1 = 0;
  private sOff2 = 0;
  private pwxW = 0;
  private pwxRounds = 3;
  private salsa20Rounds = 2;
  private sWidth = 11;
  private sMask = 0;
  private version: YespowerVersion = 10;
  private wasmSimdSmix: YespowerWasmSmix | null = null;
  private wasmScalarSmix: YespowerWasmSmix | null = null;
  private wasmSmix: YespowerWasmSmix | null = null;
  public isWasmActive = false;
  public isSimdActive = false;
  public cacheBytes = 0;

  constructor(options?: { lazyInit?: boolean }) {
    if (!options?.lazyInit) {
      this.setUseSimdCache(true, 16);
    }
  }

  public setUseSimdCache(enabled: boolean, targetCacheMb = enabled ? 16 : 9) {
    const targetPages = Math.max(132, Math.min(256, Math.round((targetCacheMb * 1024 * 1024) / 65536)));
    if (enabled) {
      this.wasmScalarSmix = null;
      const curPages = this.wasmSimdSmix ? Math.round(this.wasmSimdSmix.memU8.byteLength / 65536) : 0;
      if (!this.wasmSimdSmix || Math.abs(curPages - targetPages) >= 16) {
        this.wasmSimdSmix = null;
        this.wasmSimdSmix = createYespowerV1WasmSimd(targetPages);
      }
      if (!this.wasmSimdSmix) {
        this.wasmScalarSmix = createYespowerV1Wasm(Math.min(targetPages, 140));
      }
      this.wasmSmix = this.wasmSimdSmix ?? this.wasmScalarSmix;
    } else {
      this.wasmSimdSmix = null;
      const scalarPages = Math.min(targetPages, 140);
      const curPages = this.wasmScalarSmix ? Math.round(this.wasmScalarSmix.memU8.byteLength / 65536) : 0;
      if (!this.wasmScalarSmix || Math.abs(curPages - scalarPages) >= 8) {
        this.wasmScalarSmix = null;
        this.wasmScalarSmix = createYespowerV1Wasm(scalarPages);
      }
      this.wasmSmix = this.wasmScalarSmix;
    }
    this.isWasmActive = this.wasmSmix !== null;
    this.isSimdActive = this.wasmSmix !== null && this.wasmSmix === this.wasmSimdSmix;
    this.cacheBytes = this.wasmSmix ? this.wasmSmix.memU8.byteLength : 0;
    if (this.wasmSmix) {
      // Release JS fallback arrays if WASM is active
      this.V = new Uint32Array(0);
      this.BBytes = new Uint8Array(0);
      this.X = new Uint32Array(0);
      this.S = new Uint32Array(0);
    }
  }

  public releaseWasmForLowMemory() {
    this.wasmSimdSmix = null;
    this.wasmScalarSmix = null;
    this.wasmSmix = null;
    this.isWasmActive = false;
    this.isSimdActive = false;
    this.cacheBytes = 0;
  }

  public warmCache(limitBytes?: number) {
    if (!this.wasmSmix) return;
    const mem = this.wasmSmix.memU8;
    const end = limitBytes ? Math.min(mem.length, limitBytes) : mem.length;
    // Touch one byte per 4 KB OS page so physical RAM is committed upfront without mid-hash page faults
    for (let p = 0x20000; p < end; p += 4096) {
      mem[p] = mem[p];
    }
  }

  private sha256CompressBlock(state: Uint32Array, block: Uint8Array, offset: number) {
    const w = this.shaW;
    for (let i = 0; i < 16; i++) {
      const idx = offset + i * 4;
      w[i] =
        ((block[idx] << 24) |
          (block[idx + 1] << 16) |
          (block[idx + 2] << 8) |
          block[idx + 3]) >>>
        0;
    }
    for (let i = 16; i < 64; i++) {
      const w15 = w[i - 15];
      const s0 = ((w15 >>> 7) | (w15 << 25)) ^ ((w15 >>> 18) | (w15 << 14)) ^ (w15 >>> 3);
      const w2 = w[i - 2];
      const s1 = ((w2 >>> 17) | (w2 << 15)) ^ ((w2 >>> 19) | (w2 << 13)) ^ (w2 >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }

    let a = state[0] | 0;
    let b = state[1] | 0;
    let c = state[2] | 0;
    let d = state[3] | 0;
    let e = state[4] | 0;
    let f = state[5] | 0;
    let g = state[6] | 0;
    let h = state[7] | 0;

    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + SHA256_K[i] + w[i]) | 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) | 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) | 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) | 0;
    }

    state[0] = (state[0] + a) >>> 0;
    state[1] = (state[1] + b) >>> 0;
    state[2] = (state[2] + c) >>> 0;
    state[3] = (state[3] + d) >>> 0;
    state[4] = (state[4] + e) >>> 0;
    state[5] = (state[5] + f) >>> 0;
    state[6] = (state[6] + g) >>> 0;
    state[7] = (state[7] + h) >>> 0;
  }

  private sha256Finalize(state: Uint32Array, tail: Uint8Array, tailLen: number, totalBits: number, out: Uint8Array) {
    const pad = this.shaPadBuf;
    pad.fill(0);
    for (let i = 0; i < tailLen; i++) pad[i] = tail[i];
    pad[tailLen] = 0x80;
    const totalPadLen = tailLen < 56 ? 64 : 128;
    const bitHi = Math.floor(totalBits / 0x100000000) >>> 0;
    const bitLo = totalBits >>> 0;
    pad[totalPadLen - 8] = (bitHi >>> 24) & 0xff;
    pad[totalPadLen - 7] = (bitHi >>> 16) & 0xff;
    pad[totalPadLen - 6] = (bitHi >>> 8) & 0xff;
    pad[totalPadLen - 5] = bitHi & 0xff;
    pad[totalPadLen - 4] = (bitLo >>> 24) & 0xff;
    pad[totalPadLen - 3] = (bitLo >>> 16) & 0xff;
    pad[totalPadLen - 2] = (bitLo >>> 8) & 0xff;
    pad[totalPadLen - 1] = bitLo & 0xff;

    this.sha256CompressBlock(state, pad, 0);
    if (totalPadLen === 128) this.sha256CompressBlock(state, pad, 64);

    for (let i = 0; i < 8; i++) {
      const v = state[i];
      out[i * 4] = (v >>> 24) & 0xff;
      out[i * 4 + 1] = (v >>> 16) & 0xff;
      out[i * 4 + 2] = (v >>> 8) & 0xff;
      out[i * 4 + 3] = v & 0xff;
    }
  }

  private sha256Buf(data: Uint8Array, out: Uint8Array) {
    const st = this.shaState;
    if (data.length === 80) {
      let matched = this.hasCachedHdr;
      if (matched) {
        const cp = this.cachedHdrPrefix;
        for (let i = 0; i < 64; i++) {
          if (data[i] !== cp[i]) {
            matched = false;
            break;
          }
        }
      }
      if (!matched) {
        st.set(SHA256_IV);
        this.sha256CompressBlock(st, data, 0);
        this.cachedHdrPrefix.set(data.subarray(0, 64));
        this.cachedHdrMidstate.set(st);
        this.hasCachedHdr = true;
      } else {
        st.set(this.cachedHdrMidstate);
      }
      this.sha256Finalize(st, data.subarray(64, 80), 16, 640, out);
      return;
    }

    st.set(SHA256_IV);
    let offset = 0;
    while (offset + 64 <= data.length) {
      this.sha256CompressBlock(st, data, offset);
      offset += 64;
    }
    this.sha256Finalize(st, data.subarray(offset), data.length - offset, data.length * 8, out);
  }

  private hmacSha256TwoPart(
    key: Uint8Array,
    msg1: Uint8Array,
    msg2: Uint8Array,
    out: Uint8Array
  ) {
    const ipad = this.hmacIpad;
    const opad = this.hmacOpad;
    if (key.length > 64) {
      this.sha256Buf(key, this.hmacTmp);
      for (let i = 0; i < 32; i++) {
        ipad[i] = this.hmacTmp[i] ^ 0x36;
        opad[i] = this.hmacTmp[i] ^ 0x5c;
      }
      for (let i = 32; i < 64; i++) {
        ipad[i] = 0x36;
        opad[i] = 0x5c;
      }
    } else {
      for (let i = 0; i < key.length; i++) {
        ipad[i] = key[i] ^ 0x36;
        opad[i] = key[i] ^ 0x5c;
      }
      for (let i = key.length; i < 64; i++) {
        ipad[i] = 0x36;
        opad[i] = 0x5c;
      }
    }

    const st = this.shaState;
    st.set(SHA256_IV);
    this.sha256CompressBlock(st, ipad, 0);

    // Feed msg1 + msg2 in 64-byte chunks
    const totalMsgLen = msg1.length + msg2.length;
    const tail = this.hmacTail;
    let tailLen = 0;

    const feed = (src: Uint8Array) => {
      let off = 0;
      if (tailLen > 0) {
        const need = 64 - tailLen;
        if (src.length < need) {
          tail.set(src, tailLen);
          tailLen += src.length;
          return;
        }
        tail.set(src.subarray(0, need), tailLen);
        this.sha256CompressBlock(st, tail, 0);
        tailLen = 0;
        off = need;
      }
      while (off + 64 <= src.length) {
        this.sha256CompressBlock(st, src, off);
        off += 64;
      }
      if (off < src.length) {
        tail.set(src.subarray(off), 0);
        tailLen = src.length - off;
      }
    };

    feed(msg1);
    if (msg2.length > 0) feed(msg2);
    this.sha256Finalize(st, tail, tailLen, (64 + totalMsgLen) * 8, this.hmacTmp);

    st.set(SHA256_IV);
    this.sha256CompressBlock(st, opad, 0);
    this.sha256Finalize(st, this.hmacTmp, 32, (64 + 32) * 8, out);
  }

  private pbkdf2Sha256Iter1(passwd: Uint8Array, salt: Uint8Array, dk: Uint8Array) {
    const ipad = this.hmacIpad;
    const opad = this.hmacOpad;
    if (passwd.length > 64) {
      this.sha256Buf(passwd, this.hmacTmp);
      for (let i = 0; i < 32; i++) {
        ipad[i] = this.hmacTmp[i] ^ 0x36;
        opad[i] = this.hmacTmp[i] ^ 0x5c;
      }
      for (let i = 32; i < 64; i++) {
        ipad[i] = 0x36;
        opad[i] = 0x5c;
      }
    } else {
      for (let i = 0; i < passwd.length; i++) {
        ipad[i] = passwd[i] ^ 0x36;
        opad[i] = passwd[i] ^ 0x5c;
      }
      for (let i = passwd.length; i < 64; i++) {
        ipad[i] = 0x36;
        opad[i] = 0x5c;
      }
    }

    const innerMid = this.hmacInnerMid;
    innerMid.set(SHA256_IV);
    this.sha256CompressBlock(innerMid, ipad, 0);

    const outerMid = this.hmacOuterMid;
    outerMid.set(SHA256_IV);
    this.sha256CompressBlock(outerMid, opad, 0);

    // Precompute salt prefix blocks into innerMid when salt >= 64 bytes (e.g. Sugarchain 74B pers)
    let saltOff = 0;
    while (saltOff + 64 <= salt.length) {
      this.sha256CompressBlock(innerMid, salt, saltOff);
      saltOff += 64;
    }
    const saltRemLen = salt.length - saltOff;
    const totalInnerBits = (64 + salt.length + 4) * 8;
    const tail = this.hmacTail;

    const blocks = Math.ceil(dk.length / 32);
    const idxBuf = this.pbkdfSaltIdx;
    const st = this.shaState;
    for (let i = 1; i <= blocks; i++) {
      idxBuf[0] = (i >>> 24) & 0xff;
      idxBuf[1] = (i >>> 16) & 0xff;
      idxBuf[2] = (i >>> 8) & 0xff;
      idxBuf[3] = i & 0xff;

      st.set(innerMid);
      for (let k = 0; k < saltRemLen; k++) tail[k] = salt[saltOff + k];
      let tailLen = saltRemLen;
      if (tailLen + 4 >= 64) {
        const take = 64 - tailLen;
        for (let k = 0; k < take; k++) tail[tailLen + k] = idxBuf[k];
        this.sha256CompressBlock(st, tail, 0);
        const rem = 4 - take;
        for (let k = 0; k < rem; k++) tail[k] = idxBuf[take + k];
        tailLen = rem;
      } else {
        for (let k = 0; k < 4; k++) tail[tailLen + k] = idxBuf[k];
        tailLen += 4;
      }

      this.sha256Finalize(st, tail, tailLen, totalInnerBits, this.hmacTmp);

      st.set(outerMid);
      this.sha256Finalize(st, this.hmacTmp, 32, (64 + 32) * 8, this.hmacTmp);

      const outOff = (i - 1) * 32;
      const copyLen = Math.min(32, dk.length - outOff);
      for (let j = 0; j < copyLen; j++) dk[outOff + j] = this.hmacTmp[j];
    }
  }

  private salsa20(B: Uint32Array, bOff: number, rounds: number) {
    const x = this.salsaX;
    for (let i = 0; i < 16; i++) x[(i * 5) & 15] = B[bOff + i];

    let x0 = x[0] | 0, x1 = x[1] | 0, x2 = x[2] | 0, x3 = x[3] | 0;
    let x4 = x[4] | 0, x5 = x[5] | 0, x6 = x[6] | 0, x7 = x[7] | 0;
    let x8 = x[8] | 0, x9 = x[9] | 0, x10 = x[10] | 0, x11 = x[11] | 0;
    let x12 = x[12] | 0, x13 = x[13] | 0, x14 = x[14] | 0, x15 = x[15] | 0;

    for (let i = 0; i < rounds; i += 2) {
      let t: number;
      t = (x0 + x12) | 0; x4 ^= (t << 7) | (t >>> 25);
      t = (x4 + x0) | 0; x8 ^= (t << 9) | (t >>> 23);
      t = (x8 + x4) | 0; x12 ^= (t << 13) | (t >>> 19);
      t = (x12 + x8) | 0; x0 ^= (t << 18) | (t >>> 14);

      t = (x5 + x1) | 0; x9 ^= (t << 7) | (t >>> 25);
      t = (x9 + x5) | 0; x13 ^= (t << 9) | (t >>> 23);
      t = (x13 + x9) | 0; x1 ^= (t << 13) | (t >>> 19);
      t = (x1 + x13) | 0; x5 ^= (t << 18) | (t >>> 14);

      t = (x10 + x6) | 0; x14 ^= (t << 7) | (t >>> 25);
      t = (x14 + x10) | 0; x2 ^= (t << 9) | (t >>> 23);
      t = (x2 + x14) | 0; x6 ^= (t << 13) | (t >>> 19);
      t = (x6 + x2) | 0; x10 ^= (t << 18) | (t >>> 14);

      t = (x15 + x11) | 0; x3 ^= (t << 7) | (t >>> 25);
      t = (x3 + x15) | 0; x7 ^= (t << 9) | (t >>> 23);
      t = (x7 + x3) | 0; x11 ^= (t << 13) | (t >>> 19);
      t = (x11 + x7) | 0; x15 ^= (t << 18) | (t >>> 14);

      t = (x0 + x3) | 0; x1 ^= (t << 7) | (t >>> 25);
      t = (x1 + x0) | 0; x2 ^= (t << 9) | (t >>> 23);
      t = (x2 + x1) | 0; x3 ^= (t << 13) | (t >>> 19);
      t = (x3 + x2) | 0; x0 ^= (t << 18) | (t >>> 14);

      t = (x5 + x4) | 0; x6 ^= (t << 7) | (t >>> 25);
      t = (x6 + x5) | 0; x7 ^= (t << 9) | (t >>> 23);
      t = (x7 + x6) | 0; x4 ^= (t << 13) | (t >>> 19);
      t = (x4 + x7) | 0; x5 ^= (t << 18) | (t >>> 14);

      t = (x10 + x9) | 0; x11 ^= (t << 7) | (t >>> 25);
      t = (x11 + x10) | 0; x8 ^= (t << 9) | (t >>> 23);
      t = (x8 + x11) | 0; x9 ^= (t << 13) | (t >>> 19);
      t = (x9 + x8) | 0; x10 ^= (t << 18) | (t >>> 14);

      t = (x15 + x14) | 0; x12 ^= (t << 7) | (t >>> 25);
      t = (x12 + x15) | 0; x13 ^= (t << 9) | (t >>> 23);
      t = (x13 + x12) | 0; x14 ^= (t << 13) | (t >>> 19);
      t = (x14 + x13) | 0; x15 ^= (t << 18) | (t >>> 14);
    }

    x[0] = x0; x[1] = x1; x[2] = x2; x[3] = x3;
    x[4] = x4; x[5] = x5; x[6] = x6; x[7] = x7;
    x[8] = x8; x[9] = x9; x[10] = x10; x[11] = x11;
    x[12] = x12; x[13] = x13; x[14] = x14; x[15] = x15;

    for (let i = 0; i < 16; i++) {
      B[bOff + i] = (B[bOff + i] + x[(i * 5) & 15]) >>> 0;
    }
  }

  private blockmixSalsa(B: Uint32Array, rounds: number) {
    const X = this.salsaB;
    for (let i = 0; i < 16; i++) X[i] = B[16 + i];
    for (let i = 0; i < 2; i++) {
      const off = i * 16;
      for (let k = 0; k < 16; k++) X[k] = (X[k] ^ B[off + k]) >>> 0;
      this.salsa20(X, 0, rounds);
      for (let k = 0; k < 16; k++) B[off + k] = X[k];
    }
  }

  private pwxformV1(B: Uint32Array) {
    const S = this.S;
    let sOff0 = this.sOff0;
    let sOff1 = this.sOff1;
    let sOff2 = this.sOff2;
    const sMask = this.sMask;
    let w = this.pwxW;

    let b0 = B[0], b1 = B[1], b2 = B[2], b3 = B[3];
    let b4 = B[4], b5 = B[5], b6 = B[6], b7 = B[7];
    let b8 = B[8], b9 = B[9], b10 = B[10], b11 = B[11];
    let b12 = B[12], b13 = B[13], b14 = B[14], b15 = B[15];

    for (let i = 0; i < 3; i++) {
      // j = 0
      {
        const p0Word = (b0 & sMask) >>> 2;
        const p1Word = (b1 & sMask) >>> 2;
        // k = 0
        {
          const aLo = b1 & 0xffff, aHi = b1 >>> 16;
          const bLo = b0 & 0xffff, bHi = b0 >>> 16;
          const p0 = Math.imul(aLo, bLo) >>> 0;
          const p1 = Math.imul(aLo, bHi) >>> 0;
          const p2 = Math.imul(aHi, bLo) >>> 0;
          const p3 = Math.imul(aHi, bHi) >>> 0;
          const mid = (p0 >>> 16) + (p1 & 0xffff) + (p2 & 0xffff);
          const prodLo = Math.imul(b1, b0) >>> 0;
          const prodHi = (p3 + (p1 >>> 16) + (p2 >>> 16) + (mid >>> 16)) >>> 0;
          const s0Idx = sOff0 + p0Word;
          const s1Idx = sOff1 + p1Word;
          const sumLo = prodLo + S[s0Idx];
          const carry = sumLo >= 4294967296 ? 1 : 0;
          b0 = ((sumLo >>> 0) ^ S[s1Idx]) >>> 0;
          b1 = (((prodHi + S[s0Idx + 1] + carry) >>> 0) ^ S[s1Idx + 1]) >>> 0;
        }
        // k = 1
        {
          const aLo = b3 & 0xffff, aHi = b3 >>> 16;
          const bLo = b2 & 0xffff, bHi = b2 >>> 16;
          const p0 = Math.imul(aLo, bLo) >>> 0;
          const p1 = Math.imul(aLo, bHi) >>> 0;
          const p2 = Math.imul(aHi, bLo) >>> 0;
          const p3 = Math.imul(aHi, bHi) >>> 0;
          const mid = (p0 >>> 16) + (p1 & 0xffff) + (p2 & 0xffff);
          const prodLo = Math.imul(b3, b2) >>> 0;
          const prodHi = (p3 + (p1 >>> 16) + (p2 >>> 16) + (mid >>> 16)) >>> 0;
          const s0Idx = sOff0 + p0Word + 2;
          const s1Idx = sOff1 + p1Word + 2;
          const sumLo = prodLo + S[s0Idx];
          const carry = sumLo >= 4294967296 ? 1 : 0;
          b2 = ((sumLo >>> 0) ^ S[s1Idx]) >>> 0;
          b3 = (((prodHi + S[s0Idx + 1] + carry) >>> 0) ^ S[s1Idx + 1]) >>> 0;
        }
        // j = 0 -> even: write to sOff0 + (w+k)*2
        const ws = sOff0 + w * 2;
        S[ws] = b0; S[ws + 1] = b1; S[ws + 2] = b2; S[ws + 3] = b3;
      }

      // j = 1
      {
        const p0Word = (b4 & sMask) >>> 2;
        const p1Word = (b5 & sMask) >>> 2;
        // k = 0
        {
          const aLo = b5 & 0xffff, aHi = b5 >>> 16;
          const bLo = b4 & 0xffff, bHi = b4 >>> 16;
          const p0 = Math.imul(aLo, bLo) >>> 0;
          const p1 = Math.imul(aLo, bHi) >>> 0;
          const p2 = Math.imul(aHi, bLo) >>> 0;
          const p3 = Math.imul(aHi, bHi) >>> 0;
          const mid = (p0 >>> 16) + (p1 & 0xffff) + (p2 & 0xffff);
          const prodLo = Math.imul(b5, b4) >>> 0;
          const prodHi = (p3 + (p1 >>> 16) + (p2 >>> 16) + (mid >>> 16)) >>> 0;
          const s0Idx = sOff0 + p0Word;
          const s1Idx = sOff1 + p1Word;
          const sumLo = prodLo + S[s0Idx];
          const carry = sumLo >= 4294967296 ? 1 : 0;
          b4 = ((sumLo >>> 0) ^ S[s1Idx]) >>> 0;
          b5 = (((prodHi + S[s0Idx + 1] + carry) >>> 0) ^ S[s1Idx + 1]) >>> 0;
        }
        // k = 1
        {
          const aLo = b7 & 0xffff, aHi = b7 >>> 16;
          const bLo = b6 & 0xffff, bHi = b6 >>> 16;
          const p0 = Math.imul(aLo, bLo) >>> 0;
          const p1 = Math.imul(aLo, bHi) >>> 0;
          const p2 = Math.imul(aHi, bLo) >>> 0;
          const p3 = Math.imul(aHi, bHi) >>> 0;
          const mid = (p0 >>> 16) + (p1 & 0xffff) + (p2 & 0xffff);
          const prodLo = Math.imul(b7, b6) >>> 0;
          const prodHi = (p3 + (p1 >>> 16) + (p2 >>> 16) + (mid >>> 16)) >>> 0;
          const s0Idx = sOff0 + p0Word + 2;
          const s1Idx = sOff1 + p1Word + 2;
          const sumLo = prodLo + S[s0Idx];
          const carry = sumLo >= 4294967296 ? 1 : 0;
          b6 = ((sumLo >>> 0) ^ S[s1Idx]) >>> 0;
          b7 = (((prodHi + S[s0Idx + 1] + carry) >>> 0) ^ S[s1Idx + 1]) >>> 0;
        }
        // j = 1 -> odd: write to sOff1 + w*2 and w += 2
        const ws = sOff1 + w * 2;
        S[ws] = b4; S[ws + 1] = b5; S[ws + 2] = b6; S[ws + 3] = b7;
        w += 2;
      }

      // j = 2
      {
        const p0Word = (b8 & sMask) >>> 2;
        const p1Word = (b9 & sMask) >>> 2;
        // k = 0
        {
          const aLo = b9 & 0xffff, aHi = b9 >>> 16;
          const bLo = b8 & 0xffff, bHi = b8 >>> 16;
          const p0 = Math.imul(aLo, bLo) >>> 0;
          const p1 = Math.imul(aLo, bHi) >>> 0;
          const p2 = Math.imul(aHi, bLo) >>> 0;
          const p3 = Math.imul(aHi, bHi) >>> 0;
          const mid = (p0 >>> 16) + (p1 & 0xffff) + (p2 & 0xffff);
          const prodLo = Math.imul(b9, b8) >>> 0;
          const prodHi = (p3 + (p1 >>> 16) + (p2 >>> 16) + (mid >>> 16)) >>> 0;
          const s0Idx = sOff0 + p0Word;
          const s1Idx = sOff1 + p1Word;
          const sumLo = prodLo + S[s0Idx];
          const carry = sumLo >= 4294967296 ? 1 : 0;
          b8 = ((sumLo >>> 0) ^ S[s1Idx]) >>> 0;
          b9 = (((prodHi + S[s0Idx + 1] + carry) >>> 0) ^ S[s1Idx + 1]) >>> 0;
        }
        // k = 1
        {
          const aLo = b11 & 0xffff, aHi = b11 >>> 16;
          const bLo = b10 & 0xffff, bHi = b10 >>> 16;
          const p0 = Math.imul(aLo, bLo) >>> 0;
          const p1 = Math.imul(aLo, bHi) >>> 0;
          const p2 = Math.imul(aHi, bLo) >>> 0;
          const p3 = Math.imul(aHi, bHi) >>> 0;
          const mid = (p0 >>> 16) + (p1 & 0xffff) + (p2 & 0xffff);
          const prodLo = Math.imul(b11, b10) >>> 0;
          const prodHi = (p3 + (p1 >>> 16) + (p2 >>> 16) + (mid >>> 16)) >>> 0;
          const s0Idx = sOff0 + p0Word + 2;
          const s1Idx = sOff1 + p1Word + 2;
          const sumLo = prodLo + S[s0Idx];
          const carry = sumLo >= 4294967296 ? 1 : 0;
          b10 = ((sumLo >>> 0) ^ S[s1Idx]) >>> 0;
          b11 = (((prodHi + S[s0Idx + 1] + carry) >>> 0) ^ S[s1Idx + 1]) >>> 0;
        }
        if (i === 0) {
          const ws = sOff0 + w * 2;
          S[ws] = b8; S[ws + 1] = b9; S[ws + 2] = b10; S[ws + 3] = b11;
        }
      }

      // j = 3
      {
        const p0Word = (b12 & sMask) >>> 2;
        const p1Word = (b13 & sMask) >>> 2;
        // k = 0
        {
          const aLo = b13 & 0xffff, aHi = b13 >>> 16;
          const bLo = b12 & 0xffff, bHi = b12 >>> 16;
          const p0 = Math.imul(aLo, bLo) >>> 0;
          const p1 = Math.imul(aLo, bHi) >>> 0;
          const p2 = Math.imul(aHi, bLo) >>> 0;
          const p3 = Math.imul(aHi, bHi) >>> 0;
          const mid = (p0 >>> 16) + (p1 & 0xffff) + (p2 & 0xffff);
          const prodLo = Math.imul(b13, b12) >>> 0;
          const prodHi = (p3 + (p1 >>> 16) + (p2 >>> 16) + (mid >>> 16)) >>> 0;
          const s0Idx = sOff0 + p0Word;
          const s1Idx = sOff1 + p1Word;
          const sumLo = prodLo + S[s0Idx];
          const carry = sumLo >= 4294967296 ? 1 : 0;
          b12 = ((sumLo >>> 0) ^ S[s1Idx]) >>> 0;
          b13 = (((prodHi + S[s0Idx + 1] + carry) >>> 0) ^ S[s1Idx + 1]) >>> 0;
        }
        // k = 1
        {
          const aLo = b15 & 0xffff, aHi = b15 >>> 16;
          const bLo = b14 & 0xffff, bHi = b14 >>> 16;
          const p0 = Math.imul(aLo, bLo) >>> 0;
          const p1 = Math.imul(aLo, bHi) >>> 0;
          const p2 = Math.imul(aHi, bLo) >>> 0;
          const p3 = Math.imul(aHi, bHi) >>> 0;
          const mid = (p0 >>> 16) + (p1 & 0xffff) + (p2 & 0xffff);
          const prodLo = Math.imul(b15, b14) >>> 0;
          const prodHi = (p3 + (p1 >>> 16) + (p2 >>> 16) + (mid >>> 16)) >>> 0;
          const s0Idx = sOff0 + p0Word + 2;
          const s1Idx = sOff1 + p1Word + 2;
          const sumLo = prodLo + S[s0Idx];
          const carry = sumLo >= 4294967296 ? 1 : 0;
          b14 = ((sumLo >>> 0) ^ S[s1Idx]) >>> 0;
          b15 = (((prodHi + S[s0Idx + 1] + carry) >>> 0) ^ S[s1Idx + 1]) >>> 0;
        }
        if (i === 0) {
          const ws = sOff1 + w * 2;
          S[ws] = b12; S[ws + 1] = b13; S[ws + 2] = b14; S[ws + 3] = b15;
          w += 2;
        }
      }
    }

    B[0] = b0; B[1] = b1; B[2] = b2; B[3] = b3;
    B[4] = b4; B[5] = b5; B[6] = b6; B[7] = b7;
    B[8] = b8; B[9] = b9; B[10] = b10; B[11] = b11;
    B[12] = b12; B[13] = b13; B[14] = b14; B[15] = b15;

    this.sOff0 = sOff2;
    this.sOff2 = sOff1;
    this.sOff1 = sOff0;
    this.pwxW = w & (((1 << this.sWidth) * PWXsimple) - 1);
  }

  private pwxform(B: Uint32Array) {
    const S = this.S;
    const sOff0 = this.sOff0;
    const sOff1 = this.sOff1;
    const sMask = this.sMask;
    let w = this.pwxW;
    const rounds = this.pwxRounds;
    const isV1 = this.version !== 5;

    for (let i = 0; i < rounds; i++) {
      for (let j = 0; j < PWXgather; j++) {
        const jBase = j * 4;
        const x0l = B[jBase];
        const x0h = B[jBase + 1];
        const p0Word = (x0l & sMask) >>> 2;
        const p1Word = (x0h & sMask) >>> 2;

        for (let k = 0; k < PWXsimple; k++) {
          const bIdx = jBase + k * 2;
          const xl = B[bIdx];
          const xh = B[bIdx + 1];

          // Exact unsigned 32x32->64 product: xh * xl
          const aLo = xh & 0xffff;
          const aHi = xh >>> 16;
          const bLo = xl & 0xffff;
          const bHi = xl >>> 16;

          const p0 = aLo * bLo;
          const p1 = aLo * bHi;
          const p2 = aHi * bLo;
          const p3 = aHi * bHi;
          const mid = (p0 >>> 16) + (p1 & 0xffff) + (p2 & 0xffff);
          const prodLo = Math.imul(xh, xl) >>> 0;
          const prodHi = (p3 + (p1 >>> 16) + (p2 >>> 16) + (mid >>> 16)) >>> 0;

          const s0Idx = sOff0 + p0Word + k * 2;
          const s1Idx = sOff1 + p1Word + k * 2;
          const s0Lo = S[s0Idx];
          const s0Hi = S[s0Idx + 1];

          const sumLo = prodLo + s0Lo;
          const carry = sumLo >= 4294967296 ? 1 : 0;
          const lo = (sumLo >>> 0) ^ S[s1Idx];
          const hi = ((prodHi + s0Hi + carry) >>> 0) ^ S[s1Idx + 1];

          B[bIdx] = lo;
          B[bIdx + 1] = hi;
        }

        if (isV1 && (i === 0 || j < 2)) {
          if (j & 1) {
            for (let k = 0; k < PWXsimple; k++) {
              const sIdx = sOff1 + w * 2;
              const bIdx = jBase + k * 2;
              S[sIdx] = B[bIdx];
              S[sIdx + 1] = B[bIdx + 1];
              w++;
            }
          } else {
            for (let k = 0; k < PWXsimple; k++) {
              const sIdx = sOff0 + (w + k) * 2;
              const bIdx = jBase + k * 2;
              S[sIdx] = B[bIdx];
              S[sIdx + 1] = B[bIdx + 1];
            }
          }
        }
      }
    }

    if (isV1) {
      this.sOff0 = this.sOff2;
      this.sOff2 = this.sOff1;
      this.sOff1 = sOff0;
      this.pwxW = w & (((1 << this.sWidth) * PWXsimple) - 1);
    }
  }

  private blockmixPwxform(B: Uint32Array, bOff: number, r: number) {
    const X = this.pwxBlock;
    const r1 = (128 * r) / PWXbytes;
    const lastOff = bOff + (r1 - 1) * PWXwords;
    for (let k = 0; k < PWXwords; k++) X[k] = B[lastOff + k];

    if (this.version !== 5) {
      for (let i = 0; i < r1; i++) {
        const curOff = bOff + i * PWXwords;
        if (r1 > 1) {
          for (let k = 0; k < PWXwords; k++) X[k] ^= B[curOff + k];
        }
        this.pwxformV1(X);
        for (let k = 0; k < PWXwords; k++) B[curOff + k] = X[k];
      }
    } else {
      for (let i = 0; i < r1; i++) {
        const curOff = bOff + i * PWXwords;
        if (r1 > 1) {
          for (let k = 0; k < PWXwords; k++) X[k] ^= B[curOff + k];
        }
        this.pwxform(X);
        for (let k = 0; k < PWXwords; k++) B[curOff + k] = X[k];
      }
    }

    let i = ((r1 - 1) * PWXbytes) >> 6;
    this.salsa20(B, bOff + i * 16, this.salsa20Rounds);
    for (i++; i < 2 * r; i++) {
      const cur = bOff + i * 16;
      const prev = cur - 16;
      for (let k = 0; k < 16; k++) B[cur + k] ^= B[prev + k];
      this.salsa20(B, cur, this.salsa20Rounds);
    }
  }

  private static wrap(x: number, i: number): number {
    let n = i;
    let y: number;
    while ((y = n & (n - 1)) !== 0) n = y;
    return ((x & (n - 1)) + (i - n)) >>> 0;
  }

  private smix1(r: number, N: number, V: Uint32Array, isSInit: boolean) {
    const B = this.BBytes;
    const X = this.X;
    const s = 32 * r;

    for (let k = 0; k < 2 * r; k++) {
      for (let i = 0; i < 16; i++) {
        const bPos = (k * 16 + ((i * 5) & 15)) * 4;
        X[k * 16 + i] =
          (B[bPos] | (B[bPos + 1] << 8) | (B[bPos + 2] << 16) | (B[bPos + 3] << 24)) >>> 0;
      }
    }

    if (this.version !== 5) {
      for (let k = 1; k < r; k++) {
        const dst = k * 32;
        const src = dst - 32;
        for (let m = 0; m < 32; m++) X[dst + m] = X[src + m];
        this.blockmixPwxform(X, dst, 1);
      }
    }

    const intIdx = (2 * r - 1) * 16;
    const xSub = X.subarray(0, s);
    for (let i = 0; i < N; i++) {
      const vOff = i * s;
      V.set(xSub, vOff);
      if (i > 1) {
        const j = YespowerWorkspace.wrap(X[intIdx], i);
        const vjOff = j * s;
        for (let m = 0; m < s; m += 8) {
          X[m] ^= V[vjOff + m];
          X[m + 1] ^= V[vjOff + m + 1];
          X[m + 2] ^= V[vjOff + m + 2];
          X[m + 3] ^= V[vjOff + m + 3];
          X[m + 4] ^= V[vjOff + m + 4];
          X[m + 5] ^= V[vjOff + m + 5];
          X[m + 6] ^= V[vjOff + m + 6];
          X[m + 7] ^= V[vjOff + m + 7];
        }
      }
      if (!isSInit) {
        this.blockmixPwxform(X, 0, r);
      } else {
        this.blockmixSalsa(X, this.salsa20Rounds);
      }
    }

    for (let k = 0; k < 2 * r; k++) {
      for (let i = 0; i < 16; i++) {
        const v = X[k * 16 + i];
        const bPos = (k * 16 + ((i * 5) & 15)) * 4;
        B[bPos] = v & 0xff;
        B[bPos + 1] = (v >>> 8) & 0xff;
        B[bPos + 2] = (v >>> 16) & 0xff;
        B[bPos + 3] = (v >>> 24) & 0xff;
      }
    }
  }

  private smix2(r: number, N: number, Nloop: number, V: Uint32Array) {
    const B = this.BBytes;
    const X = this.X;
    const s = 32 * r;
    const nMask = N - 1;
    const intIdx = (2 * r - 1) * 16;

    for (let k = 0; k < 2 * r; k++) {
      for (let i = 0; i < 16; i++) {
        const bPos = (k * 16 + ((i * 5) & 15)) * 4;
        X[k * 16 + i] =
          (B[bPos] | (B[bPos + 1] << 8) | (B[bPos + 2] << 16) | (B[bPos + 3] << 24)) >>> 0;
      }
    }

    const writeBack = Nloop !== 2;
    const xSub = X.subarray(0, s);
    for (let i = 0; i < Nloop; i++) {
      const j = X[intIdx] & nMask;
      const vjOff = j * s;
      for (let m = 0; m < s; m += 8) {
        X[m] ^= V[vjOff + m];
        X[m + 1] ^= V[vjOff + m + 1];
        X[m + 2] ^= V[vjOff + m + 2];
        X[m + 3] ^= V[vjOff + m + 3];
        X[m + 4] ^= V[vjOff + m + 4];
        X[m + 5] ^= V[vjOff + m + 5];
        X[m + 6] ^= V[vjOff + m + 6];
        X[m + 7] ^= V[vjOff + m + 7];
      }
      if (writeBack) {
        V.set(xSub, vjOff);
      }
      this.blockmixPwxform(X, 0, r);
    }

    for (let k = 0; k < 2 * r; k++) {
      for (let i = 0; i < 16; i++) {
        const v = X[k * 16 + i];
        const bPos = (k * 16 + ((i * 5) & 15)) * 4;
        B[bPos] = v & 0xff;
        B[bPos + 1] = (v >>> 8) & 0xff;
        B[bPos + 2] = (v >>> 16) & 0xff;
        B[bPos + 3] = (v >>> 24) & 0xff;
      }
    }
  }

  public hash(src: Uint8Array, params: YespowerParams, dstOut?: Uint8Array): Uint8Array {
    const version = params.version;
    const N = params.N;
    const r = params.r;
    const bSize = 128 * r;
    const bWords = 32 * r;
    const vWords = bWords * N;

    this.version = version;
    if (version === 5) {
      this.salsa20Rounds = 8;
      this.pwxRounds = 6;
      this.sWidth = 8;
    } else {
      this.salsa20Rounds = 2;
      this.pwxRounds = 3;
      this.sWidth = 11;
    }
    const s1Bytes = (1 << this.sWidth) * PWXsimple * 8;
    const sBytes = (version === 5 ? 2 : 3) * s1Bytes;
    const s1Words = s1Bytes >>> 2;
    const sWords = sBytes >>> 2;
    this.sMask = ((1 << this.sWidth) - 1) * PWXsimple * 8;
    this.sOff0 = 0;
    this.sOff1 = s1Words;
    this.sOff2 = s1Words * 2;
    this.pwxW = 0;

    const useWasm = version === 10 && r <= 32 && N <= 2048 && this.wasmSmix !== null;
    if (!useWasm) {
      if (this.V.length < vWords) this.V = new Uint32Array(vWords);
      if (this.BBytes.length < bSize) this.BBytes = new Uint8Array(bSize);
      if (this.X.length < bWords) this.X = new Uint32Array(bWords);
      if (this.S.length < sWords) this.S = new Uint32Array(sWords);
    }

    const B = useWasm ? this.wasmSmix!.memU8.subarray(0, bSize) : this.BBytes.subarray(0, bSize);
    this.sha256Buf(src, this.shaPass);

    let salt: Uint8Array;
    if (version !== 5) {
      if (typeof params.pers === 'string') {
        salt = new TextEncoder().encode(params.pers);
      } else if (params.pers instanceof Uint8Array) {
        salt = params.pers;
      } else {
        salt = EMPTY_U8;
      }
    } else {
      salt = src;
    }

    this.pbkdf2Sha256Iter1(this.shaPass, salt, B);
    for (let i = 0; i < 32; i++) this.firstBlockCopy[i] = B[i];

    // smix
    let nLoopAll = Math.floor((N + 2) / 3);
    let nLoopRw = nLoopAll;
    nLoopAll = (nLoopAll + 1) & ~1;
    if (version === 5) {
      nLoopRw &= ~1;
    } else {
      nLoopRw = (nLoopRw + 1) & ~1;
    }

    if (useWasm) {
      this.wasmSmix!.smixAll(N, r, nLoopRw, nLoopAll - nLoopRw, sBytes >> 7);
    } else {
      this.smix1(1, sBytes >> 7, this.S, true);
      this.smix1(r, N, this.V, false);
      this.smix2(r, N, nLoopRw, this.V);
      this.smix2(r, N, nLoopAll - nLoopRw, this.V);
    }

    const dst = dstOut ?? new Uint8Array(32);
    if (version === 5) {
      this.pbkdf2Sha256Iter1(this.firstBlockCopy, B, dst);
      if (params.pers) {
        const persBytes =
          typeof params.pers === 'string' ? new TextEncoder().encode(params.pers) : params.pers;
        this.hmacSha256TwoPart(dst, persBytes, EMPTY_U8, this.shaPass);
        this.sha256Buf(this.shaPass, dst);
      }
    } else {
      this.hmacSha256TwoPart(B.subarray(bSize - 64, bSize), this.firstBlockCopy, EMPTY_U8, dst);
    }

    return dst;
  }
}

const YESPOWER_DIFF1_NUM = 0x0000ffff00000000000000000000000000000000000000000000000000000000n;

/**
 * Converts a YiiMP / Yespower pool difficulty (where diff 1 = 0x0000ffff << 224)
 * into a 32-byte big-endian target threshold, and checks a little-endian 32-byte hash.
 */
export function difficultyToTarget256BE(difficulty: number, diff1ShiftBits = 240): Uint8Array {
  const safeDiff = Number.isFinite(difficulty) && difficulty > 0 ? difficulty : 0.01;
  // Use 1e9 fixed-point denominator so fractional diffs like 0.005 or 0.01 work cleanly
  const scale = 1_000_000_000n;
  const scaledDiff = BigInt(Math.max(1, Math.round(safeDiff * 1_000_000_000)));
  const base =
    diff1ShiftBits === 240
      ? YESPOWER_DIFF1_NUM
      : 0x00000000ffff0000000000000000000000000000000000000000000000000000n;
  let target = (base * scale) / scaledDiff;
  const max256 = (1n << 256n) - 1n;
  if (target > max256) target = max256;
  const out = new Uint8Array(32);
  for (let i = 31; i >= 0; i--) {
    out[i] = Number(target & 0xffn);
    target >>= 8n;
  }
  return out;
}

export function hashLEMeetsTargetBE(hashLE: Uint8Array, targetBE: Uint8Array): boolean {
  for (let i = 0; i < 32; i++) {
    const hb = hashLE[31 - i];
    const tb = targetBE[i];
    if (hb < tb) return true;
    if (hb > tb) return false;
  }
  return true;
}

export function countLeadingZeroBitsLE(hashLE: Uint8Array): number {
  let zeros = 0;
  for (let i = 31; i >= 0; i--) {
    const b = hashLE[i];
    if (b === 0) {
      zeros += 8;
    } else {
      zeros += Math.clz32(b) - 24;
      break;
    }
  }
  return zeros;
}

export const YESPOWER_PERS = {
  SUGAR: new TextEncoder().encode(
    'Satoshi Nakamoto 31/Oct/2008 Proof-of-work is essentially one-CPU-one-vote'
  ),
  ADVC: new TextEncoder().encode('Let the quest begin'),
} as const;


