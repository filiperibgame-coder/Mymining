// Hand-assembled WebAssembly 128-bit SIMD (v128 / ARM64 NEON) module for Yespower 1.0 smix.
// Accelerates pwxformV1 (i64x2.extmul_low_i32x4_u), Salsa20 (4x i32x4 diagonal vectorization),
// and 128-byte block copy/XOR (v128.load/xor/store) with inlined pwxform register state.
// Automatically falls back to scalar WASM i64 if WebAssembly SIMD is unavailable.

import type { YespowerWasmSmix } from './yespowerWasm.ts';

const PTR_X = 0x1000;       // 4096 bytes
const PTR_SALSA_B = 0x2040; // 64 bytes
const PTR_S = 0x4000;       // 98304 bytes
const PTR_V = 0x20000;      // 8,388,608 bytes (N = 2048, r = 32)
// Default 256 pages (16 MB); minimum 132 pages (~8.25 MB) for Yespower 1.0 (N=2048, r=32)
const INITIAL_PAGES = 256;
const MIN_SIMD_PAGES = 132;

function uleb(n: number): number[] {
  const out: number[] = [];
  let v = n >>> 0;
  do {
    let b = v & 0x7f;
    v >>>= 7;
    if (v !== 0) b |= 0x80;
    out.push(b);
  } while (v !== 0);
  return out;
}

function sleb(n: number): number[] {
  const out: number[] = [];
  let v = n | 0;
  let more = true;
  while (more) {
    let b = v & 0x7f;
    v >>= 7;
    if ((v === 0 && (b & 0x40) === 0) || (v === -1 && (b & 0x40) !== 0)) {
      more = false;
    } else {
      b |= 0x80;
    }
    out.push(b);
  }
  return out;
}

function section(id: number, body: number[]): number[] {
  return [id, ...uleb(body.length), ...body];
}

function strBytes(s: string): number[] {
  const bytes = Array.from(new TextEncoder().encode(s));
  return [...uleb(bytes.length), ...bytes];
}

const I32 = 0x7f;
const V128 = 0x7b;
const VOID = 0x40;

const OP = {
  block: 0x02,
  loop: 0x03,
  if_: 0x04,
  end: 0x0b,
  br: 0x0c,
  br_if: 0x0d,
  call: 0x10,
  local_get: 0x20,
  local_set: 0x21,
  local_tee: 0x22,
  global_get: 0x23,
  global_set: 0x24,
  i32_load: 0x28,
  i32_store: 0x36,
  i32_const: 0x41,
  i32_eqz: 0x45,
  i32_eq: 0x46,
  i32_ne: 0x47,
  i32_gt_u: 0x4b,
  i32_ge_u: 0x4f,
  i32_add: 0x6a,
  i32_sub: 0x6b,
  i32_mul: 0x6c,
  i32_and: 0x71,
  i32_shl: 0x74,
};

const SIMD = {
  prefix: 0xfd,
  v128_load: 0,
  v128_store: 11,
  i8x16_shuffle: 13,
  i32x4_extract_lane: 27,
  v128_or: 80,
  v128_xor: 81,
  i32x4_shl: 171,
  i32x4_shr_u: 173,
  i32x4_add: 174,
  i64x2_add: 206,
  i64x2_extmul_low_i32x4_u: 222,
};

const lget = (i: number) => [OP.local_get, ...uleb(i)];
const lset = (i: number) => [OP.local_set, ...uleb(i)];
const ltee = (i: number) => [OP.local_tee, ...uleb(i)];
const gget = (i: number) => [OP.global_get, ...uleb(i)];
const gset = (i: number) => [OP.global_set, ...uleb(i)];
const i32c = (v: number) => [OP.i32_const, ...sleb(v)];
const ld32 = (off = 0) => [OP.i32_load, 0x02, ...uleb(off)];
const st32 = (off = 0) => [OP.i32_store, 0x02, ...uleb(off)];
const ld128 = (off = 0) => [SIMD.prefix, ...uleb(SIMD.v128_load), 0x03, ...uleb(off)];
const st128 = (off = 0) => [SIMD.prefix, ...uleb(SIMD.v128_store), 0x03, ...uleb(off)];
const vxor = () => [SIMD.prefix, ...uleb(SIMD.v128_xor)];
const vor = () => [SIMD.prefix, ...uleb(SIMD.v128_or)];
const i32x4Add = () => [SIMD.prefix, ...uleb(SIMD.i32x4_add)];
const i32x4Shl = () => [SIMD.prefix, ...uleb(SIMD.i32x4_shl)];
const i32x4ShrU = () => [SIMD.prefix, ...uleb(SIMD.i32x4_shr_u)];
const i64x2Add = () => [SIMD.prefix, ...uleb(SIMD.i64x2_add)];
const i64x2ExtmulLoU = () => [SIMD.prefix, ...uleb(SIMD.i64x2_extmul_low_i32x4_u)];
const lane32 = (idx: number) => [SIMD.prefix, ...uleb(SIMD.i32x4_extract_lane), idx];
const shuffleBytes = (lanes: number[]) => [SIMD.prefix, ...uleb(SIMD.i8x16_shuffle), ...lanes];

const SHUFFLE_ROT1 = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3];
const SHUFFLE_ROT2 = [8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7];
const SHUFFLE_ROT3 = [12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
const SHUFFLE_LO32 = [0, 1, 2, 3, 8, 9, 10, 11, 0, 1, 2, 3, 8, 9, 10, 11];
const SHUFFLE_HI32 = [4, 5, 6, 7, 12, 13, 14, 15, 4, 5, 6, 7, 12, 13, 14, 15];

function rotl32x4(vLocal: number, k: number): number[] {
  return [
    ...lget(vLocal),
    ...i32c(k),
    ...i32x4Shl(),
    ...lget(vLocal),
    ...i32c(32 - k),
    ...i32x4ShrU(),
    ...vor(),
  ];
}

export function buildYespowerV1WasmSimdBytes(): Uint8Array {
  // Types:
  // 0: (i32, i32) -> void
  // 1: (i32, i32, i32, i32) -> void
  // 2: (i32, i32, i32, i32, i32) -> void
  const typeSec = section(1, [
    ...uleb(3),
    0x60, 2, I32, I32, 0,
    0x60, 4, I32, I32, I32, I32, 0,
    0x60, 5, I32, I32, I32, I32, I32, 0,
  ]);

  const importSec = section(2, [
    ...uleb(1),
    ...strBytes('env'),
    ...strBytes('memory'),
    0x02,
    0x00,
    ...uleb(MIN_SIMD_PAGES),
  ]);

  // Functions:
  // 0: salsa20_simd(bPtr, rounds) [type 0]
  // 1: blockmixSalsa_simd(bPtr, rounds) [type 0]
  // 2: blockmixPwxform_simd(bPtr, r) [type 0]
  // 3: smix1_simd(r, N, vPtr, isSInit) [type 1]
  // 4: smix2_simd(r, N, nLoop, vPtr) [type 1]
  // 5: smixAll(N, r, nLoopRw, nLoopRo, sN) [type 2]
  const funcSec = section(3, [...uleb(6), 0, 0, 0, 1, 1, 2]);

  const globalSec = section(6, [
    ...uleb(6),
    I32, 1, ...i32c(0), OP.end,      // 0: sOff0 (bytes relative to PTR_S)
    I32, 1, ...i32c(32768), OP.end,  // 1: sOff1
    I32, 1, ...i32c(65536), OP.end,  // 2: sOff2
    I32, 1, ...i32c(0), OP.end,      // 3: pwxW
    I32, 1, ...i32c(0x7ff0), OP.end, // 4: sMask
    I32, 1, ...i32c(0x7ff8), OP.end, // 5: pwxWMask
  ]);

  const exportSec = section(7, [
    ...uleb(1),
    ...strBytes('smixAll'),
    0x00,
    ...uleb(5),
  ]);

  // --- Func 0: salsa20_simd(bPtr: 0, rounds: 1) ---
  // Locals: i32: 2=i; v128: 3=L0, 4=L1, 5=L2, 6=L3, 7=sum
  const salsaRoundSimd = (a: number, b: number, c: number, d: number) => [
    // b ^= rotl(a + d, 7)
    ...lget(a), ...lget(d), ...i32x4Add(), ...lset(7),
    ...rotl32x4(7, 7), ...lget(b), ...vxor(), ...lset(b),
    // c ^= rotl(b + a, 9)
    ...lget(b), ...lget(a), ...i32x4Add(), ...lset(7),
    ...rotl32x4(7, 9), ...lget(c), ...vxor(), ...lset(c),
    // d ^= rotl(c + b, 13)
    ...lget(c), ...lget(b), ...i32x4Add(), ...lset(7),
    ...rotl32x4(7, 13), ...lget(d), ...vxor(), ...lset(d),
    // a ^= rotl(d + c, 18)
    ...lget(d), ...lget(c), ...i32x4Add(), ...lset(7),
    ...rotl32x4(7, 18), ...lget(a), ...vxor(), ...lset(a),
  ];

  const f0: number[] = [
    ...uleb(2),
    ...uleb(1), I32,
    ...uleb(5), V128,
    ...lget(0), ...ld128(0), ...lset(3),
    ...lget(0), ...ld128(16), ...lset(4),
    ...lget(0), ...ld128(32), ...lset(5),
    ...lget(0), ...ld128(48), ...lset(6),
    ...i32c(0), ...lset(2),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(2), ...lget(1), OP.i32_ge_u, OP.br_if, 1,
    // Column round: (L0, L1, L2, L3)
    ...salsaRoundSimd(3, 4, 5, 6),
    // Shuffle for row round: L3<-rot1(L3), L2<-rot2(L2), L1<-rot3(L1)
    ...lget(6), ...lget(6), ...shuffleBytes(SHUFFLE_ROT1), ...lset(6),
    ...lget(5), ...lget(5), ...shuffleBytes(SHUFFLE_ROT2), ...lset(5),
    ...lget(4), ...lget(4), ...shuffleBytes(SHUFFLE_ROT3), ...lset(4),
    // Row round: (L0, L3, L2, L1)
    ...salsaRoundSimd(3, 6, 5, 4),
    // Un-shuffle back: L3<-rot3(L3), L2<-rot2(L2), L1<-rot1(L1)
    ...lget(6), ...lget(6), ...shuffleBytes(SHUFFLE_ROT3), ...lset(6),
    ...lget(5), ...lget(5), ...shuffleBytes(SHUFFLE_ROT2), ...lset(5),
    ...lget(4), ...lget(4), ...shuffleBytes(SHUFFLE_ROT1), ...lset(4),
    ...lget(2), ...i32c(2), OP.i32_add, ...lset(2),
    OP.br, 0,
    OP.end,
    OP.end,
    // Add original and store back
    ...lget(0), ...lget(0), ...ld128(0), ...lget(3), ...i32x4Add(), ...st128(0),
    ...lget(0), ...lget(0), ...ld128(16), ...lget(4), ...i32x4Add(), ...st128(16),
    ...lget(0), ...lget(0), ...ld128(32), ...lget(5), ...i32x4Add(), ...st128(32),
    ...lget(0), ...lget(0), ...ld128(48), ...lget(6), ...i32x4Add(), ...st128(48),
    OP.end,
  ];

  // --- Func 1: blockmixSalsa_simd(bPtr: 0, rounds: 1) ---
  const f1: number[] = [
    ...uleb(0),
  ];
  for (let v = 0; v < 4; v++) {
    f1.push(...i32c(PTR_SALSA_B), ...lget(0), ...ld128(64 + v * 16), ...st128(v * 16));
  }
  for (let i = 0; i < 2; i++) {
    const off = i * 64;
    for (let v = 0; v < 4; v++) {
      f1.push(
        ...i32c(PTR_SALSA_B),
        ...i32c(PTR_SALSA_B), ...ld128(v * 16),
        ...lget(0), ...ld128(off + v * 16),
        ...vxor(),
        ...st128(v * 16)
      );
    }
    f1.push(...i32c(PTR_SALSA_B), ...lget(1), OP.call, 0);
    for (let v = 0; v < 4; v++) {
      f1.push(...lget(0), ...i32c(PTR_SALSA_B), ...ld128(v * 16), ...st128(off + v * 16));
    }
  }
  f1.push(OP.end);

  // --- Func 2: blockmixPwxform_simd(bPtr: 0, r: 1) ---
  // Inlines pwxformV1 directly using 4 v128 registers (X0..X3) kept hot in registers across 2*r blocks!
  // Locals i32:
  //   2=r1, 3=i, 4=curOff, 5=s0PtrBase, 6=s1PtrBase, 7=sMask, 8=w, 9=s0Ptr, 10=s1Ptr, 11=tmpS
  // Locals v128:
  //   12=X0, 13=X1, 14=X2, 15=X3, 16=lo32, 17=hi32
  const pwxSimdStep = (j: number, doWrite: boolean) => {
    const xReg = 12 + j;
    const ops: number[] = [
      // s0Ptr = s0PtrBase + (extract_lane_0(xReg) & sMask)
      ...lget(xReg), ...lane32(0), ...lget(7), OP.i32_and, ...lget(5), OP.i32_add, ...lset(9),
      // s1Ptr = s1PtrBase + (extract_lane_1(xReg) & sMask)
      ...lget(xReg), ...lane32(1), ...lget(7), OP.i32_and, ...lget(6), OP.i32_add, ...lset(10),
      // lo32 = shuffle(xReg, xReg, SHUFFLE_LO32)
      ...lget(xReg), ...lget(xReg), ...shuffleBytes(SHUFFLE_LO32), ...lset(16),
      // hi32 = shuffle(xReg, xReg, SHUFFLE_HI32)
      ...lget(xReg), ...lget(xReg), ...shuffleBytes(SHUFFLE_HI32), ...lset(17),
      // xReg = (i64x2.extmul_low_u(lo32, hi32) + v128.load(s0Ptr)) ^ v128.load(s1Ptr)
      ...lget(16), ...lget(17), ...i64x2ExtmulLoU(),
      ...lget(9), ...ld128(0),
      ...i64x2Add(),
      ...lget(10), ...ld128(0),
      ...vxor(),
      ...ltee(xReg),
    ];
    if (doWrite) {
      if ((j & 1) === 0) {
        ops.push(
          ...lget(5), ...lget(8), OP.i32_add,
          ...lget(xReg),
          ...st128(0)
        );
      } else {
        ops.push(
          ...lget(6), ...lget(8), OP.i32_add,
          ...lget(xReg),
          ...st128(0),
          ...lget(8), ...i32c(16), OP.i32_add, ...lset(8)
        );
      }
    } else {
      ops.push(0x1a); // drop ltee value
    }
    return ops;
  };

  const f2: number[] = [
    ...uleb(2),
    ...uleb(10), I32,
    ...uleb(6), V128,
    // r1 = 2 * r
    ...lget(1), ...i32c(1), OP.i32_shl, ...ltee(2),
    // curOff = bPtr + (r1 - 1) * 64
    ...i32c(1), OP.i32_sub, ...i32c(6), OP.i32_shl, ...lget(0), OP.i32_add, ...lset(4),
    // Load X0..X3 from B[lastOff]
    ...lget(4), ...ld128(0), ...lset(12),
    ...lget(4), ...ld128(16), ...lset(13),
    ...lget(4), ...ld128(32), ...lset(14),
    ...lget(4), ...ld128(48), ...lset(15),
    // Load pwx globals into locals
    ...gget(4), ...lset(7), // sMask
    ...gget(3), ...lset(8), // w
    ...gget(0), ...i32c(PTR_S), OP.i32_add, ...lset(5),
    ...gget(1), ...i32c(PTR_S), OP.i32_add, ...lset(6),

    // for i = 0..r1-1
    ...i32c(0), ...lset(3),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(3), ...lget(2), OP.i32_ge_u, OP.br_if, 1,
    ...lget(0), ...lget(3), ...i32c(6), OP.i32_shl, OP.i32_add, ...lset(4),
    ...lget(2), ...i32c(1), OP.i32_gt_u,
    OP.if_, VOID,
    ...lget(12), ...lget(4), ...ld128(0), ...vxor(), ...lset(12),
    ...lget(13), ...lget(4), ...ld128(16), ...vxor(), ...lset(13),
    ...lget(14), ...lget(4), ...ld128(32), ...vxor(), ...lset(14),
    ...lget(15), ...lget(4), ...ld128(48), ...vxor(), ...lset(15),
    OP.end,

    // Inlined 3 rounds of pwxformV1
    ...pwxSimdStep(0, true),
    ...pwxSimdStep(1, true),
    ...pwxSimdStep(2, true),
    ...pwxSimdStep(3, true),
    ...pwxSimdStep(0, true),
    ...pwxSimdStep(1, true),
    ...pwxSimdStep(2, false),
    ...pwxSimdStep(3, false),
    ...pwxSimdStep(0, true),
    ...pwxSimdStep(1, true),
    ...pwxSimdStep(2, false),
    ...pwxSimdStep(3, false),

    // Rotate s0/s1/s2 bases and wrap w
    ...lget(5), ...lset(11), // tmpS = s0PtrBase
    ...gget(2), ...i32c(PTR_S), OP.i32_add, ...lset(5), // s0 = s2
    ...lget(6), ...i32c(PTR_S), OP.i32_sub, ...gset(2), // global s2 = old s1 - PTR_S
    ...lget(11), ...lset(6), // s1 = old s0
    ...lget(5), ...i32c(PTR_S), OP.i32_sub, ...gset(0),
    ...lget(6), ...i32c(PTR_S), OP.i32_sub, ...gset(1),
    ...lget(8), ...gget(5), OP.i32_and, ...lset(8),

    // Store X0..X3 into B[i*64]
    ...lget(4), ...lget(12), ...st128(0),
    ...lget(4), ...lget(13), ...st128(16),
    ...lget(4), ...lget(14), ...st128(32),
    ...lget(4), ...lget(15), ...st128(48),

    ...lget(3), ...i32c(1), OP.i32_add, ...lset(3),
    OP.br, 0,
    OP.end,
    OP.end,

    // Persist pwxW global
    ...lget(8), ...gset(3),

    // i = r1 - 1; salsa20_simd(bPtr + i * 64, 2)
    ...lget(2), ...i32c(1), OP.i32_sub, ...ltee(3),
    ...i32c(6), OP.i32_shl, ...lget(0), OP.i32_add, ...i32c(2), OP.call, 0,
    // for (i++; i < 2*r; i++)
    ...lget(3), ...i32c(1), OP.i32_add, ...lset(3),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(3), ...lget(2), OP.i32_ge_u, OP.br_if, 1,
    ...lget(0), ...lget(3), ...i32c(6), OP.i32_shl, OP.i32_add, ...lset(4),
    ...lget(4), ...lget(4), ...ld128(0), ...lget(4), ...i32c(64), OP.i32_sub, ...ld128(0), ...vxor(), ...st128(0),
    ...lget(4), ...lget(4), ...ld128(16), ...lget(4), ...i32c(64), OP.i32_sub, ...ld128(16), ...vxor(), ...st128(16),
    ...lget(4), ...lget(4), ...ld128(32), ...lget(4), ...i32c(64), OP.i32_sub, ...ld128(32), ...vxor(), ...st128(32),
    ...lget(4), ...lget(4), ...ld128(48), ...lget(4), ...i32c(64), OP.i32_sub, ...ld128(48), ...vxor(), ...st128(48),
    ...lget(4), ...i32c(2), OP.call, 0,
    ...lget(3), ...i32c(1), OP.i32_add, ...lset(3),
    OP.br, 0,
    OP.end,
    OP.end,
    OP.end,
  ];

  // 128-byte SIMD copy/xor loops (sBytes is always 128 * r)
  const copyLoopSimd = (srcLocal: number, dstLocal: number, sBytesLocal: number, idxLocal: number) => {
    const ops: number[] = [
      ...i32c(0), ...lset(idxLocal),
      OP.block, VOID,
      OP.loop, VOID,
      ...lget(idxLocal), ...lget(sBytesLocal), OP.i32_ge_u, OP.br_if, 1,
    ];
    for (let v = 0; v < 8; v++) {
      ops.push(
        ...lget(dstLocal), ...lget(idxLocal), OP.i32_add,
        ...lget(srcLocal), ...lget(idxLocal), OP.i32_add, ...ld128(v * 16),
        ...st128(v * 16)
      );
    }
    ops.push(
      ...lget(idxLocal), ...i32c(128), OP.i32_add, ...lset(idxLocal),
      OP.br, 0,
      OP.end,
      OP.end
    );
    return ops;
  };

  const xorLoopSimd = (dstLocal: number, srcLocal: number, sBytesLocal: number, idxLocal: number) => {
    const ops: number[] = [
      ...i32c(0), ...lset(idxLocal),
      OP.block, VOID,
      OP.loop, VOID,
      ...lget(idxLocal), ...lget(sBytesLocal), OP.i32_ge_u, OP.br_if, 1,
    ];
    for (let v = 0; v < 8; v++) {
      ops.push(
        ...lget(dstLocal), ...lget(idxLocal), OP.i32_add,
        ...lget(dstLocal), ...lget(idxLocal), OP.i32_add, ...ld128(v * 16),
        ...lget(srcLocal), ...lget(idxLocal), OP.i32_add, ...ld128(v * 16),
        ...vxor(),
        ...st128(v * 16)
      );
    }
    ops.push(
      ...lget(idxLocal), ...i32c(128), OP.i32_add, ...lset(idxLocal),
      OP.br, 0,
      OP.end,
      OP.end
    );
    return ops;
  };

  // --- Func 3: smix1_simd(r: 0, N: 1, vPtr: 2, isSInit: 3) ---
  const f3: number[] = [
    ...uleb(1),
    ...uleb(11), I32,
    ...lget(0), ...i32c(7), OP.i32_shl, ...lset(4),
    ...lget(0), ...i32c(1), OP.i32_shl, ...ltee(14),
    ...i32c(1), OP.i32_sub, ...i32c(6), OP.i32_shl, ...lset(7),

    // Permute B -> X
    ...i32c(0), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(14), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(6), OP.i32_shl, ...lset(9),
    ...lget(9), ...i32c(PTR_X), OP.i32_add, ...lset(8),
    ...(() => {
      const ps: number[] = [];
      for (let i = 0; i < 16; i++) {
        const bOff = ((i * 5) & 15) * 4;
        ps.push(...lget(8), ...lget(9), ...ld32(bOff), ...st32(i * 4));
      }
      return ps;
    })(),
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,

    // Initial r expansion
    ...i32c(1), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(0), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(7), OP.i32_shl, ...i32c(PTR_X), OP.i32_add, ...ltee(8),
    ...i32c(128), OP.i32_sub, ...lset(9),
    ...i32c(128), ...lset(10),
    ...copyLoopSimd(9, 8, 10, 6),
    ...lget(8), ...i32c(1), OP.call, 2,
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,

    // Main N loop
    ...i32c(0), ...lset(6),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(6), ...lget(1), OP.i32_ge_u, OP.br_if, 1,
    ...i32c(PTR_X), ...lset(9),
    ...lget(2), ...lget(6), ...lget(4), OP.i32_mul, OP.i32_add, ...lset(8),
    ...copyLoopSimd(9, 8, 4, 5),

    ...lget(6), ...i32c(1), OP.i32_gt_u,
    OP.if_, VOID,
    ...lget(6), ...lset(11),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(11), ...lget(11), ...i32c(1), OP.i32_sub, OP.i32_and, ...ltee(12),
    OP.i32_eqz, OP.br_if, 1,
    ...lget(12), ...lset(11),
    OP.br, 0,
    OP.end,
    OP.end,
    ...lget(7), ...i32c(PTR_X), OP.i32_add, ...ld32(0),
    ...lget(11), ...i32c(1), OP.i32_sub, OP.i32_and,
    ...lget(6), ...lget(11), OP.i32_sub, OP.i32_add,
    ...lget(4), OP.i32_mul, ...lget(2), OP.i32_add, ...lset(9),
    ...i32c(PTR_X), ...lset(8),
    ...xorLoopSimd(8, 9, 4, 5),
    OP.end,

    ...lget(3), OP.i32_eqz,
    OP.if_, VOID,
    ...i32c(PTR_X), ...lget(0), OP.call, 2,
    0x05, // else
    ...i32c(PTR_X), ...i32c(2), OP.call, 1,
    OP.end,

    ...lget(6), ...i32c(1), OP.i32_add, ...lset(6),
    OP.br, 0,
    OP.end,
    OP.end,

    // Unpermute X -> B
    ...i32c(0), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(14), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(6), OP.i32_shl, ...ltee(8),
    ...i32c(PTR_X), OP.i32_add, ...lset(9),
    ...(() => {
      const ps: number[] = [];
      for (let i = 0; i < 16; i++) {
        const bOff = ((i * 5) & 15) * 4;
        ps.push(...lget(8), ...lget(9), ...ld32(i * 4), ...st32(bOff));
      }
      return ps;
    })(),
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,
    OP.end,
  ];

  // --- Func 4: smix2_simd(r: 0, N: 1, Nloop: 2, vPtr: 3) ---
  const f4: number[] = [
    ...uleb(1),
    ...uleb(9), I32,
    ...lget(0), ...i32c(7), OP.i32_shl, ...lset(4),
    ...lget(0), ...i32c(1), OP.i32_shl, ...ltee(11),
    ...i32c(1), OP.i32_sub, ...i32c(6), OP.i32_shl, ...lset(7),
    ...lget(1), ...i32c(1), OP.i32_sub, ...lset(10),
    ...lget(2), ...i32c(2), OP.i32_ne, ...lset(12),

    // Permute B -> X
    ...i32c(0), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(11), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(6), OP.i32_shl, ...lset(9),
    ...lget(9), ...i32c(PTR_X), OP.i32_add, ...lset(8),
    ...(() => {
      const ps: number[] = [];
      for (let i = 0; i < 16; i++) {
        const bOff = ((i * 5) & 15) * 4;
        ps.push(...lget(8), ...lget(9), ...ld32(bOff), ...st32(i * 4));
      }
      return ps;
    })(),
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,

    // for i = 0..Nloop-1
    ...i32c(0), ...lset(6),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(6), ...lget(2), OP.i32_ge_u, OP.br_if, 1,
    ...lget(7), ...i32c(PTR_X), OP.i32_add, ...ld32(0), ...lget(10), OP.i32_and,
    ...lget(4), OP.i32_mul, ...lget(3), OP.i32_add, ...lset(9),
    ...i32c(PTR_X), ...lset(8),
    ...xorLoopSimd(8, 9, 4, 5),
    ...lget(12),
    OP.if_, VOID,
    ...copyLoopSimd(8, 9, 4, 5),
    OP.end,
    ...i32c(PTR_X), ...lget(0), OP.call, 2,
    ...lget(6), ...i32c(1), OP.i32_add, ...lset(6),
    OP.br, 0,
    OP.end,
    OP.end,

    // Unpermute X -> B
    ...i32c(0), ...lset(5),
    OP.block, VOID,
    OP.loop, VOID,
    ...lget(5), ...lget(11), OP.i32_ge_u, OP.br_if, 1,
    ...lget(5), ...i32c(6), OP.i32_shl, ...ltee(8),
    ...i32c(PTR_X), OP.i32_add, ...lset(9),
    ...(() => {
      const ps: number[] = [];
      for (let i = 0; i < 16; i++) {
        const bOff = ((i * 5) & 15) * 4;
        ps.push(...lget(8), ...lget(9), ...ld32(i * 4), ...st32(bOff));
      }
      return ps;
    })(),
    ...lget(5), ...i32c(1), OP.i32_add, ...lset(5),
    OP.br, 0,
    OP.end,
    OP.end,
    OP.end,
  ];

  // --- Func 5: smixAll(N: 0, r: 1, nLoopRw: 2, nLoopRo: 3, sN: 4) ---
  const f5: number[] = [
    ...uleb(0),
    ...i32c(0), ...gset(0),
    ...i32c(32768), ...gset(1),
    ...i32c(65536), ...gset(2),
    ...i32c(0), ...gset(3),
    ...i32c(1), ...lget(4), ...i32c(PTR_S), ...i32c(1), OP.call, 3,
    ...lget(1), ...lget(0), ...i32c(PTR_V), ...i32c(0), OP.call, 3,
    ...lget(1), ...lget(0), ...lget(2), ...i32c(PTR_V), OP.call, 4,
    ...lget(1), ...lget(0), ...lget(3), ...i32c(PTR_V), OP.call, 4,
    OP.end,
  ];

  const bodies = [f0, f1, f2, f3, f4, f5];
  const codeBody: number[] = [...uleb(bodies.length)];
  for (const b of bodies) {
    codeBody.push(...uleb(b.length), ...b);
  }
  const codeSec = section(10, codeBody);

  return new Uint8Array([
    0x00, 0x61, 0x73, 0x6d,
    0x01, 0x00, 0x00, 0x00,
    ...typeSec,
    ...importSec,
    ...funcSec,
    ...globalSec,
    ...exportSec,
    ...codeSec,
  ]);
}

let cachedSimdModule: WebAssembly.Module | null = null;

export function createYespowerV1WasmSimd(targetPages = INITIAL_PAGES): YespowerWasmSmix | null {
  try {
    if (typeof WebAssembly === 'undefined') return null;
    if (!cachedSimdModule) {
      const bytes = buildYespowerV1WasmSimdBytes();
      if (!WebAssembly.validate(bytes as unknown as BufferSource)) {
        return null;
      }
      cachedSimdModule = new WebAssembly.Module(bytes as unknown as BufferSource);
    }
    const desired = Math.max(MIN_SIMD_PAGES, Math.round(targetPages));
    const candidates = [desired, 192, 160, 140, MIN_SIMD_PAGES].filter(
      (p, idx, arr) => p <= desired && arr.indexOf(p) === idx
    );
    for (const pages of candidates) {
      try {
        const memory = new WebAssembly.Memory({ initial: pages });
        const instance = new WebAssembly.Instance(cachedSimdModule, { env: { memory } });
        const smixAll = instance.exports.smixAll as (
          N: number,
          r: number,
          nLoopRw: number,
          nLoopRo: number,
          sN: number
        ) => void;
        return {
          memU8: new Uint8Array(memory.buffer),
          smixAll,
        };
      } catch {
        // Step down memory pages on OOM / allocation failure
      }
    }
    return null;
  } catch {
    return null;
  }
}
