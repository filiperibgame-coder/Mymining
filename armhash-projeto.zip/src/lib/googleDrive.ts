import { getApp, getApps, initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  type User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export const SCOPES = ['https://www.googleapis.com/auth/drive.file'] as const;

const DRIVE_FOLDER_NAME = 'ARMHash Minerador';
const DRIVE_FILES_API = 'https://www.googleapis.com/drive/v3/files';
const DRIVE_UPLOAD_API = 'https://www.googleapis.com/upload/drive/v3/files';

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
for (const scope of SCOPES) {
  provider.addScope(scope);
}

// Strict in-memory token cache (never stored in localStorage/sessionStorage)
let isSigningIn = false;
let cachedAccessToken: string | null = null;

export interface DriveFileEntry {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  modifiedTime?: string;
  webViewLink?: string;
}

export interface DriveFolderInfo {
  id: string;
  name: string;
  webViewLink?: string;
}

export interface ArmhashDriveBackup {
  app: 'ARMHash';
  schemaVersion: 1;
  savedAt: string;
  appUrl: string;
  wallet: {
    coin: string;
    address: string;
  };
  stratum: {
    host: string;
    port: string;
    worker: string;
    password: string;
  };
  minerConfig: {
    algorithm: string;
    powerProfile: string;
    threads: number;
    dutyCycle: number;
  };
  sessionSummary: {
    acceptedCount: number;
    rejectedCount: number;
    totalHashes: number;
    recentProofs: Array<{
      time: string;
      algorithm: string;
      jobId: string;
      nonceHex: string;
      digestHex: string;
      status: string;
    }>;
  };
}

export class DriveAuthExpiredError extends Error {
  constructor(message = 'Sessão do Google Drive expirada. Entre novamente.') {
    super(message);
    this.name = 'DriveAuthExpiredError';
  }
}

export function initGoogleDriveAuth(
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
): () => void {
  return onAuthStateChanged(auth, (user) => {
    if (user) {
      if (cachedAccessToken) {
        onAuthSuccess?.(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        onAuthFailure?.();
      }
    } else {
      cachedAccessToken = null;
      onAuthFailure?.();
    }
  });
}

export async function googleDriveSignIn(): Promise<{ user: User; accessToken: string }> {
  isSigningIn = true;
  try {
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Não foi possível obter o token de acesso do Google Drive.');
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } finally {
    isSigningIn = false;
  }
}

export function getGoogleDriveAccessToken(): string | null {
  return cachedAccessToken;
}

export function clearGoogleDriveToken(): void {
  cachedAccessToken = null;
}

export async function googleDriveLogout(): Promise<void> {
  cachedAccessToken = null;
  await auth.signOut();
}

async function driveFetch(url: string, token: string, init?: RequestInit): Promise<Response> {
  const resp = await fetch(url, {
    ...init,
    headers: {
      ...(init?.headers ?? {}),
      Authorization: `Bearer ${token}`,
    },
  });
  if (resp.status === 401) {
    cachedAccessToken = null;
    throw new DriveAuthExpiredError();
  }
  return resp;
}

async function parseDriveError(resp: Response, fallback: string): Promise<string> {
  try {
    const data = await resp.json();
    const msg = data?.error?.message;
    if (typeof msg === 'string' && msg.trim()) return msg;
  } catch {
    // ignore
  }
  return fallback;
}

export async function ensureArmhashFolder(token: string): Promise<DriveFolderInfo> {
  const query = `name = '${DRIVE_FOLDER_NAME}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
  const searchUrl = `${DRIVE_FILES_API}?q=${encodeURIComponent(query)}&spaces=drive&fields=files(id,name,webViewLink)&pageSize=5`;
  const searchResp = await driveFetch(searchUrl, token);
  if (!searchResp.ok) {
    throw new Error(await parseDriveError(searchResp, 'Erro ao consultar pasta no Google Drive.'));
  }
  const searchData = (await searchResp.json()) as { files?: DriveFolderInfo[] };
  if (searchData.files && searchData.files.length > 0) {
    return searchData.files[0];
  }

  const createResp = await driveFetch(`${DRIVE_FILES_API}?fields=id,name,webViewLink`, token, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: DRIVE_FOLDER_NAME,
      mimeType: 'application/vnd.google-apps.folder',
      description: 'Backups, configurações e instaladores Android do ARMHash',
    }),
  });
  if (!createResp.ok) {
    throw new Error(await parseDriveError(createResp, 'Erro ao criar pasta ARMHash Minerador no Google Drive.'));
  }
  return (await createResp.json()) as DriveFolderInfo;
}

export async function listArmhashDriveFiles(token: string, folderId: string): Promise<DriveFileEntry[]> {
  const query = `'${folderId}' in parents and trashed = false`;
  const url = `${DRIVE_FILES_API}?q=${encodeURIComponent(query)}&orderBy=modifiedTime desc&fields=files(id,name,mimeType,size,modifiedTime,webViewLink)&pageSize=50`;
  const resp = await driveFetch(url, token);
  if (!resp.ok) {
    throw new Error(await parseDriveError(resp, 'Erro ao listar arquivos no Google Drive.'));
  }
  const data = (await resp.json()) as { files?: DriveFileEntry[] };
  return data.files ?? [];
}

function buildMultipartBody(
  metadata: Record<string, unknown>,
  content: string,
  mimeType: string
): { body: string; contentType: string } {
  const boundary = `armhash_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const body =
    `--${boundary}\r\n` +
    `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
    `${JSON.stringify(metadata)}\r\n` +
    `--${boundary}\r\n` +
    `Content-Type: ${mimeType}; charset=UTF-8\r\n\r\n` +
    `${content}\r\n` +
    `--${boundary}--`;
  return {
    body,
    contentType: `multipart/related; boundary=${boundary}`,
  };
}

export async function createDriveFile(
  token: string,
  folderId: string,
  name: string,
  content: string,
  mimeType: string
): Promise<DriveFileEntry> {
  const { body, contentType } = buildMultipartBody(
    {
      name,
      parents: [folderId],
      mimeType,
    },
    content,
    mimeType
  );
  const resp = await driveFetch(
    `${DRIVE_UPLOAD_API}?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink`,
    token,
    {
      method: 'POST',
      headers: { 'Content-Type': contentType },
      body,
    }
  );
  if (!resp.ok) {
    throw new Error(await parseDriveError(resp, `Erro ao salvar "${name}" no Google Drive.`));
  }
  return (await resp.json()) as DriveFileEntry;
}

export async function updateDriveFile(
  token: string,
  fileId: string,
  name: string,
  content: string,
  mimeType: string
): Promise<DriveFileEntry> {
  const { body, contentType } = buildMultipartBody(
    {
      name,
      mimeType,
    },
    content,
    mimeType
  );
  const resp = await driveFetch(
    `${DRIVE_UPLOAD_API}/${encodeURIComponent(fileId)}?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink`,
    token,
    {
      method: 'PATCH',
      headers: { 'Content-Type': contentType },
      body,
    }
  );
  if (!resp.ok) {
    throw new Error(await parseDriveError(resp, `Erro ao atualizar "${name}" no Google Drive.`));
  }
  return (await resp.json()) as DriveFileEntry;
}

function buildMultipartBinaryBody(
  metadata: Record<string, unknown>,
  bytes: ArrayBuffer,
  mimeType: string
): { body: Blob; contentType: string } {
  const boundary = `armhash_bin_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const header =
    `--${boundary}\r\n` +
    `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
    `${JSON.stringify(metadata)}\r\n` +
    `--${boundary}\r\n` +
    `Content-Type: ${mimeType}\r\n\r\n`;
  const footer = `\r\n--${boundary}--`;
  return {
    body: new Blob([header, bytes, footer]),
    contentType: `multipart/related; boundary=${boundary}`,
  };
}

export async function createDriveBinaryFile(
  token: string,
  folderId: string,
  name: string,
  bytes: ArrayBuffer,
  mimeType: string
): Promise<DriveFileEntry> {
  const { body, contentType } = buildMultipartBinaryBody(
    {
      name,
      parents: [folderId],
      mimeType,
    },
    bytes,
    mimeType
  );
  const resp = await driveFetch(
    `${DRIVE_UPLOAD_API}?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink`,
    token,
    {
      method: 'POST',
      headers: { 'Content-Type': contentType },
      body,
    }
  );
  if (!resp.ok) {
    throw new Error(await parseDriveError(resp, `Erro ao salvar "${name}" no Google Drive.`));
  }
  return (await resp.json()) as DriveFileEntry;
}

export async function updateDriveBinaryFile(
  token: string,
  fileId: string,
  name: string,
  bytes: ArrayBuffer,
  mimeType: string
): Promise<DriveFileEntry> {
  const { body, contentType } = buildMultipartBinaryBody(
    {
      name,
      mimeType,
    },
    bytes,
    mimeType
  );
  const resp = await driveFetch(
    `${DRIVE_UPLOAD_API}/${encodeURIComponent(fileId)}?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink`,
    token,
    {
      method: 'PATCH',
      headers: { 'Content-Type': contentType },
      body,
    }
  );
  if (!resp.ok) {
    throw new Error(await parseDriveError(resp, `Erro ao atualizar "${name}" no Google Drive.`));
  }
  return (await resp.json()) as DriveFileEntry;
}

export async function downloadDriveFileText(token: string, fileId: string): Promise<string> {
  const resp = await driveFetch(`${DRIVE_FILES_API}/${encodeURIComponent(fileId)}?alt=media`, token);
  if (!resp.ok) {
    throw new Error(await parseDriveError(resp, 'Erro ao baixar arquivo do Google Drive.'));
  }
  return await resp.text();
}

export async function deleteDriveFile(token: string, fileId: string): Promise<void> {
  const resp = await driveFetch(`${DRIVE_FILES_API}/${encodeURIComponent(fileId)}`, token, {
    method: 'DELETE',
  });
  if (!resp.ok && resp.status !== 204) {
    throw new Error(await parseDriveError(resp, 'Erro ao excluir arquivo no Google Drive.'));
  }
}

function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function buildPortableLauncherHtml(backup: ArmhashDriveBackup): string {
  const safeUrl = escapeHtml(backup.appUrl);
  const safeCoin = escapeHtml(backup.wallet.coin);
  const safeAddr = escapeHtml(backup.wallet.address || 'Não configurada');
  const safeHost = escapeHtml(backup.stratum.host);
  const safePort = escapeHtml(backup.stratum.port);
  const safePass = escapeHtml(backup.stratum.password);
  const safeAlgo = escapeHtml(backup.minerConfig.algorithm);
  const safeSavedAt = escapeHtml(new Date(backup.savedAt).toLocaleString('pt-BR'));

  return `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ARMHash — Atalho e Backup Android</title>
  <style>
    body { margin: 0; font-family: system-ui, -apple-system, sans-serif; background: #0B0F14; color: #E2E8F0; padding: 24px; }
    .wrap { max-width: 720px; margin: 0 auto; }
    .card { background: #121821; border: 1px solid #1E293B; border-radius: 14px; padding: 20px; margin-bottom: 16px; }
    h1 { margin: 0 0 8px; font-size: 22px; color: #F8FAFC; }
    h2 { margin: 0 0 10px; font-size: 16px; color: #34D399; }
    p, li { font-size: 14px; line-height: 1.55; color: #CBD5E1; }
    .btn { display: inline-block; background: #059669; color: #FFF; text-decoration: none; padding: 12px 18px; border-radius: 10px; font-weight: 600; font-size: 14px; }
    code, pre { font-family: ui-monospace, SFMono-Regular, monospace; background: #0B0F14; border: 1px solid #1E293B; border-radius: 8px; }
    code { padding: 2px 6px; font-size: 12px; }
    pre { padding: 14px; overflow-x: auto; font-size: 12px; color: #A7F3D0; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>ARMHash — Minerador Android ARM</h1>
      <p>Snapshot salvo no seu Google Drive em <strong>${safeSavedAt}</strong>.</p>
      <p><a class="btn" href="${safeUrl}" target="_blank" rel="noopener noreferrer">Abrir ARMHash Online (Instalar PWA no Android)</a></p>
      <p>Link direto: <code>${safeUrl}</code></p>
      <p>No celular Android, abra o link acima no <strong>Google Chrome</strong> e toque em <strong>Menu (⋮) → Instalar aplicativo</strong>.</p>
    </div>
    <div class="card">
      <h2>Configuração Salva</h2>
      <p><strong>Moeda:</strong> ${safeCoin}<br/>
         <strong>Carteira:</strong> <code>${safeAddr}</code><br/>
         <strong>Pool Stratum:</strong> <code>${safeHost}:${safePort}</code><br/>
         <strong>Parâmetros:</strong> <code>${safePass}</code><br/>
         <strong>Algoritmo:</strong> <code>${safeAlgo}</code></p>
    </div>
    <div class="card">
      <h2>Comando Rápido Termux ARM64 (Opcional)</h2>
      <pre>pkg update -y && pkg install -y clang termux-api
bash termux_miner.sh</pre>
    </div>
  </div>
</body>
</html>`;
}
