import React from 'react';
import { formatHashrate } from '../lib/ecoEngine';

export interface HashSample {
  ts: number;
  hps: number;
}

interface HashChartProps {
  samples: HashSample[];
  active: boolean;
}

export const HashChart: React.FC<HashChartProps> = ({ samples, active }) => {
  const width = 640;
  const height = 200;
  const padL = 58;
  const padR = 14;
  const padT = 16;
  const padB = 26;
  const plotW = width - padL - padR;
  const plotH = height - padT - padB;

  const maxVal = Math.max(100, ...samples.map((s) => s.hps));
  const yMax = Math.ceil(maxVal * 1.15);

  const pts = samples.map((s, idx) => {
    const x =
      samples.length <= 1
        ? padL + plotW
        : padL + (idx / (samples.length - 1)) * plotW;
    const y = padT + plotH - (s.hps / yMax) * plotH;
    return { x, y };
  });

  const line =
    pts.length > 0
      ? pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ')
      : '';

  const area =
    pts.length > 1
      ? `${line} L ${pts[pts.length - 1].x.toFixed(1)} ${(padT + plotH).toFixed(1)} L ${pts[0].x.toFixed(1)} ${(padT + plotH).toFixed(1)} Z`
      : '';

  const ticks = [0, 0.5, 1].map((r) => ({
    val: yMax * r,
    y: padT + plotH - r * plotH,
  }));

  return (
    <div className="w-full">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-48 overflow-visible select-none"
        role="img"
        aria-label="Gráfico de taxa de hash em tempo real"
      >
        <defs>
          <linearGradient id="ecoChartGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#10B981" stopOpacity="0.28" />
            <stop offset="100%" stopColor="#10B981" stopOpacity="0" />
          </linearGradient>
        </defs>

        {ticks.map((t, i) => (
          <g key={i}>
            <line
              x1={padL}
              y1={t.y}
              x2={width - padR}
              y2={t.y}
              stroke="#1E293B"
              strokeDasharray={i === 0 ? undefined : '3 3'}
              strokeWidth="1"
            />
            <text
              x={padL - 8}
              y={t.y + 4}
              textAnchor="end"
              className="fill-slate-500 text-[10px] font-mono tabular-nums"
            >
              {formatHashrate(t.val).replace(' ', '')}
            </text>
          </g>
        ))}

        {area && <path d={area} fill="url(#ecoChartGrad)" />}

        {line && (
          <path
            d={line}
            fill="none"
            stroke="#10B981"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}

        {pts.length > 0 && active && (
          <circle
            cx={pts[pts.length - 1].x}
            cy={pts[pts.length - 1].y}
            r="3.5"
            fill="#10B981"
            stroke="#0B0F14"
            strokeWidth="1.5"
          />
        )}

        <text x={padL} y={height - 4} className="fill-slate-500 text-[10px] font-mono">
          -60s
        </text>
        <text
          x={width - padR}
          y={height - 4}
          textAnchor="end"
          className="fill-slate-500 text-[10px] font-mono"
        >
          Agora
        </text>
      </svg>

      {samples.length === 0 && (
        <p className="text-xs text-slate-400 text-center -mt-28 pb-20">
          Inicie a mineração para medir a taxa real dos núcleos do seu dispositivo.
        </p>
      )}
    </div>
  );
};
