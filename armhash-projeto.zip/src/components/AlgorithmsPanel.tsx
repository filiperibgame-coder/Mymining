import React, { useEffect, useRef, useState } from 'react';
import { Play, Square, Check } from 'lucide-react';
import { ALGORITHM_SPECS, createBlockHeader, formatHashrate } from '../lib/ecoEngine';
import type { MiningAlgorithm } from '../workers/miner.worker';

interface BenchResult {
  hps: number;
  hpw: number;
}

interface AlgorithmsPanelProps {
  activeAlgorithm: MiningAlgorithm;
  onSelectAlgorithm: (algo: MiningAlgorithm) => void;
  threads: number;
  dutyCycle: number;
  isMining: boolean;
}

export const AlgorithmsPanel: React.FC<AlgorithmsPanelProps> = ({
  activeAlgorithm,
  onSelectAlgorithm,
  threads,
  dutyCycle,
  isMining,
}) => {
  const [running, setRunning] = useState(false);
  const [currentAlgo, setCurrentAlgo] = useState<MiningAlgorithm | null>(null);
  const [results, setResults] = useState<Partial<Record<MiningAlgorithm, BenchResult>>>({});
  const workersRef = useRef<Worker[]>([]);
  const abortRef = useRef(false);

  const stopBench = () => {
    workersRef.current.forEach((w) => {
      w.postMessage({ type: 'stop' });
      w.terminate();
    });
    workersRef.current = [];
  };

  useEffect(() => {
    return () => {
      abortRef.current = true;
      stopBench();
    };
  }, []);

  const testAlgo = (algo: MiningAlgorithm): Promise<BenchResult> =>
    new Promise((resolve) => {
      const n = Math.max(1, threads);
      const { headerHex, jobId } = createBlockHeader(1, 20);
      let hashes = 0;
      const t0 = performance.now();

      for (let i = 0; i < n; i++) {
        const w = new Worker(new URL('../workers/miner.worker.ts', import.meta.url), {
          type: 'module',
        });
        w.onmessage = (e) => {
          if (e.data?.type === 'stats') hashes += Number(e.data.hashes ?? 0);
        };
        w.postMessage({
          type: 'start',
          workerId: i,
          algorithm: algo,
          headerHex,
          targetZeroBits: 28,
          startNonce: i,
          stride: n,
          dutyCycle,
          jobId,
        });
        workersRef.current.push(w);
      }

      window.setTimeout(() => {
        stopBench();
        const sec = Math.max(0.5, (performance.now() - t0) / 1000);
        const hps = hashes / sec;
        const watts = Math.max(0.25, n * ALGORITHM_SPECS[algo].wattsPerThread * (dutyCycle / 100));
        resolve({ hps, hpw: hps / watts });
      }, 2000);
    });

  const runSuite = async () => {
    if (isMining || running) return;
    abortRef.current = false;
    setRunning(true);
    const list: MiningAlgorithm[] = ['yespower_advc', 'yespower_sugar', 'blake3_eco', 'sha256d'];
    for (const algo of list) {
      if (abortRef.current) break;
      setCurrentAlgo(algo);
      const res = await testAlgo(algo);
      if (abortRef.current) break;
      setResults((prev) => ({ ...prev, [algo]: res }));
    }
    setCurrentAlgo(null);
    setRunning(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1E293B] pb-5">
        <div>
          <h2 className="text-xl font-semibold text-slate-100">
            Algoritmos Otimizados e Benchmark Real
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Teste os algoritmos diretamente no seu processador com {threads} thread(s) e {dutyCycle}% de ciclo.
          </p>
        </div>

        {!running ? (
          <button
            type="button"
            disabled={isMining}
            onClick={runSuite}
            className="min-h-[44px] px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-45 text-white text-sm font-medium flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            <Play className="w-4 h-4" />
            <span>{isMining ? 'Pause a mineração para testar' : 'Executar Benchmark (6s)'}</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => {
              abortRef.current = true;
              stopBench();
              setCurrentAlgo(null);
              setRunning(false);
            }}
            className="min-h-[44px] px-5 py-2 rounded-lg bg-amber-600 text-white text-sm font-medium flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            <Square className="w-4 h-4" />
            <span>Cancelar ({currentAlgo ? ALGORITHM_SPECS[currentAlgo].shortName : '...'})</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {Object.values(ALGORITHM_SPECS).map((spec) => {
          const active = activeAlgorithm === spec.id;
          const res = results[spec.id];
          const testing = currentAlgo === spec.id;

          return (
            <div
              key={spec.id}
              className={`rounded-xl bg-[#121821] border p-5 flex flex-col justify-between ${
                active ? 'border-emerald-500/70' : 'border-[#1E293B]'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-base font-semibold text-slate-100">{spec.name}</h3>
                  {active && (
                    <span className="text-xs font-medium text-emerald-400 flex items-center gap-1 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                      Ativo
                    </span>
                  )}
                </div>

                <p className="text-sm text-slate-300 mt-3 leading-relaxed">{spec.description}</p>

                <dl className="mt-4 pt-4 border-t border-[#1E293B] space-y-2 text-xs">
                  <div className="flex justify-between gap-2">
                    <dt className="text-slate-400">Cache</dt>
                    <dd className="text-slate-200 font-mono text-right">{spec.cacheUse}</dd>
                  </div>
                  <div className="flex justify-between gap-2">
                    <dt className="text-slate-400">Benefício ARM</dt>
                    <dd className="text-slate-200 text-right">{spec.armBenefit}</dd>
                  </div>
                </dl>

                <div className="mt-4 pt-4 border-t border-[#1E293B]">
                  {testing ? (
                    <p className="text-xs font-mono text-amber-400">Medindo throughput real...</p>
                  ) : res ? (
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-slate-400 block">Taxa Real</span>
                        <span className="text-base font-mono font-semibold text-emerald-400 tabular-nums">
                          {formatHashrate(res.hps)}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Eficiência Est.</span>
                        <span className="text-base font-mono font-semibold text-slate-100 tabular-nums">
                          {Math.round(res.hpw).toLocaleString('pt-BR')} H/W
                        </span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500">Sem medição ainda nesta sessão.</p>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={() => onSelectAlgorithm(spec.id)}
                className={`mt-5 w-full min-h-[44px] px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  active
                    ? 'bg-[#1C2532] text-slate-200 border border-[#2D3B4E]'
                    : 'bg-emerald-600/15 hover:bg-emerald-600/25 text-emerald-300 border border-emerald-500/30'
                }`}
              >
                {active ? 'Selecionado' : `Usar ${spec.shortName}`}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
