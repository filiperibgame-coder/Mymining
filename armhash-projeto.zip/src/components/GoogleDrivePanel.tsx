import React, { useCallback, useEffect, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  AlertTriangle,
  Check,
  CloudUpload,
  Copy,
  Download,
  ExternalLink,
  FileCode2,
  FolderOpen,
  HardDrive,
  LogOut,
  RefreshCw,
  RotateCcw,
  Save,
  Trash2,
} from 'lucide-react';
import { ARTIFACTS } from './AndroidExportPanel';
import {
  buildPortableLauncherHtml,
  clearGoogleDriveToken,
  createDriveBinaryFile,
  createDriveFile,
  deleteDriveFile,
  downloadDriveFileText,
  DriveAuthExpiredError,
  ensureArmhashFolder,
  getGoogleDriveAccessToken,
  googleDriveLogout,
  googleDriveSignIn,
  initGoogleDriveAuth,
  listArmhashDriveFiles,
  updateDriveBinaryFile,
  updateDriveFile,
  type ArmhashDriveBackup,
  type DriveFileEntry,
  type DriveFolderInfo,
} from '../lib/googleDrive';

interface GoogleDrivePanelProps {
  currentBackup: ArmhashDriveBackup;
  onRestoreBackup: (backup: ArmhashDriveBackup) => void;
}

interface PendingConfirmAction {
  title: string;
  description: string;
  confirmLabel: string;
  destructive?: boolean;
  run: (token: string) => Promise<void>;
}

function formatBytes(sizeStr?: string): string {
  const n = Number(sizeStr);
  if (!Number.isFinite(n) || n <= 0) return '—';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

function formatDate(iso?: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function mapFirebaseAuthError(err: unknown): string {
  const code = (err as { code?: string })?.code ?? '';
  if (code === 'auth/popup-blocked') {
    return 'Pop-up bloqueado pelo navegador. Libere pop-ups para entrar com sua conta Google.';
  }
  if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
    return 'Login cancelado antes da conclusão.';
  }
  if (code === 'auth/unauthorized-domain') {
    return 'Domínio atual não autorizado no provedor de login. Tente pelo link principal do app.';
  }
  return err instanceof Error ? err.message : 'Falha ao autenticar com o Google.';
}

export const GoogleDrivePanel: React.FC<GoogleDrivePanelProps> = ({
  currentBackup,
  onRestoreBackup,
}) => {
  const [needsAuth, setNeedsAuth] = useState<boolean>(() => !getGoogleDriveAccessToken());
  const [user, setUser] = useState<User | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const [folder, setFolder] = useState<DriveFolderInfo | null>(null);
  const [files, setFiles] = useState<DriveFileEntry[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [pendingConfirm, setPendingConfirm] = useState<PendingConfirmAction | null>(null);

  const appUrl = typeof window !== 'undefined' ? window.location.origin : currentBackup.appUrl;

  const refreshDrive = useCallback(async (tokenOverride?: string) => {
    const token = tokenOverride ?? getGoogleDriveAccessToken();
    if (!token) {
      setNeedsAuth(true);
      return;
    }
    setLoadingFiles(true);
    setErrorMsg(null);
    try {
      const f = await ensureArmhashFolder(token);
      setFolder(f);
      const list = await listArmhashDriveFiles(token, f.id);
      setFiles(list);
      setNeedsAuth(false);
    } catch (err) {
      if (err instanceof DriveAuthExpiredError) {
        setNeedsAuth(true);
      }
      setErrorMsg(err instanceof Error ? err.message : 'Erro ao carregar arquivos do Google Drive.');
    } finally {
      setLoadingFiles(false);
    }
  }, []);

  useEffect(() => {
    const unsub = initGoogleDriveAuth(
      (u, token) => {
        setUser(u);
        setNeedsAuth(false);
        void refreshDrive(token);
      },
      () => {
        setNeedsAuth(true);
      }
    );
    const existingToken = getGoogleDriveAccessToken();
    if (existingToken) {
      void refreshDrive(existingToken);
    }
    return () => unsub();
  }, [refreshDrive]);

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setErrorMsg(null);
    setStatusMsg(null);
    try {
      const result = await googleDriveSignIn();
      setUser(result.user);
      setNeedsAuth(false);
      await refreshDrive(result.accessToken);
      setStatusMsg('Conectado ao Google Drive com sucesso.');
    } catch (err) {
      setErrorMsg(mapFirebaseAuthError(err));
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleGoogleLogout = async () => {
    await googleDriveLogout();
    clearGoogleDriveToken();
    setUser(null);
    setFolder(null);
    setFiles([]);
    setNeedsAuth(true);
    setStatusMsg(null);
    setErrorMsg(null);
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 1800);
    } catch {
      // ignore
    }
  };

  const runDriveMutation = async (actionKey: string, fn: (token: string) => Promise<void>) => {
    const token = getGoogleDriveAccessToken();
    if (!token) {
      setNeedsAuth(true);
      setErrorMsg('Conecte sua conta Google antes de salvar no Drive.');
      return;
    }
    setBusyAction(actionKey);
    setErrorMsg(null);
    setStatusMsg(null);
    try {
      await fn(token);
      await refreshDrive(token);
    } catch (err) {
      if (err instanceof DriveAuthExpiredError) {
        setNeedsAuth(true);
      }
      setErrorMsg(err instanceof Error ? err.message : 'Falha na operação com o Google Drive.');
    } finally {
      setBusyAction(null);
    }
  };

  const handleSaveMainBackup = async () => {
    const token = getGoogleDriveAccessToken();
    if (!token) {
      setNeedsAuth(true);
      return;
    }
    const targetName = 'armhash-backup.json';
    const jsonContent = JSON.stringify({ ...currentBackup, appUrl }, null, 2);
    const activeFolder = folder ?? (await ensureArmhashFolder(token));
    const currentList = await listArmhashDriveFiles(token, activeFolder.id);
    const existing = currentList.find((f) => f.name === targetName);

    if (existing) {
      setPendingConfirm({
        title: `Atualizar "${targetName}" no Google Drive?`,
        description:
          'Já existe um backup principal na pasta ARMHash Minerador. Confirmar substituirá esse arquivo pela sua carteira, configurações Stratum e histórico atual.',
        confirmLabel: 'Confirmar Atualização',
        run: async (t) => {
          await updateDriveFile(t, existing.id, targetName, jsonContent, 'application/json');
          setStatusMsg(`Backup "${targetName}" atualizado no Google Drive.`);
        },
      });
      return;
    }

    await runDriveMutation('save-main', async (t) => {
      await createDriveFile(t, activeFolder.id, targetName, jsonContent, 'application/json');
      setStatusMsg(`Backup "${targetName}" salvo no Google Drive.`);
    });
  };

  const handleSaveTimestampedBackup = async () => {
    const now = new Date();
    const stamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
      now.getDate()
    ).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}-${String(
      now.getMinutes()
    ).padStart(2, '0')}-${String(now.getSeconds()).padStart(2, '0')}`;
    const filename = `armhash-backup-${stamp}.json`;
    const jsonContent = JSON.stringify({ ...currentBackup, appUrl }, null, 2);

    await runDriveMutation('save-snapshot', async (token) => {
      const activeFolder = folder ?? (await ensureArmhashFolder(token));
      await createDriveFile(token, activeFolder.id, filename, jsonContent, 'application/json');
      setStatusMsg(`Cópia "${filename}" salva no Google Drive.`);
    });
  };

  const handleSaveAndroidBundle = async () => {
    const token = getGoogleDriveAccessToken();
    if (!token) {
      setNeedsAuth(true);
      return;
    }
    const activeFolder = folder ?? (await ensureArmhashFolder(token));
    const currentList = await listArmhashDriveFiles(token, activeFolder.id);

    const launcherHtml = buildPortableLauncherHtml({ ...currentBackup, appUrl });
    const termuxSh = ARTIFACTS.find((a) => a.id === 'sh');
    const armC = ARTIFACTS.find((a) => a.id === 'c');

    const bundleItems = [
      {
        name: 'armhash-app-android.html',
        content: launcherHtml,
        mimeType: 'text/html',
      },
      ...(termuxSh
        ? [{ name: termuxSh.filename, content: termuxSh.code, mimeType: 'text/x-shellscript' }]
        : []),
      ...(armC ? [{ name: armC.filename, content: armC.code, mimeType: 'text/plain' }] : []),
    ];

    const existingMatches = bundleItems.filter((item) =>
      currentList.some((f) => f.name === item.name)
    );

    const executeBundleUpload = async (t: string) => {
      const fdr = folder ?? (await ensureArmhashFolder(t));
      const latest = await listArmhashDriveFiles(t, fdr.id);
      for (const item of bundleItems) {
        const match = latest.find((f) => f.name === item.name);
        if (match) {
          await updateDriveFile(t, match.id, item.name, item.content, item.mimeType);
        } else {
          await createDriveFile(t, fdr.id, item.name, item.content, item.mimeType);
        }
      }
      setStatusMsg(
        `${bundleItems.length} arquivos do pacote Android/Atalho salvos em "${fdr.name}".`
      );
    };

    if (existingMatches.length > 0) {
      setPendingConfirm({
        title: `Atualizar ${existingMatches.length} arquivo(s) no Google Drive?`,
        description: `Os seguintes arquivos já existem na pasta ARMHash Minerador e serão atualizados: ${existingMatches
          .map((m) => m.name)
          .join(', ')}.`,
        confirmLabel: 'Confirmar Atualização',
        run: executeBundleUpload,
      });
      return;
    }

    await runDriveMutation('save-bundle', executeBundleUpload);
  };

  const handleSaveProjectZipToDrive = async () => {
    const token = getGoogleDriveAccessToken();
    if (!token) {
      setNeedsAuth(true);
      return;
    }
    const targetName = 'armhash-projeto.zip';
    const activeFolder = folder ?? (await ensureArmhashFolder(token));
    const currentList = await listArmhashDriveFiles(token, activeFolder.id);
    const existing = currentList.find((f) => f.name === targetName);

    const uploadZip = async (t: string) => {
      const resp = await fetch('/api/export/zip');
      if (!resp.ok) {
        throw new Error('Falha ao gerar o arquivo .zip do projeto.');
      }
      const bytes = await resp.arrayBuffer();
      const fdr = folder ?? (await ensureArmhashFolder(t));
      if (existing) {
        await updateDriveBinaryFile(t, existing.id, targetName, bytes, 'application/zip');
        setStatusMsg(`Arquivo "${targetName}" atualizado no Google Drive.`);
      } else {
        await createDriveBinaryFile(t, fdr.id, targetName, bytes, 'application/zip');
        setStatusMsg(`Arquivo "${targetName}" salvo no Google Drive.`);
      }
    };

    if (existing) {
      setPendingConfirm({
        title: `Atualizar "${targetName}" no Google Drive?`,
        description:
          'Já existe um arquivo armhash-projeto.zip na pasta ARMHash Minerador. Confirmar substituirá o pacote ZIP pelo código atual do projeto.',
        confirmLabel: 'Confirmar Atualização',
        run: uploadZip,
      });
      return;
    }

    await runDriveMutation('save-zip', uploadZip);
  };

  const handleRestoreFile = async (file: DriveFileEntry) => {
    await runDriveMutation(`restore-${file.id}`, async (token) => {
      const raw = await downloadDriveFileText(token, file.id);
      const parsed = JSON.parse(raw) as ArmhashDriveBackup;
      if (!parsed || parsed.app !== 'ARMHash' || !parsed.wallet) {
        throw new Error(`O arquivo "${file.name}" não é um backup válido do ARMHash.`);
      }
      onRestoreBackup(parsed);
      setStatusMsg(`Configuração restaurada de "${file.name}".`);
    });
  };

  const requestDeleteFile = (file: DriveFileEntry) => {
    setPendingConfirm({
      title: `Excluir "${file.name}" do Google Drive?`,
      description:
        'Esta ação removerá o arquivo da sua pasta ARMHash Minerador no Google Drive e não pode ser desfeita.',
      confirmLabel: 'Confirmar Exclusão',
      destructive: true,
      run: async (token) => {
        await deleteDriveFile(token, file.id);
        setStatusMsg(`Arquivo "${file.name}" excluído do Google Drive.`);
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-[#1E293B] pb-5">
        <h2 className="text-xl font-semibold text-slate-100">
          Salvar e Sincronizar no Google Drive
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Guarde suas carteiras, configurações Stratum, atalho portátil e scripts Android/Termux com segurança na sua conta Google.
        </p>
      </div>

      {/* Live Web Hosting vs Google Drive Storage Info */}
      <section className="rounded-xl bg-[#121821] border border-[#1E293B] p-5 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-emerald-400" />
              <span>Endereço Ativo do Aplicativo (PWA + Stratum TCP)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              O Google Drive armazena backups e arquivos estáticos (ele não executa o conector Stratum em Node.js). Para minerar no celular Android, abra ou instale o app por este endereço publicado e salve seus backups no Drive abaixo.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0 self-start sm:self-center">
            <a
              href="/api/export/zip"
              download="armhash-projeto.zip"
              className="min-h-[40px] px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar Projeto (.zip)</span>
            </a>
            <button
              type="button"
              onClick={handleCopyUrl}
              className="min-h-[40px] px-3.5 py-2 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-medium text-slate-200 flex items-center gap-1.5"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedUrl ? 'Link copiado' : 'Copiar link do App'}</span>
            </button>
          </div>
        </div>
        <p className="text-xs font-mono text-emerald-300 bg-[#0B0F14] border border-[#1E293B] rounded-lg px-3 py-2 break-all">
          {appUrl}
        </p>
      </section>

      {errorMsg && (
        <div className="rounded-xl bg-rose-950/30 border border-rose-500/40 p-4 text-xs text-rose-300">
          {errorMsg}
        </div>
      )}

      {statusMsg && (
        <div className="rounded-xl bg-emerald-950/30 border border-emerald-500/40 p-4 text-xs text-emerald-300">
          {statusMsg}
        </div>
      )}

      {needsAuth ? (
        <section className="rounded-xl bg-[#121821] border border-[#1E293B] p-6 sm:p-8 flex flex-col items-center text-center space-y-4">
          <div className="w-12 h-12 rounded-xl bg-[#0B0F14] border border-[#1E293B] flex items-center justify-center">
            <CloudUpload className="w-6 h-6 text-emerald-400" />
          </div>
          <div className="max-w-md space-y-1.5">
            <h3 className="text-base font-semibold text-slate-100">
              Conectar sua conta Google Drive
            </h3>
            <p className="text-xs text-slate-400">
              O acesso fica restrito apenas à pasta e aos arquivos criados pelo ARMHash, com sua permissão explícita.
            </p>
          </div>

          <button
            type="button"
            disabled={isLoggingIn}
            onClick={handleGoogleLogin}
            className="min-h-[44px] px-5 py-2.5 rounded-full bg-white hover:bg-slate-100 text-[#1F1F1F] border border-[#747775] text-sm font-medium inline-flex items-center gap-3 shadow-sm transition-colors disabled:opacity-60"
          >
            <svg
              className="w-5 h-5 shrink-0"
              viewBox="0 0 48 48"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <path
                fill="#EA4335"
                d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
              />
              <path
                fill="#4285F4"
                d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
              />
              <path
                fill="#FBBC05"
                d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
              />
              <path
                fill="#34A853"
                d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
              />
            </svg>
            <span>{isLoggingIn ? 'Conectando...' : 'Sign in with Google'}</span>
          </button>
        </section>
      ) : (
        <>
          {/* Account & Save Actions */}
          <section className="rounded-xl bg-[#121821] border border-[#1E293B] p-5 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#1E293B]">
              <div>
                <p className="text-xs text-slate-400">Conta Google conectada</p>
                <p className="text-sm font-semibold text-slate-100 mt-0.5">
                  {user?.displayName ? `${user.displayName} · ` : ''}
                  <span className="font-mono text-emerald-400">{user?.email ?? 'Google Drive'}</span>
                </p>
                {folder && (
                  <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                    <FolderOpen className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Pasta: {folder.name}</span>
                  </p>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {folder?.webViewLink && (
                  <a
                    href={folder.webViewLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="min-h-[40px] px-3 py-1.5 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-medium text-slate-200 inline-flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Abrir Pasta no Drive</span>
                  </a>
                )}
                <button
                  type="button"
                  disabled={loadingFiles}
                  onClick={() => void refreshDrive()}
                  className="min-h-[40px] px-3 py-1.5 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-medium text-slate-200 inline-flex items-center gap-1.5 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingFiles ? 'animate-spin' : ''}`} />
                  <span>Atualizar</span>
                </button>
                <button
                  type="button"
                  onClick={handleGoogleLogout}
                  className="min-h-[40px] px-3 py-1.5 rounded-lg bg-[#1A222E] hover:bg-rose-950/50 border border-[#283344] text-xs font-medium text-slate-300 inline-flex items-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sair</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <button
                type="button"
                disabled={busyAction !== null}
                onClick={() => void handleSaveMainBackup()}
                className="min-h-[48px] px-4 py-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>
                  {busyAction === 'save-main' ? 'Salvando...' : 'Salvar Backup Principal (.json)'}
                </span>
              </button>

              <button
                type="button"
                disabled={busyAction !== null}
                onClick={() => void handleSaveTimestampedBackup()}
                className="min-h-[48px] px-4 py-3 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <CloudUpload className="w-4 h-4 text-emerald-400" />
                <span>
                  {busyAction === 'save-snapshot' ? 'Salvando...' : 'Salvar Nova Cópia com Data'}
                </span>
              </button>

              <button
                type="button"
                disabled={busyAction !== null}
                onClick={() => void handleSaveAndroidBundle()}
                className="min-h-[48px] px-4 py-3 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <FileCode2 className="w-4 h-4 text-sky-400" />
                <span>
                  {busyAction === 'save-bundle'
                    ? 'Enviando...'
                    : 'Salvar Atalho HTML + Scripts'}
                </span>
              </button>

              <button
                type="button"
                disabled={busyAction !== null}
                onClick={() => void handleSaveProjectZipToDrive()}
                className="min-h-[48px] px-4 py-3 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Download className="w-4 h-4 text-amber-400" />
                <span>
                  {busyAction === 'save-zip'
                    ? 'Enviando ZIP...'
                    : 'Salvar Projeto (.zip) no Drive'}
                </span>
              </button>
            </div>
          </section>

          {/* Saved Files List */}
          <section className="rounded-xl bg-[#121821] border border-[#1E293B] overflow-hidden">
            <div className="p-5 border-b border-[#1E293B] flex items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  Arquivos Salvos em &ldquo;{folder?.name ?? 'ARMHash Minerador'}&rdquo;
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Restaure carteiras de backups JSON ou abra o atalho/scripts salvos diretamente no Google Drive.
                </p>
              </div>
              <span className="text-xs font-mono text-slate-400 tabular-nums">
                {files.length} arquivo(s)
              </span>
            </div>

            {loadingFiles && files.length === 0 ? (
              <div className="p-8 text-center text-sm text-slate-400">
                Carregando arquivos do Google Drive...
              </div>
            ) : files.length === 0 ? (
              <div className="p-8 text-center text-sm text-slate-400">
                Nenhum arquivo salvo ainda. Use os botões acima para salvar sua configuração ou o pacote Android no Drive.
              </div>
            ) : (
              <div className="divide-y divide-[#1A222E]">
                {files.map((file) => {
                  const isJson = file.name.endsWith('.json') || file.mimeType === 'application/json';
                  return (
                    <div
                      key={file.id}
                      className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-[#161E29]"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-mono font-medium text-slate-100 truncate">
                          {file.name}
                        </p>
                        <p className="text-xs text-slate-400 font-mono tabular-nums mt-0.5">
                          {formatBytes(file.size)} · Atualizado em {formatDate(file.modifiedTime)}
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        {isJson && (
                          <button
                            type="button"
                            disabled={busyAction !== null}
                            onClick={() => void handleRestoreFile(file)}
                            className="min-h-[36px] px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 text-xs font-medium text-emerald-300 inline-flex items-center gap-1.5 disabled:opacity-50"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>Restaurar</span>
                          </button>
                        )}
                        {file.webViewLink && (
                          <a
                            href={file.webViewLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="min-h-[36px] px-3 py-1.5 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-medium text-slate-200 inline-flex items-center gap-1.5"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>Abrir</span>
                          </a>
                        )}
                        <button
                          type="button"
                          disabled={busyAction !== null}
                          onClick={() => requestDeleteFile(file)}
                          className="min-h-[36px] px-3 py-1.5 rounded-lg bg-rose-950/30 hover:bg-rose-950/60 border border-rose-500/30 text-xs font-medium text-rose-300 inline-flex items-center gap-1.5 disabled:opacity-50"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Excluir</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </>
      )}

      {/* Explicit Confirmation Modal for Overwrite or Delete */}
      {pendingConfirm && (
        <div
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-xl bg-[#121821] border border-[#283344] p-6 space-y-4 shadow-2xl">
            <div className="flex items-start gap-3">
              <div
                className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                  pendingConfirm.destructive
                    ? 'bg-rose-950/50 border border-rose-500/40 text-rose-400'
                    : 'bg-amber-950/50 border border-amber-500/40 text-amber-400'
                }`}
              >
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-semibold text-slate-100">{pendingConfirm.title}</h4>
                <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                  {pendingConfirm.description}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPendingConfirm(null)}
                className="min-h-[40px] px-4 py-2 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-medium text-slate-200"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const action = pendingConfirm;
                  setPendingConfirm(null);
                  void runDriveMutation('confirmed-action', action.run);
                }}
                className={`min-h-[40px] px-4 py-2 rounded-lg text-xs font-semibold text-white ${
                  pendingConfirm.destructive
                    ? 'bg-rose-600 hover:bg-rose-500'
                    : 'bg-emerald-600 hover:bg-emerald-500'
                }`}
              >
                {pendingConfirm.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
