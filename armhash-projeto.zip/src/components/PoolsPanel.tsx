import React, { useEffect, useState } from 'react';
import { Plug, Unplug, RefreshCw, Copy, Check } from 'lucide-react';
import {
  ZPOOL_COINS,
  formatHashrate,
  type ZpoolCoinSpec,
} from '../lib/ecoEngine';
import type { MiningAlgorithm } from '../workers/miner.worker';

export interface StratumJobState {
  jobId: string;
  headerHex: string;
  extranonce2: string;
  ntime: string;
  difficulty: number;
  receivedAt: number;
}

export interface PoolLogItem {
  id: string;
  time: string;
  kind: 'info' | 'job' | 'accepted' | 'rejected' | 'error';
  message: string;
}

export interface MarketPrices {
  'verus-coin'?: { usd: number; brl: number };
  bitcoin?: { usd: number; brl: number };
  litecoin?: { usd: number; brl: number };
  monero?: { usd: number; brl: number };
  tron?: { usd: number; brl: number };
  'the-open-network'?: { usd: number; brl: number };
  tether?: { usd: number; brl: number };
  dogecoin?: { usd: number; brl: number };
  dash?: { usd: number; brl: number };
  solana?: { usd: number; brl: number };
}

export interface ZpoolWalletInfo {
  currency: string;
  unpaid: number;
  balance: number;
  total: number;
  paid24h: number;
  hasActivity: boolean;
}

interface VerusPoolStats {
  hashrateString: string;
  minerCount: number;
  workerCount: number;
  estimatedLuck: string;
  blockReward: number;
}

export interface StratumConnectOverride {
  host?: string;
  port?: string;
  worker?: string;
  password?: string;
  algorithm?: MiningAlgorithm;
  autoStartMining?: boolean;
}

interface PoolsPanelProps {
  host: string;
  port: string;
  worker: string;
  password: string;
  onChangeHost: (v: string) => void;
  onChangePort: (v: string) => void;
  onChangeWorker: (v: string) => void;
  onChangePassword: (v: string) => void;
  connected: boolean;
  connecting: boolean;
  subscribed: boolean;
  authorized: boolean;
  isMining: boolean;
  hashrate: number;
  totalHashes: number;
  acceptedCount: number;
  rejectedCount: number;
  poolError: string | null;
  activeJob: StratumJobState | null;
  logs: PoolLogItem[];
  onConnect: (override?: StratumConnectOverride) => void;
  onDisconnect: () => void;
  onOpenMiner: () => void;
  activeAlgorithm: MiningAlgorithm;
  onSelectAlgorithm: (algo: MiningAlgorithm) => void;
  zCoin: ZpoolCoinSpec['code'];
  zAddress: string;
  onChangeZCoin: (c: ZpoolCoinSpec['code']) => void;
  onChangeZAddress: (a: string) => void;
  zWallet: ZpoolWalletInfo | null;
  zLoading: boolean;
  zError: string | null;
  onCheckZpoolWallet: () => void;
  onConnectZpool: () => void;
  prices: MarketPrices;
  initialSubTab?: 'zpool' | 'unmineable' | 'verus' | 'custom';
}

export const PoolsPanel: React.FC<PoolsPanelProps> = ({
  host,
  port,
  worker,
  password,
  onChangeHost,
  onChangePort,
  onChangeWorker,
  onChangePassword,
  connected,
  connecting,
  subscribed,
  authorized,
  isMining,
  hashrate,
  totalHashes,
  acceptedCount,
  rejectedCount,
  poolError,
  activeJob,
  logs,
  onConnect,
  onDisconnect,
  onOpenMiner,
  activeAlgorithm,
  onSelectAlgorithm,
  zCoin,
  zAddress,
  onChangeZCoin,
  onChangeZAddress,
  zWallet,
  zLoading,
  zError,
  onCheckZpoolWallet,
  onConnectZpool,
  prices,
  initialSubTab,
}) => {
  const [subTab, setSubTab] = useState<'zpool' | 'unmineable' | 'verus' | 'custom'>(
    initialSubTab ?? 'zpool'
  );
  const [verusStats, setVerusStats] = useState<VerusPoolStats | null>(null);

  useEffect(() => {
    if (initialSubTab) setSubTab(initialSubTab);
  }, [initialSubTab]);

  // unMineable wallet state
  const [umCoin, setUmCoin] = useState(() => {
    try {
      const saved = localStorage.getItem('armhash_um_coin');
      if (saved) return saved;
      const m = /^([A-Z0-9]{2,10}):([^.\s]+)/i.exec(worker);
      if (m && m[2] !== 'SeuEnderecoAqui') return m[1].toUpperCase();
    } catch {
      // ignore
    }
    return 'USDT';
  });
  const [umAddress, setUmAddress] = useState(() => {
    try {
      const saved = localStorage.getItem('armhash_um_address');
      if (saved) return saved;
      const m = /^([A-Z0-9]{2,10}):([^.\s]+)/i.exec(worker);
      if (m && m[2] !== 'SeuEnderecoAqui') return m[2];
    } catch {
      // ignore
    }
    return '';
  });
  const [umBalance, setUmBalance] = useState<{
    balance: string;
    threshold: string;
    network?: string;
    paid?: string;
  } | null>(null);
  const [umLoading, setUmLoading] = useState(false);
  const [umError, setUmError] = useState<string | null>(null);
  const [copiedXmrig, setCopiedXmrig] = useState(false);

  // Verus miner state
  const [vrscAddress, setVrscAddress] = useState(() => {
    try {
      return localStorage.getItem('armhash_vrsc_address') ?? '';
    } catch {
      return '';
    }
  });
  const [vrscMinerInfo, setVrscMinerInfo] = useState<{
    balance?: number;
    immature?: number;
    paid?: number;
    hashrateString?: string;
  } | null>(null);
  const [vrscLoading, setVrscLoading] = useState(false);
  const [vrscError, setVrscError] = useState<string | null>(null);
  const [copiedTermux, setCopiedTermux] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('armhash_um_coin', umCoin);
    } catch {
      // ignore
    }
  }, [umCoin]);

  useEffect(() => {
    try {
      localStorage.setItem('armhash_um_address', umAddress);
    } catch {
      // ignore
    }
  }, [umAddress]);

  useEffect(() => {
    try {
      localStorage.setItem('armhash_vrsc_address', vrscAddress);
    } catch {
      // ignore
    }
  }, [vrscAddress]);

  useEffect(() => {
    fetch('/api/pool/verus-stats')
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d && !d.error) setVerusStats(d);
      })
      .catch(() => {});
  }, []);

  const selectedZpoolCoin = ZPOOL_COINS.find((c) => c.code === zCoin) ?? ZPOOL_COINS[0];

  const normalizeUmAddress = (raw: string, coin: string) => {
    let clean = raw.trim();
    if (clean.toUpperCase().startsWith(`${coin.toUpperCase()}:`)) {
      clean = clean.slice(coin.length + 1);
    }
    const dotIdx = clean.indexOf('.');
    if (dotIdx > 15) {
      clean = clean.slice(0, dotIdx);
    }
    return clean;
  };

  const checkUnmineableAccount = async () => {
    const cleanAddr = normalizeUmAddress(umAddress, umCoin);
    if (!cleanAddr) return;
    setUmLoading(true);
    setUmError(null);
    try {
      const resp = await fetch(
        `/api/pool/unmineable/${encodeURIComponent(umCoin)}/${encodeURIComponent(cleanAddr)}`
      );
      const data = await resp.json();
      if (!resp.ok) {
        setUmError(data.error ?? 'Conta não encontrada.');
        setUmBalance(null);
      } else {
        setUmBalance({
          balance: String(data.balance ?? '0'),
          threshold: String(data.payment_threshold ?? '—'),
          network: data.network ? String(data.network) : undefined,
          paid: data.paid ? String(data.paid) : undefined,
        });
      }
    } catch {
      setUmError('Erro de conexão ao consultar API do unMineable.');
    } finally {
      setUmLoading(false);
    }
  };

  const applyUnmineableAndConnect = () => {
    const cleanAddr = normalizeUmAddress(umAddress, umCoin);
    if (!cleanAddr || /\s/.test(cleanAddr)) {
      setUmError('Informe um endereço de carteira válido (sem espaços) para receber os pagamentos.');
      return;
    }
    setUmError(null);
    onConnect({
      host: 'sha256.unmineable.com',
      port: '3333',
      worker: `${umCoin}:${cleanAddr}.AndroidEco`,
      password: 'x',
      algorithm: 'sha256d',
      autoStartMining: true,
    });
  };

  const umCleanAddr = normalizeUmAddress(umAddress, umCoin) || 'SUA_CARTEIRA_AQUI';
  const umXmrigCommand = `pkg update -y && pkg install -y git cmake clang make libuv openssl hwloc termux-api
git clone --depth 1 https://github.com/xmrig/xmrig.git && mkdir xmrig/build && cd xmrig/build
cmake .. -DWITH_HWLOC=ON && make -j4
termux-wake-lock
./xmrig -a rx/0 -o stratum+tcp://rx.unmineable.com:3333 -u ${umCoin}:${umCleanAddr}.AndroidARM -p x -t 4`;

  const copyUmXmrig = async () => {
    try {
      await navigator.clipboard.writeText(umXmrigCommand);
      setCopiedXmrig(true);
      window.setTimeout(() => setCopiedXmrig(false), 1800);
    } catch {
      // ignore
    }
  };

  const checkVerusMiner = async () => {
    const clean = vrscAddress.trim();
    if (!clean) return;
    setVrscLoading(true);
    setVrscError(null);
    try {
      const resp = await fetch(`/api/pool/verus-miner/${encodeURIComponent(clean)}`);
      const data = await resp.json();
      if (!resp.ok) {
        setVrscError(data.error ?? 'Endereço sem atividade registrada.');
        setVrscMinerInfo(null);
      } else {
        setVrscMinerInfo({
          balance: Number(data.balance ?? 0),
          immature: Number(data.immature ?? 0),
          paid: Number(data.paid ?? 0),
          hashrateString: String(data.hashrateString ?? '0 H/s'),
        });
      }
    } catch {
      setVrscError('Falha ao consultar Luckpool.');
    } finally {
      setVrscLoading(false);
    }
  };

  const vrscTermuxCommand = `pkg update -y && pkg install -y git build-essential automake autoconf libcurl libjansson openssl termux-api
git clone --single-branch -b ARM https://github.com/monkins1010/ccminer.git
cd ccminer && chmod +x build.sh configure.sh && ./build.sh
termux-wake-lock
./ccminer -a verus -o stratum+tcp://na.luckpool.net:3956 -u ${vrscAddress.trim() || 'SEU_ENDERECO_VERUS'}.AndroidEco -p x -t 4`;

  const copyVerusScript = async () => {
    try {
      await navigator.clipboard.writeText(vrscTermuxCommand);
      setCopiedTermux(true);
      window.setTimeout(() => setCopiedTermux(false), 1800);
    } catch {
      // ignore
    }
  };

  const renderConnectionMonitor = () => (
    <div className="lg:col-span-6 rounded-xl bg-[#121821] border border-[#1E293B] p-5 space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-base font-semibold text-slate-100">Estado da Conexão & Shares</h3>
        <div className="flex items-center gap-3">
          {connected && isMining && (
            <button
              type="button"
              onClick={onOpenMiner}
              className="text-xs text-sky-400 hover:text-sky-300 underline"
            >
              Ver Minerador
            </button>
          )}
          <span className={`text-xs font-medium ${connected ? 'text-emerald-400' : 'text-slate-400'}`}>
            {connected ? (authorized ? 'Autorizado' : subscribed ? 'Subscrito' : 'Conectado') : 'Offline'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 rounded-lg bg-[#0B0F14] border border-[#1E293B] p-3 text-xs font-mono tabular-nums">
        <div>
          <span className="text-slate-400 block">Hashrate</span>
          <span className="text-sky-300 font-semibold">{formatHashrate(hashrate)}</span>
        </div>
        <div>
          <span className="text-slate-400 block">Aceitos</span>
          <span className="text-emerald-400 font-semibold">{acceptedCount}</span>
        </div>
        <div>
          <span className="text-slate-400 block">Rejeitados</span>
          <span className={rejectedCount > 0 ? 'text-rose-400 font-semibold' : 'text-slate-300'}>
            {rejectedCount}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block">Dificuldade</span>
          <span className="text-slate-200">{activeJob ? activeJob.difficulty : '—'}</span>
        </div>
      </div>

      {isMining && (
        <p className="text-[11px] font-mono text-slate-400 tabular-nums">
          Total processado no hardware: {totalHashes.toLocaleString('pt-BR')} hashes
        </p>
      )}

      {activeJob ? (
        <div className="rounded-lg bg-[#0B0F14] border border-[#1E293B] p-3 text-xs font-mono space-y-1">
          <div className="text-slate-400">
            Job {activeJob.jobId} · Diff {activeJob.difficulty}
          </div>
          <p className="text-emerald-300 break-all">{activeJob.headerHex}</p>
        </div>
      ) : (
        <p className="text-xs text-slate-400 bg-[#0B0F14] border border-[#1E293B] rounded-lg p-3">
          Nenhum job Stratum ativo. Conecte ao pool para receber blocos reais em tempo real.
        </p>
      )}

      <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
        {logs.length === 0 ? (
          <p className="text-xs text-slate-500 py-4 text-center">
            Logs JSON-RPC reais aparecerão aqui após conectar.
          </p>
        ) : (
          logs.map((l) => (
            <div key={l.id} className="flex gap-2.5 text-xs font-mono py-1 border-b border-[#1A222E]">
              <span className="text-slate-500 shrink-0 tabular-nums">{l.time}</span>
              <span
                className={`break-all ${
                  l.kind === 'accepted'
                    ? 'text-emerald-400'
                    : l.kind === 'error' || l.kind === 'rejected'
                      ? 'text-rose-400'
                      : l.kind === 'job'
                        ? 'text-sky-300'
                        : 'text-slate-200'
                }`}
              >
                {l.message}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-[#1E293B] pb-5">
        <div>
          <h2 className="text-xl font-semibold text-slate-100">
            Pools Reais e Principais Criptomoedas
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Minere direto na CPU do celular em BTC, LTC, SUGAR, ADVC, VRSC, DASH e BCH pela Zpool, ou use XMR, TRX, TON, USDT e DOGE via unMineable/ARM64.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#121821] border border-[#1E293B] rounded-lg shrink-0">
          {(
            [
              { id: 'zpool', label: 'CPU Real (Zpool)' },
              { id: 'unmineable', label: 'unMineable (XMR/TRX/TON/USDT)' },
              { id: 'verus', label: 'VerusCoin (ARM64)' },
              { id: 'custom', label: 'Stratum TCP' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSubTab(item.id)}
              className={`min-h-[38px] px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                subTab === item.id
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Live CoinGecko Market Prices Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'Bitcoin (BTC)', data: prices.bitcoin, decimals: 0 },
          { label: 'Litecoin (LTC)', data: prices.litecoin, decimals: 2 },
          { label: 'Monero (XMR)', data: prices.monero, decimals: 2 },
          { label: 'TRON (TRX)', data: prices.tron, decimals: 4 },
          { label: 'Toncoin (TON)', data: prices['the-open-network'], decimals: 2 },
          { label: 'Tether (USDT)', data: prices.tether, decimals: 4 },
        ].map((item) => (
          <div key={item.label} className="rounded-xl bg-[#121821] border border-[#1E293B] p-3.5">
            <span className="text-[11px] text-slate-400 block">{item.label}</span>
            <p className="text-base font-mono font-semibold text-emerald-400 mt-1 tabular-nums">
              {item.data ? `R$ ${item.data.brl.toFixed(item.decimals === 0 ? 0 : 2)}` : '—'}
            </p>
            <span className="text-[11px] text-slate-500 font-mono tabular-nums">
              {item.data ? `$${item.data.usd.toFixed(item.decimals)}` : 'Carregando...'}
            </span>
          </div>
        ))}
      </div>

      {subTab === 'zpool' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-6 rounded-xl bg-[#121821] border border-[#1E293B] p-5 space-y-4">
            <h3 className="text-base font-semibold text-slate-100">
              Mineração CPU Real — Yespower 1.0 (Zpool Stratum)
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Usa o hardware CPU do próprio celular com <strong>Yespower 1.0</strong> (dificuldade baixa <span className="font-mono text-emerald-300">0.006</span>), gerando shares aceitos em segundos e pagamento direto na sua carteira em <strong>BTC, LTC, SUGAR, ADVC, VRSC, DASH ou BCH</strong>.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1.5" htmlFor="zp-coin">
                  Moeda de Saque
                </label>
                <select
                  id="zp-coin"
                  value={zCoin}
                  onChange={(e) => onChangeZCoin(e.target.value as ZpoolCoinSpec['code'])}
                  className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm text-slate-100"
                >
                  {ZPOOL_COINS.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs text-slate-400 block mb-1.5" htmlFor="zp-addr">
                  Endereço da Sua Carteira ({zCoin})
                </label>
                <input
                  id="zp-addr"
                  type="text"
                  value={zAddress}
                  onChange={(e) => onChangeZAddress(e.target.value)}
                  placeholder={selectedZpoolCoin.placeholder}
                  className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm font-mono text-slate-100"
                />
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              {selectedZpoolCoin.note}
            </p>

            {(zError || poolError) && (
              <p className="text-xs text-rose-400 bg-rose-950/30 border border-rose-500/30 rounded-lg p-3">
                {zError ?? poolError}
              </p>
            )}

            {zWallet && (
              <div className="rounded-lg bg-[#0B0F14] border border-emerald-500/30 p-3 space-y-1 text-xs font-mono">
                {zWallet.hasActivity ? (
                  <div className="flex flex-wrap justify-between gap-2">
                    <span className="text-slate-300">
                      Não pago: <strong className="text-emerald-400">{zWallet.unpaid.toFixed(8)} {zWallet.currency || zCoin}</strong>
                    </span>
                    <span className="text-slate-400">
                      Confirmado: {zWallet.balance.toFixed(8)} · Total: {zWallet.total.toFixed(8)}
                    </span>
                  </div>
                ) : (
                  <span className="text-slate-400">
                    Carteira válida sem blocos confirmados ainda na Zpool. Após os primeiros shares aceitos e blocos encontrados pelo pool, o saldo real aparecerá aqui.
                  </span>
                )}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                disabled={zLoading || !zAddress.trim()}
                onClick={onCheckZpoolWallet}
                className="min-h-[44px] px-4 py-2 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-medium text-slate-200 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${zLoading ? 'animate-spin' : ''}`} />
                <span>Consultar Saldo</span>
              </button>

              {!connected ? (
                <button
                  type="button"
                  disabled={connecting}
                  onClick={onConnectZpool}
                  className="flex-1 min-h-[44px] px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Plug className="w-4 h-4" />
                  <span>{connecting ? 'Conectando...' : 'Conectar e Minerar Agora'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onDisconnect}
                  className="flex-1 min-h-[44px] px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white flex items-center justify-center gap-2"
                >
                  <Unplug className="w-4 h-4" />
                  <span>Desconectar</span>
                </button>
              )}
            </div>
          </div>

          {renderConnectionMonitor()}
        </div>
      )}

      {subTab === 'unmineable' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-6 rounded-xl bg-[#121821] border border-[#1E293B] p-5 space-y-4">
            <h3 className="text-base font-semibold text-slate-100">
              unMineable — XMR, TRX, TON, USDT, BTC, LTC, DOGE e SOL
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Consulte seu saldo real no unMineable ou gere o comando <strong>RandomX ARM64 (Termux)</strong> para minerar <strong>XMR, TRX, TON, USDT, BTC, LTC, DOGE ou SOL</strong> usando a CPU do celular. (Nota: no navegador, use a aba <strong>CPU Real (Zpool)</strong> com BTC/LTC/SUGAR, pois a porta SHA-256 do unMineable exige dificuldade 16.384 de ASIC).
            </p>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1.5" htmlFor="um-coin">
                  Moeda de Saque
                </label>
                <select
                  id="um-coin"
                  value={umCoin}
                  onChange={(e) => {
                    setUmCoin(e.target.value);
                    setUmBalance(null);
                    setUmError(null);
                  }}
                  className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm text-slate-100"
                >
                  <option value="USDT">USDT</option>
                  <option value="TRX">TRX (TRON)</option>
                  <option value="TON">TON (Toncoin)</option>
                  <option value="XMR">XMR (Monero)</option>
                  <option value="BTC">BTC (Bitcoin)</option>
                  <option value="LTC">LTC (Litecoin)</option>
                  <option value="DOGE">DOGE</option>
                  <option value="SOL">SOL (Solana)</option>
                </select>
              </div>

              <div className="col-span-2">
                <label className="text-xs text-slate-400 block mb-1.5" htmlFor="um-addr">
                  Endereço da Sua Carteira ({umCoin})
                </label>
                <input
                  id="um-addr"
                  type="text"
                  value={umAddress}
                  onChange={(e) => {
                    setUmAddress(e.target.value);
                    if (umError) setUmError(null);
                  }}
                  placeholder={`Cole seu endereço ${umCoin}...`}
                  className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm font-mono text-slate-100"
                />
              </div>
            </div>

            {umCoin === 'USDT' && (
              <p className="text-[11px] text-slate-400">
                Para USDT no unMineable, utilize endereço das redes <strong className="text-slate-200">TRC20</strong> (inicia com T), <strong className="text-slate-200">BEP20</strong> ou <strong className="text-slate-200">ERC20</strong> (0x...).
              </p>
            )}

            {(umError || poolError) && (
              <p className="text-xs text-rose-400 bg-rose-950/30 border border-rose-500/30 rounded-lg p-3">
                {umError ?? poolError}
              </p>
            )}

            {umBalance && (
              <div className="rounded-lg bg-[#0B0F14] border border-emerald-500/30 p-3 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
                <span className="text-slate-300">
                  Saldo: <strong className="text-emerald-400">{umBalance.balance} {umCoin}</strong>
                  {umBalance.network ? <span className="text-slate-400"> ({umBalance.network})</span> : null}
                </span>
                <span className="text-slate-400">
                  Saque mín.: {umBalance.threshold} {umCoin}
                  {umBalance.paid && Number(umBalance.paid) > 0 ? ` · Pago: ${umBalance.paid}` : ''}
                </span>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                disabled={umLoading || !umAddress.trim()}
                onClick={checkUnmineableAccount}
                className="min-h-[44px] px-4 py-2 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-medium text-slate-200 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${umLoading ? 'animate-spin' : ''}`} />
                <span>Consultar Saldo</span>
              </button>

              {!connected ? (
                <button
                  type="button"
                  disabled={connecting}
                  onClick={applyUnmineableAndConnect}
                  className="flex-1 min-h-[44px] px-4 py-2 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Plug className="w-4 h-4" />
                  <span>{connecting ? 'Conectando...' : 'Conectar SHA-256 (ASIC)'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onDisconnect}
                  className="flex-1 min-h-[44px] px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white flex items-center justify-center gap-2"
                >
                  <Unplug className="w-4 h-4" />
                  <span>Desconectar</span>
                </button>
              )}
            </div>

            <div className="pt-3 border-t border-[#1E293B] space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-emerald-300">
                  Minerar {umCoin} no Android via CPU RandomX (Termux)
                </span>
                <button
                  type="button"
                  onClick={copyUmXmrig}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-[11px] font-medium text-white flex items-center gap-1.5"
                >
                  {copiedXmrig ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedXmrig ? 'Copiado' : 'Copiar Comando'}</span>
                </button>
              </div>
              <pre className="p-3 rounded-lg bg-[#0B0F14] border border-[#1E293B] overflow-x-auto text-[11px] font-mono text-slate-300 leading-relaxed">
                <code>{umXmrigCommand}</code>
              </pre>
            </div>
          </div>

          {renderConnectionMonitor()}
        </div>
      )}

      {subTab === 'verus' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 rounded-xl bg-[#121821] border border-[#1E293B] p-5 space-y-4">
            <h3 className="text-base font-semibold text-slate-100">
              VerusCoin (VRSC) — Modo Nativo ARM64 (Termux)
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              O algoritmo <strong>VerusHash 2.2</strong> usa as instruções nativas ARMv8 AES do Android (atingindo 2 a 6 MH/s via Termux). Você também pode minerar VRSC direto no navegador pela aba <strong>CPU Real (Zpool)</strong>!
            </p>
            {verusStats && (
              <p className="text-xs font-mono text-slate-400">
                Luckpool: {verusStats.hashrateString} · {verusStats.minerCount} mineradores · Bloco {verusStats.blockReward} VRSC
              </p>
            )}

            <div>
              <label className="text-xs text-slate-400 block mb-1.5" htmlFor="vrsc-addr">
                Sua Carteira Verus (inicia com R...)
              </label>
              <div className="flex gap-2">
                <input
                  id="vrsc-addr"
                  type="text"
                  value={vrscAddress}
                  onChange={(e) => setVrscAddress(e.target.value)}
                  placeholder="REoP..."
                  className="flex-1 min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm font-mono text-slate-100"
                />
                <button
                  type="button"
                  disabled={vrscLoading || !vrscAddress.trim()}
                  onClick={checkVerusMiner}
                  className="min-h-[44px] px-3.5 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-medium text-slate-200 flex items-center gap-1.5 disabled:opacity-50 whitespace-nowrap"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${vrscLoading ? 'animate-spin' : ''}`} />
                  <span>Ver Saldo</span>
                </button>
              </div>
            </div>

            {vrscError && (
              <p className="text-xs text-amber-300 bg-amber-950/30 border border-amber-500/30 rounded-lg p-3">
                {vrscError}
              </p>
            )}

            {vrscMinerInfo && (
              <div className="grid grid-cols-3 gap-2 rounded-lg bg-[#0B0F14] border border-emerald-500/30 p-3 text-xs font-mono tabular-nums">
                <div>
                  <span className="text-slate-400 block">Saldo</span>
                  <span className="text-emerald-400 font-semibold">
                    {(vrscMinerInfo.balance ?? 0).toFixed(4)} VRSC
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Pago</span>
                  <span className="text-slate-200">{(vrscMinerInfo.paid ?? 0).toFixed(4)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Taxa Pool</span>
                  <span className="text-slate-200">{vrscMinerInfo.hashrateString}</span>
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-7 rounded-xl bg-[#121821] border border-[#1E293B] p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  Comando Pronto para Android (Termux ARM64)
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Limita a 4 threads (<span className="font-mono">-t 4</span>) e ativa <span className="font-mono">termux-wake-lock</span> para eficiência energética.
                </p>
              </div>
              <button
                type="button"
                onClick={copyVerusScript}
                className="min-h-[40px] px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-medium text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                {copiedTermux ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedTermux ? 'Copiado' : 'Copiar comandos'}</span>
              </button>
            </div>

            <pre className="p-4 rounded-lg bg-[#0B0F14] border border-[#1E293B] overflow-x-auto text-xs font-mono text-slate-200 leading-relaxed">
              <code>{vrscTermuxCommand}</code>
            </pre>
          </div>
        </div>
      )}

      {subTab === 'custom' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-6 rounded-xl bg-[#121821] border border-[#1E293B] p-5 space-y-4">
            <h3 className="text-base font-semibold text-slate-100">Pool Stratum v1 Personalizado</h3>

            <div className="flex flex-wrap gap-2">
              {[
                { label: 'Zpool Yespower-ADVC (BTC)', h: 'yespowerADVC.na.mine.zpool.ca', p: '6248', pass: 'c=BTC,d=0.005', algo: 'yespower_advc' as MiningAlgorithm },
                { label: 'Zpool Yespower-ADVC (LTC)', h: 'yespowerADVC.na.mine.zpool.ca', p: '6248', pass: 'c=LTC,d=0.005', algo: 'yespower_advc' as MiningAlgorithm },
                { label: 'Zpool Yespower-SUGAR', h: 'yespowerSUGAR.na.mine.zpool.ca', p: '6241', pass: 'c=SUGAR,d=0.005', algo: 'yespower_sugar' as MiningAlgorithm },
                { label: 'Public Pool (BTC)', h: 'public-pool.io', p: '21496', pass: 'x', algo: 'sha256d' as MiningAlgorithm },
              ].map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  disabled={connected}
                  onClick={() => {
                    onChangeHost(preset.h);
                    onChangePort(preset.p);
                    onChangePassword(preset.pass);
                    onSelectAlgorithm(preset.algo);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs text-slate-300 disabled:opacity-50"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label className="text-xs text-slate-400 block mb-1.5" htmlFor="st-host">
                  Host
                </label>
                <input
                  id="st-host"
                  type="text"
                  disabled={connected}
                  value={host}
                  onChange={(e) => onChangeHost(e.target.value)}
                  placeholder="yespowerADVC.na.mine.zpool.ca"
                  className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm font-mono text-slate-100"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1.5" htmlFor="st-port">
                  Porta
                </label>
                <input
                  id="st-port"
                  type="text"
                  disabled={connected}
                  value={port}
                  onChange={(e) => onChangePort(e.target.value)}
                  className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm font-mono text-slate-100"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1.5" htmlFor="st-algo">
                Algoritmo do Pool
              </label>
              <select
                id="st-algo"
                disabled={connected}
                value={activeAlgorithm}
                onChange={(e) => onSelectAlgorithm(e.target.value as MiningAlgorithm)}
                className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm text-slate-100"
              >
                <option value="yespower_advc">Yespower-ADVC (Zpool CPU)</option>
                <option value="yespower_sugar">Yespower-SUGAR (Sugarchain)</option>
                <option value="yespower_arm">Yespower 1.0 Genérico</option>
                <option value="sha256d">SHA-256d (BTC / unMineable)</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1.5" htmlFor="st-worker">
                Carteira / Worker
              </label>
              <input
                id="st-worker"
                type="text"
                disabled={connected}
                value={worker}
                onChange={(e) => onChangeWorker(e.target.value)}
                className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm font-mono text-slate-100"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1.5" htmlFor="st-pass">
                Senha (ex: c=LTC,d=0.005 ou x)
              </label>
              <input
                id="st-pass"
                type="text"
                disabled={connected}
                value={password}
                onChange={(e) => onChangePassword(e.target.value)}
                className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm font-mono text-slate-100"
              />
            </div>

            {poolError && (
              <p className="text-xs text-rose-400 bg-rose-950/30 border border-rose-500/30 rounded-lg p-3">
                {poolError}
              </p>
            )}

            {!connected ? (
              <button
                type="button"
                disabled={connecting}
                onClick={() =>
                  onConnect({
                    host,
                    port,
                    worker,
                    password,
                    algorithm: activeAlgorithm === 'blake3_eco' ? 'yespower_advc' : activeAlgorithm,
                    autoStartMining: true,
                  })
                }
                className="w-full min-h-[44px] px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-sm font-semibold text-white flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Plug className="w-4 h-4" />
                <span>{connecting ? 'Conectando...' : 'Conectar Stratum TCP'}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={onDisconnect}
                className="w-full min-h-[44px] px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-sm font-semibold text-white flex items-center justify-center gap-2"
              >
                <Unplug className="w-4 h-4" />
                <span>Desconectar</span>
              </button>
            )}
          </div>

          {renderConnectionMonitor()}
        </div>
      )}
    </div>
  );
};
