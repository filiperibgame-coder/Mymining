import React, { useState } from 'react';
import { Download, X, WifiOff } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallControl: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, isOnline, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  const handleClick = async () => {
    if (isInstallable) {
      const ok = await install();
      if (!ok) setShowGuide(true);
      return;
    }
    setShowGuide(true);
  };

  return (
    <>
      {!isInstalled && (
        <button
          type="button"
          onClick={handleClick}
          className="min-h-[44px] px-4 py-2 rounded-lg bg-emerald-600/15 hover:bg-emerald-600/25 border border-emerald-500/40 text-xs font-medium text-emerald-300 flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>{isInstallable ? 'Instalar App no Android' : 'Instalar no Celular'}</span>
        </button>
      )}

      {!isOnline && (
        <div
          role="status"
          className="fixed bottom-20 md:bottom-4 left-4 z-50 flex items-center gap-2 rounded-lg bg-amber-600 px-3 py-2 text-xs font-medium text-white shadow-lg"
        >
          <WifiOff className="w-3.5 h-3.5" />
          <span>Modo Offline — Interface em cache e mineração local disponíveis</span>
        </div>
      )}

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Como instalar o aplicativo no celular"
        >
          <div className="w-full max-w-md rounded-xl bg-[#121821] border border-[#1E293B] p-6 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <h3 className="text-lg font-semibold text-slate-100">
                {isIOS ? 'Instalar no iPhone / iPad' : 'Instalar no Celular Android'}
              </h3>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-200 hover:bg-[#1A222E]"
                aria-label="Fechar instruções"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isIOS ? (
              <ol className="space-y-2.5 text-sm text-slate-300 list-decimal list-inside">
                <li>
                  Toque no botão <strong>Compartilhar</strong> na barra do Safari.
                </li>
                <li>
                  Role para baixo e toque em <strong>Adicionar à Tela de Início</strong>.
                </li>
                <li>
                  Confirme tocando em <strong>Adicionar</strong> para abrir como aplicativo.
                </li>
              </ol>
            ) : (
              <ol className="space-y-2.5 text-sm text-slate-300 list-decimal list-inside">
                <li>
                  Abra este endereço diretamente no <strong>Google Chrome</strong> do Android (fora de visualizações embutidas).
                </li>
                <li>
                  Toque no menu <strong>⋮</strong> (três pontos no canto superior direito) e selecione <strong>Instalar aplicativo</strong> ou <strong>Adicionar à tela inicial</strong>.
                </li>
                <li>
                  O ícone do <strong>ARMHash</strong> aparecerá na tela inicial e rodará em modo standalone usando os núcleos do celular.
                </li>
              </ol>
            )}

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="w-full min-h-[44px] rounded-lg bg-emerald-600 hover:bg-emerald-500 text-sm font-medium text-white transition-colors"
            >
              Entendi
            </button>
          </div>
        </div>
      )}
    </>
  );
};
