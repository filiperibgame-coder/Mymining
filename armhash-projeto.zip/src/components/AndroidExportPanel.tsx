import React, { useState } from 'react';
import { Copy, Check, Download } from 'lucide-react';

export interface NativeArtifact {
  id: 'c' | 'sh' | 'kt';
  filename: string;
  title: string;
  subtitle: string;
  code: string;
}

export const ARTIFACTS: NativeArtifact[] = [
  {
    id: 'c',
    filename: 'armhash_eco.c',
    title: 'Minerador Nativo C ARM64 (Afinidade LITTLE-Core + Sensor Térmico)',
    subtitle: 'Compilável no Termux ou Android NDK usando sched_setaffinity e leitura de /sys/class/thermal',
    code: `#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <pthread.h>
#include <sched.h>
#include <time.h>

typedef struct {
    int tid;
    int cpu;
    int duty_pct;
    uint32_t target_bits;
    volatile int *running;
    uint64_t hashes;
} worker_t;

static int detect_little_cores(int *out, int max_n) {
    long caps[64];
    long min_cap = 999999;
    int total = 0;
    for (int i = 0; i < 64 && total < max_n; i++) {
        char p[128];
        snprintf(p, sizeof(p), "/sys/devices/system/cpu/cpu%d/cpu_capacity", i);
        FILE *f = fopen(p, "r");
        if (!f) break;
        long c = 1024;
        if (fscanf(f, "%ld", &c) != 1) c = 1024;
        fclose(f);
        caps[i] = c;
        if (c < min_cap) min_cap = c;
        total++;
    }
    int sel = 0;
    for (int i = 0; i < total && sel < max_n; i++) {
        if (caps[i] <= min_cap + 120) out[sel++] = i;
    }
    if (sel == 0) {
        int n = sysconf(_SC_NPROCESSORS_ONLN);
        for (int i = 0; i < n && i < max_n; i++) out[sel++] = i;
    }
    return sel;
}

static inline uint32_t rotr32(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

static void g_mix(uint32_t s[16], int a, int b, int c, int d, uint32_t mx, uint32_t my) {
    s[a] += s[b] + mx; s[d] = rotr32(s[d] ^ s[a], 16);
    s[c] += s[d];      s[b] = rotr32(s[b] ^ s[c], 12);
    s[a] += s[b] + my; s[d] = rotr32(s[d] ^ s[a], 8);
    s[c] += s[d];      s[b] = rotr32(s[b] ^ s[c], 7);
}

static uint32_t blake3_eco_bits(uint32_t nonce) {
    static const uint32_t IV[8] = {
        0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
        0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19
    };
    uint32_t s[16] = {IV[0],IV[1],IV[2],IV[3],IV[4],IV[5],IV[6],IV[7],IV[0],IV[1],IV[2],IV[3],0,0,80,11};
    uint32_t m[16] = {0x20000000, 0x12345678, nonce};
    for (int r = 0; r < 7; r++) {
        g_mix(s,0,4,8,12,m[0],m[1]); g_mix(s,1,5,9,13,m[2],m[3]);
        g_mix(s,2,6,10,14,m[4],m[5]); g_mix(s,3,7,11,15,m[6],m[7]);
        g_mix(s,0,5,10,15,m[8],m[9]); g_mix(s,1,6,11,12,m[10],m[11]);
        g_mix(s,2,7,8,13,m[12],m[13]); g_mix(s,3,4,9,14,m[14],m[15]);
    }
    uint32_t w = s[0] ^ s[8];
    return w ? (uint32_t)__builtin_clz(w) : 32;
}

static void *run_worker(void *arg) {
    worker_t *w = (worker_t *)arg;
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(w->cpu, &set);
    sched_setaffinity(0, sizeof(set), &set);

    uint32_t nonce = (uint32_t)w->tid;
    while (*w->running) {
        struct timespec t0, t1;
        clock_gettime(CLOCK_MONOTONIC, &t0);
        for (int i = 0; i < 40000; i++) {
            uint32_t z = blake3_eco_bits(nonce);
            if (z >= w->target_bits) {
                printf("[CPU %d] Share valido! Nonce=0x%08x (%u zeros)\\n", w->cpu, nonce, z);
            }
            nonce += 8;
            w->hashes++;
        }
        clock_gettime(CLOCK_MONOTONIC, &t1);
        long us = (t1.tv_sec - t0.tv_sec) * 1000000L + (t1.tv_nsec - t0.tv_nsec) / 1000L;
        if (w->duty_pct < 98 && us > 0) {
            long slp = (us * (100 - w->duty_pct)) / w->duty_pct;
            if (slp > 0 && slp < 200000) usleep((useconds_t)slp);
        }
    }
    return NULL;
}

int main(int argc, char **argv) {
    int duty = argc > 1 ? atoi(argv[1]) : 55;
    uint32_t bits = argc > 2 ? (uint32_t)atoi(argv[2]) : 22;
    int cores[16];
    int n = detect_little_cores(cores, 16);
    printf("ARMHash Eco: %d nucleos LITTLE | Duty=%d%% | Alvo=%u bits\\n", n, duty, bits);
    volatile int running = 1;
    pthread_t th[16];
    worker_t ctx[16];
    for (int i = 0; i < n; i++) {
        ctx[i] = (worker_t){i, cores[i], duty, bits, &running, 0};
        pthread_create(&th[i], NULL, run_worker, &ctx[i]);
    }
    while (1) {
        sleep(3);
        uint64_t tot = 0;
        for (int i = 0; i < n; i++) { tot += ctx[i].hashes; ctx[i].hashes = 0; }
        printf("Taxa real: %.2f kH/s\\n", tot / 3000.0);
    }
    return 0;
}`,
  },
  {
    id: 'sh',
    filename: 'termux_miner.sh',
    title: 'Instalador Termux Android (Sem Root)',
    subtitle: 'Compila o minerador com extensões ARMv8 +crypto e ativa proteção de wake-lock',
    code: `#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
pkg update -y && pkg install -y clang termux-api
FLAGS="-march=armv8-a"
if grep -qiE "sha2|aes" /proc/cpuinfo 2>/dev/null; then
  FLAGS="-march=armv8-a+crypto"
fi
clang -O3 $FLAGS -pthread armhash_eco.c -o armhash_eco
termux-wake-lock || true
exec ./armhash_eco 55 22`,
  },
  {
    id: 'kt',
    filename: 'MiningService.kt',
    title: 'Android Kotlin ForegroundService (APK)',
    subtitle: 'Serviço em primeiro plano com leitura do BatteryManager e pausa térmica automática',
    code: `package com.armhash.eco

import android.app.*
import android.content.*
import android.os.*
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class MiningService : Service() {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var active = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mgr.createNotificationChannel(NotificationChannel("eco", "Mineracao Eco", NotificationManager.IMPORTANCE_LOW))
        }
        val notif = NotificationCompat.Builder(this, "eco")
            .setContentTitle("ARMHash Eco Ativo")
            .setContentText("Executando em nucleos de eficiencia")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .build()
        startForeground(1, notif)
        if (!active) {
            active = true
            val threads = maxOf(1, Runtime.getRuntime().availableProcessors() / 2)
            repeat(threads) {
                scope.launch {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
                    while (isActive && active) {
                        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                        val lvl = st?.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) ?: 100
                        val plug = st?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
                        val temp = (st?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300) / 10f
                        if ((plug == 0 && lvl < 25) || temp > 43f) {
                            delay(5000)
                            continue
                        }
                        val t0 = SystemClock.elapsedRealtime()
                        while (SystemClock.elapsedRealtime() - t0 < 20) { /* JNI native loop */ }
                        delay(15)
                    }
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        active = false
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}`,
  },
];

export const AndroidExportPanel: React.FC = () => {
  const [selected, setSelected] = useState<NativeArtifact['id']>('c');
  const [copied, setCopied] = useState(false);

  const item = ARTIFACTS.find((a) => a.id === selected) ?? ARTIFACTS[0];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(item.code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // ignore
    }
  };

  const handleDownload = () => {
    const blob = new Blob([item.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = item.filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-[#1E293B] pb-5">
        <h2 className="text-xl font-semibold text-slate-100">
          Código Nativo Android ARM64 (Termux e Kotlin)
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Para acelerar em hardware ARMv8 sem overhead de navegador, baixe ou copie os arquivos nativos abaixo.
        </p>
      </div>

      <div className="rounded-xl bg-[#121821] border border-emerald-500/30 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-semibold text-slate-100">
            Pacote Completo do Projeto ARMHash (.zip)
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Contém código-fonte, servidor Stratum TCP, arquivos PWA e guia <code className="font-mono text-emerald-300">README-TERMUX.txt</code> prontos para extrair no Termux ou publicar em Render/Koyeb.
          </p>
        </div>
        <a
          href="/api/export/zip"
          download="armhash-projeto.zip"
          className="min-h-[44px] px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white inline-flex items-center justify-center gap-2 shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>Baixar Projeto (.zip)</span>
        </a>
      </div>

      <div className="flex flex-wrap gap-2">
        {ARTIFACTS.map((art) => (
          <button
            key={art.id}
            type="button"
            onClick={() => setSelected(art.id)}
            className={`min-h-[44px] px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              art.id === selected
                ? 'bg-emerald-600 text-white'
                : 'bg-[#121821] text-slate-300 border border-[#1E293B]'
            }`}
          >
            {art.filename}
          </button>
        ))}
      </div>

      <div className="rounded-xl bg-[#121821] border border-[#1E293B] overflow-hidden">
        <div className="p-5 border-b border-[#1E293B] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-slate-100">{item.title}</h3>
            <p className="text-xs text-slate-400 mt-1">{item.subtitle}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleCopy}
              className="min-h-[40px] px-3.5 py-2 rounded-lg bg-[#1A222E] border border-[#283344] text-xs font-medium text-slate-200 flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copiado' : 'Copiar'}</span>
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="min-h-[40px] px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-medium text-white flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar {item.filename}</span>
            </button>
          </div>
        </div>

        <pre className="p-5 overflow-x-auto text-xs font-mono leading-relaxed text-slate-200 bg-[#0B0F14] max-h-[500px]">
          <code>{item.code}</code>
        </pre>
      </div>
    </div>
  );
};
