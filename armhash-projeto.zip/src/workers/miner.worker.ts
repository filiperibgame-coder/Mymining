/* eslint-disable no-restricted-globals */
import {
  YESPOWER_PERS,
  YespowerWorkspace,
  countLeadingZeroBitsLE,
  difficultyToTarget256BE,
  hashLEMeetsTargetBE,
  type YespowerParams,
} from '../lib/yespower';

export type MiningAlgorithm =
  | 'yespower_advc'
  | 'yespower_sugar'
  | 'yespower_arm'
  | 'blake3_eco'
  | 'sha256d';

export interface WorkerStartMessage {
  type: 'start';
  workerId: number;
  algorithm: MiningAlgorithm;
  headerHex: string;
  targetZeroBits: number;
  poolDifficulty?: number;
  startNonce: number;
  stride: number;
  dutyCycle: number;
  useRamCache?: boolean;
  deviceMemoryGb?: number;
  freeHeapMbHint?: number;
  jobId: string;
  extranonce2?: string;
  ntime?: string;
}

export interface WorkerUpdateConfigMessage {
  type: 'config';
  dutyCycle?: number;
  useRamCache?: boolean;
  freeHeapMbHint?: number;
  targetZeroBits?: number;
  poolDifficulty?: number;
  headerHex?: string;
  jobId?: string;
  extranonce2?: string;
  ntime?: string;
}

export interface WorkerStopMessage {
  type: 'stop';
}

type IncomingMessage = WorkerStartMessage | WorkerUpdateConfigMessage | WorkerStopMessage;

const SHA256_K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);

const SHA256_IV = new Uint32Array([
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
  0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]);

const BLAKE3_IV = new Uint32Array([
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
  0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]);

const BLAKE3_MSG_PERM = new Uint8Array([2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8]);

const shaW = new Uint32Array(64);
const midState = new Uint32Array(8);
const hash1 = new Uint32Array(8);
const hashOut = new Uint32Array(8);
const shaHashLE = new Uint8Array(32);
const headerWordsBE = new Uint32Array(20);
const headerWordsLE = new Uint32Array(20);
const headerBytes = new Uint8Array(80);

const b3State = new Uint32Array(16);
const b3Msg = new Uint32Array(16);
const b3MsgTmp = new Uint32Array(16);
const b3Cv = new Uint32Array(8);

const yespowerWs = new YespowerWorkspace({ lazyInit: true });
const yespowerOut = new Uint8Array(32);

interface PerformanceMemoryLike {
  jsHeapSizeLimit?: number;
  totalJSHeapSize?: number;
  usedJSHeapSize?: number;
}

interface DynamicCachePlan {
  targetCacheMb: number;
  prewarm: boolean;
  memoryGuardActive: boolean;
  estimatedFreeMb: number;
  perThreadBudgetMb: number;
}

let deviceMemoryHintGb = 0;
let freeHeapHintMb = 0;
let wantRamCache = true;
let allocatedCacheMb = 16;
let estimatedFreeMemMb = 512;
let memoryGuardActive = false;
let oomEmergencyMode = false;
let lastMemCheckAt = 0;

function estimateAvailableMemoryMb(): number {
  const nav = self.navigator as Navigator & { deviceMemory?: number };
  const rawDevMem =
    typeof nav?.deviceMemory === 'number' && nav.deviceMemory > 0
      ? nav.deviceMemory
      : deviceMemoryHintGb > 0
        ? deviceMemoryHintGb
        : /Android/i.test(nav?.userAgent ?? '')
          ? 2
          : 4;

  let osFreeMb: number;
  if (rawDevMem <= 0.5) osFreeMb = 96;
  else if (rawDevMem <= 1) osFreeMb = 180;
  else if (rawDevMem <= 2) osFreeMb = 360;
  else if (rawDevMem <= 3) osFreeMb = 550;
  else if (rawDevMem <= 4) osFreeMb = 820;
  else osFreeMb = Math.round(rawDevMem * 1024 * 0.28);

  const perfMem = (self.performance as Performance & { memory?: PerformanceMemoryLike })?.memory;
  let heapFreeMb = osFreeMb;
  if (
    perfMem &&
    typeof perfMem.jsHeapSizeLimit === 'number' &&
    perfMem.jsHeapSizeLimit > 0 &&
    typeof perfMem.usedJSHeapSize === 'number'
  ) {
    heapFreeMb = Math.max(12, (perfMem.jsHeapSizeLimit - perfMem.usedJSHeapSize) / (1024 * 1024));
    const ratio = perfMem.usedJSHeapSize / perfMem.jsHeapSizeLimit;
    if (ratio > 0.8) {
      heapFreeMb *= 0.6;
    }
  }

  const hintFree = freeHeapHintMb > 0 ? freeHeapHintMb : osFreeMb;
  return Math.max(16, Math.round(Math.min(osFreeMb, heapFreeMb, hintFree)));
}

function computeDynamicCachePlan(threadCount: number, cacheEnabled: boolean, isYp: boolean): DynamicCachePlan {
  const estFree = estimateAvailableMemoryMb();
  if (!isYp) {
    return {
      targetCacheMb: 0,
      prewarm: false,
      memoryGuardActive: false,
      estimatedFreeMb: estFree,
      perThreadBudgetMb: estFree,
    };
  }

  // Reserve >= 72% of estimated free RAM for Android OS, browser renderer & other apps
  const totalBudgetMb = estFree * 0.28;
  const perThreadBudgetMb = totalBudgetMb / Math.max(1, threadCount);

  if (oomEmergencyMode) {
    return {
      targetCacheMb: 9,
      prewarm: false,
      memoryGuardActive: true,
      estimatedFreeMb: estFree,
      perThreadBudgetMb,
    };
  }

  if (!cacheEnabled) {
    return {
      targetCacheMb: 9,
      prewarm: false,
      memoryGuardActive: perThreadBudgetMb < 10,
      estimatedFreeMb: estFree,
      perThreadBudgetMb,
    };
  }

  let targetCacheMb = 16;
  let prewarm = true;
  let guard = false;

  if (perThreadBudgetMb >= 16) {
    targetCacheMb = 16;
    prewarm = true;
    guard = false;
  } else if (perThreadBudgetMb >= 12) {
    targetCacheMb = 12;
    prewarm = true;
    guard = true;
  } else if (perThreadBudgetMb >= 10) {
    targetCacheMb = 10;
    prewarm = true;
    guard = true;
  } else {
    targetCacheMb = 9;
    prewarm = perThreadBudgetMb >= 8.5;
    guard = true;
  }

  return {
    targetCacheMb,
    prewarm,
    memoryGuardActive: guard,
    estimatedFreeMb: estFree,
    perThreadBudgetMb,
  };
}

function applyDynamicCachePlan(forceReapply = false) {
  const isYp = isYespowerAlgo(algorithm);
  const plan = computeDynamicCachePlan(stride, wantRamCache, isYp);
  estimatedFreeMemMb = plan.estimatedFreeMb;
  memoryGuardActive = plan.memoryGuardActive;

  if (!isYp) {
    yespowerWs.releaseWasmForLowMemory();
    allocatedCacheMb = 0;
    return;
  }

  if (!forceReapply && allocatedCacheMb === plan.targetCacheMb && yespowerWs.isWasmActive) {
    return;
  }

  try {
    yespowerWs.setUseSimdCache(wantRamCache && !oomEmergencyMode, plan.targetCacheMb);
    if (plan.prewarm && yespowerWs.isWasmActive) {
      yespowerWs.warmCache();
    }
    allocatedCacheMb =
      yespowerWs.cacheBytes > 0 ? Math.max(9, Math.round(yespowerWs.cacheBytes / (1024 * 1024))) : 9;
  } catch {
    oomEmergencyMode = true;
    memoryGuardActive = true;
    yespowerWs.releaseWasmForLowMemory();
    allocatedCacheMb = 9;
  }
}

function handleRuntimeOom() {
  oomEmergencyMode = true;
  memoryGuardActive = true;
  batchSize = 1;
  try {
    yespowerWs.setUseSimdCache(false, 9);
    allocatedCacheMb =
      yespowerWs.cacheBytes > 0 ? Math.max(9, Math.round(yespowerWs.cacheBytes / (1024 * 1024))) : 9;
  } catch {
    yespowerWs.releaseWasmForLowMemory();
    allocatedCacheMb = 9;
  }
}

function hexToWords(hex: string) {
  const padded = hex.padEnd(160, '0').slice(0, 160);
  for (let i = 0; i < 80; i++) {
    headerBytes[i] = parseInt(padded.slice(i * 2, i * 2 + 2), 16) || 0;
  }
  for (let i = 0; i < 20; i++) {
    const idx = i * 4;
    const b0 = headerBytes[idx];
    const b1 = headerBytes[idx + 1];
    const b2 = headerBytes[idx + 2];
    const b3 = headerBytes[idx + 3];
    headerWordsBE[i] = ((b0 << 24) | (b1 << 16) | (b2 << 8) | b3) >>> 0;
    headerWordsLE[i] = ((b3 << 24) | (b2 << 16) | (b1 << 8) | b0) >>> 0;
  }
}

function sha256Compress(stateIn: Uint32Array, stateOut: Uint32Array, w: Uint32Array) {
  for (let i = 16; i < 64; i++) {
    const w15 = w[i - 15];
    const s0 = ((w15 >>> 7) | (w15 << 25)) ^ ((w15 >>> 18) | (w15 << 14)) ^ (w15 >>> 3);
    const w2 = w[i - 2];
    const s1 = ((w2 >>> 17) | (w2 << 15)) ^ ((w2 >>> 19) | (w2 << 13)) ^ (w2 >>> 10);
    w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
  }

  let a = stateIn[0] | 0;
  let b = stateIn[1] | 0;
  let c = stateIn[2] | 0;
  let d = stateIn[3] | 0;
  let e = stateIn[4] | 0;
  let f = stateIn[5] | 0;
  let g = stateIn[6] | 0;
  let h = stateIn[7] | 0;

  for (let i = 0; i < 64; i++) {
    const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
    const ch = (e & f) ^ (~e & g);
    const temp1 = (h + S1 + ch + SHA256_K[i] + w[i]) | 0;
    const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
    const maj = (a & b) ^ (a & c) ^ (b & c);
    const temp2 = (S0 + maj) | 0;

    h = g;
    g = f;
    f = e;
    e = (d + temp1) | 0;
    d = c;
    c = b;
    b = a;
    a = (temp1 + temp2) | 0;
  }

  stateOut[0] = (stateIn[0] + a) >>> 0;
  stateOut[1] = (stateIn[1] + b) >>> 0;
  stateOut[2] = (stateIn[2] + c) >>> 0;
  stateOut[3] = (stateIn[3] + d) >>> 0;
  stateOut[4] = (stateIn[4] + e) >>> 0;
  stateOut[5] = (stateIn[5] + f) >>> 0;
  stateOut[6] = (stateIn[6] + g) >>> 0;
  stateOut[7] = (stateIn[7] + h) >>> 0;
}

function computeMidstate() {
  for (let i = 0; i < 16; i++) {
    shaW[i] = headerWordsBE[i];
  }
  sha256Compress(SHA256_IV, midState, shaW);
}

function hashSha256d(nonceLE: number): number {
  shaW[0] = headerWordsBE[16];
  shaW[1] = headerWordsBE[17];
  shaW[2] = headerWordsBE[18];
  shaW[3] =
    (((nonceLE & 0xff) << 24) |
      ((nonceLE & 0xff00) << 8) |
      ((nonceLE >>> 8) & 0xff00) |
      ((nonceLE >>> 24) & 0xff)) >>>
    0;
  shaW[4] = 0x80000000;
  shaW[5] = 0;
  shaW[6] = 0;
  shaW[7] = 0;
  shaW[8] = 0;
  shaW[9] = 0;
  shaW[10] = 0;
  shaW[11] = 0;
  shaW[12] = 0;
  shaW[13] = 0;
  shaW[14] = 0;
  shaW[15] = 640;

  sha256Compress(midState, hash1, shaW);

  for (let i = 0; i < 8; i++) shaW[i] = hash1[i];
  shaW[8] = 0x80000000;
  shaW[9] = 0;
  shaW[10] = 0;
  shaW[11] = 0;
  shaW[12] = 0;
  shaW[13] = 0;
  shaW[14] = 0;
  shaW[15] = 256;

  sha256Compress(SHA256_IV, hashOut, shaW);

  const w7 = hashOut[7];
  const msw =
    (((w7 & 0xff) << 24) |
      ((w7 & 0xff00) << 8) |
      ((w7 >>> 8) & 0xff00) |
      ((w7 >>> 24) & 0xff)) >>>
    0;
  if (msw !== 0) return Math.clz32(msw);

  let zeros = 32;
  for (let i = 6; i >= 0; i--) {
    const wi = hashOut[i];
    const sw =
      (((wi & 0xff) << 24) |
        ((wi & 0xff00) << 8) |
        ((wi >>> 8) & 0xff00) |
        ((wi >>> 24) & 0xff)) >>>
      0;
    if (sw !== 0) return zeros + Math.clz32(sw);
    zeros += 32;
  }
  return 256;
}

function blake3G(s: Uint32Array, a: number, b: number, c: number, d: number, mx: number, my: number) {
  let va = (s[a] + s[b] + mx) | 0;
  let vd = s[d] ^ va;
  vd = (vd >>> 16) | (vd << 16);
  let vc = (s[c] + vd) | 0;
  let vb = s[b] ^ vc;
  vb = (vb >>> 12) | (vb << 20);
  va = (va + vb + my) | 0;
  vd = vd ^ va;
  vd = (vd >>> 8) | (vd << 24);
  vc = (vc + vd) | 0;
  vb = vb ^ vc;
  vb = (vb >>> 7) | (vb << 25);

  s[a] = va >>> 0;
  s[b] = vb >>> 0;
  s[c] = vc >>> 0;
  s[d] = vd >>> 0;
}

function blake3Compress(cv: Uint32Array, block: Uint32Array, blockLen: number, flags: number) {
  for (let i = 0; i < 8; i++) b3State[i] = cv[i];
  b3State[8] = BLAKE3_IV[0];
  b3State[9] = BLAKE3_IV[1];
  b3State[10] = BLAKE3_IV[2];
  b3State[11] = BLAKE3_IV[3];
  b3State[12] = 0;
  b3State[13] = 0;
  b3State[14] = blockLen;
  b3State[15] = flags;

  for (let i = 0; i < 16; i++) b3Msg[i] = block[i];

  for (let round = 0; round < 7; round++) {
    blake3G(b3State, 0, 4, 8, 12, b3Msg[0], b3Msg[1]);
    blake3G(b3State, 1, 5, 9, 13, b3Msg[2], b3Msg[3]);
    blake3G(b3State, 2, 6, 10, 14, b3Msg[4], b3Msg[5]);
    blake3G(b3State, 3, 7, 11, 15, b3Msg[6], b3Msg[7]);
    blake3G(b3State, 0, 5, 10, 15, b3Msg[8], b3Msg[9]);
    blake3G(b3State, 1, 6, 11, 12, b3Msg[10], b3Msg[11]);
    blake3G(b3State, 2, 7, 8, 13, b3Msg[12], b3Msg[13]);
    blake3G(b3State, 3, 4, 9, 14, b3Msg[14], b3Msg[15]);

    if (round < 6) {
      for (let i = 0; i < 16; i++) b3MsgTmp[i] = b3Msg[BLAKE3_MSG_PERM[i]];
      for (let i = 0; i < 16; i++) b3Msg[i] = b3MsgTmp[i];
    }
  }

  for (let i = 0; i < 8; i++) {
    b3State[i] = (b3State[i] ^ b3State[i + 8]) >>> 0;
  }
}

function hashBlake3Eco(nonceLE: number): number {
  for (let i = 0; i < 16; i++) b3Msg[i] = headerWordsLE[i];
  blake3Compress(BLAKE3_IV, b3Msg, 64, 1);
  for (let i = 0; i < 8; i++) b3Cv[i] = b3State[i];

  b3Msg[0] = headerWordsLE[16];
  b3Msg[1] = headerWordsLE[17];
  b3Msg[2] = headerWordsLE[18];
  b3Msg[3] = nonceLE >>> 0;
  for (let i = 4; i < 16; i++) b3Msg[i] = 0;
  blake3Compress(b3Cv, b3Msg, 16, 10);

  for (let i = 0; i < 8; i++) hashOut[i] = b3State[i];

  let zeros = 0;
  for (let i = 0; i < 8; i++) {
    const w = hashOut[i];
    if (w !== 0) return zeros + Math.clz32(w);
    zeros += 32;
  }
  return 256;
}

const YESPOWER_PARAMS_SUGAR: YespowerParams = {
  version: 10,
  N: 2048,
  r: 32,
  pers: YESPOWER_PERS.SUGAR,
};
const YESPOWER_PARAMS_ADVC: YespowerParams = {
  version: 10,
  N: 2048,
  r: 32,
  pers: YESPOWER_PERS.ADVC,
};
const YESPOWER_PARAMS_ARM: YespowerParams = {
  version: 10,
  N: 2048,
  r: 32,
  pers: null,
};

function getYespowerParamsFor(algo: MiningAlgorithm): YespowerParams {
  if (algo === 'yespower_sugar') return YESPOWER_PARAMS_SUGAR;
  if (algo === 'yespower_advc') return YESPOWER_PARAMS_ADVC;
  return YESPOWER_PARAMS_ARM;
}

function isYespowerAlgo(algo: MiningAlgorithm): boolean {
  return algo === 'yespower_advc' || algo === 'yespower_sugar' || algo === 'yespower_arm';
}

function digestToHex(out: Uint32Array, reverseForBitcoin: boolean): string {
  let hex = '';
  if (reverseForBitcoin) {
    for (let i = 7; i >= 0; i--) {
      const w = out[i];
      const sw =
        (((w & 0xff) << 24) |
          ((w & 0xff00) << 8) |
          ((w >>> 8) & 0xff00) |
          ((w >>> 24) & 0xff)) >>>
        0;
      hex += sw.toString(16).padStart(8, '0');
    }
  } else {
    for (let i = 0; i < 8; i++) {
      hex += (out[i] >>> 0).toString(16).padStart(8, '0');
    }
  }
  return hex;
}

function digestBytesLEToHexBE(bytesLE: Uint8Array): string {
  let hex = '';
  for (let i = 31; i >= 0; i--) {
    hex += bytesLE[i].toString(16).padStart(2, '0');
  }
  return hex;
}

let running = false;
let timerId: number | null = null;
let workerId = 0;
let algorithm: MiningAlgorithm = 'yespower_advc';
let targetZeroBits = 16;
let poolDifficulty = 0;
let targetBE: Uint8Array | null = null;
let nonce = 0;
let stride = 1;
let dutyCycle = 60;
let jobId = 'local-0';
let extranonce2 = '00000001';
let ntime = '';
let hashesSinceReport = 0;
let lastReportAt = 0;
let batchSize = 4096;

function rebuildTarget() {
  if (poolDifficulty > 0) {
    targetBE = difficultyToTarget256BE(poolDifficulty, isYespowerAlgo(algorithm) ? 240 : 224);
  } else {
    targetBE = null;
  }
}

function runSlice() {
  if (!running) return;

  const t0 = performance.now();
  let foundNonce = -1;
  let foundZeros = 0;
  let foundDigestHex = '';

  if (algorithm === 'sha256d') {
    for (let i = 0; i < batchSize; i++) {
      const zeros = hashSha256d(nonce);
      let matched = false;
      if (targetBE !== null) {
        for (let w = 0; w < 8; w++) {
          const v = hashOut[w];
          shaHashLE[w * 4] = (v >>> 24) & 0xff;
          shaHashLE[w * 4 + 1] = (v >>> 16) & 0xff;
          shaHashLE[w * 4 + 2] = (v >>> 8) & 0xff;
          shaHashLE[w * 4 + 3] = v & 0xff;
        }
        matched = hashLEMeetsTargetBE(shaHashLE, targetBE);
      } else {
        matched = zeros >= targetZeroBits;
      }
      if (matched) {
        foundNonce = nonce;
        foundZeros = zeros;
        foundDigestHex = digestToHex(hashOut, true);
        nonce = (nonce + stride) >>> 0;
        hashesSinceReport += i + 1;
        break;
      }
      nonce = (nonce + stride) >>> 0;
    }
    if (foundNonce === -1) hashesSinceReport += batchSize;
  } else if (algorithm === 'blake3_eco') {
    for (let i = 0; i < batchSize; i++) {
      const zeros = hashBlake3Eco(nonce);
      if (zeros >= targetZeroBits) {
        foundNonce = nonce;
        foundZeros = zeros;
        foundDigestHex = digestToHex(hashOut, false);
        nonce = (nonce + stride) >>> 0;
        hashesSinceReport += i + 1;
        break;
      }
      nonce = (nonce + stride) >>> 0;
    }
    if (foundNonce === -1) hashesSinceReport += batchSize;
  } else {
    const ypParams = getYespowerParamsFor(algorithm);
    const ypBatch = batchSize;
    for (let i = 0; i < ypBatch; i++) {
      const n = nonce >>> 0;
      headerBytes[76] = n & 0xff;
      headerBytes[77] = (n >>> 8) & 0xff;
      headerBytes[78] = (n >>> 16) & 0xff;
      headerBytes[79] = (n >>> 24) & 0xff;
      try {
        yespowerWs.hash(headerBytes, ypParams, yespowerOut);
      } catch {
        handleRuntimeOom();
        break;
      }
      const zeros = countLeadingZeroBitsLE(yespowerOut);
      const matched = targetBE !== null ? hashLEMeetsTargetBE(yespowerOut, targetBE) : zeros >= targetZeroBits;
      if (matched) {
        foundNonce = n;
        foundZeros = zeros;
        foundDigestHex = digestBytesLEToHexBE(yespowerOut);
        nonce = (nonce + stride) >>> 0;
        hashesSinceReport += i + 1;
        break;
      }
      nonce = (nonce + stride) >>> 0;
    }
    if (foundNonce === -1) hashesSinceReport += ypBatch;
  }

  const sliceMs = Math.max(0.5, performance.now() - t0);
  const sliceHashes = batchSize;

  if (foundNonce === -1) {
    if (isYespowerAlgo(algorithm)) {
      if (sliceMs < 40 && batchSize < 20) batchSize = Math.min(20, batchSize + 1);
      else if (sliceMs > 80 && batchSize > 1) batchSize = Math.max(1, batchSize - 1);
    } else {
      if (sliceMs < 10 && batchSize < 65536) {
        batchSize = Math.min(65536, Math.round(batchSize * 1.4));
      } else if (sliceMs > 30 && batchSize > 256) {
        batchSize = Math.max(256, Math.round(batchSize * 0.7));
      }
    }
  }

  if (foundNonce !== -1) {
    const nonceHex = (foundNonce >>> 0).toString(16).padStart(8, '0');
    self.postMessage({
      type: 'share',
      workerId,
      algorithm,
      jobId,
      extranonce2,
      ntime,
      nonce: foundNonce >>> 0,
      nonceHex,
      digestHex: foundDigestHex,
      leadingZeroBits: foundZeros,
      foundAt: Date.now(),
    });
  }

  const now = performance.now();
  if (isYespowerAlgo(algorithm) && now - lastMemCheckAt >= 10_000) {
    lastMemCheckAt = now;
    const plan = computeDynamicCachePlan(stride, wantRamCache, true);
    estimatedFreeMemMb = plan.estimatedFreeMb;
    memoryGuardActive = plan.memoryGuardActive;
    if (plan.targetCacheMb < allocatedCacheMb) {
      applyDynamicCachePlan(true);
    }
  }

  const reportElapsed = now - lastReportAt;
  if (reportElapsed >= 400) {
    const hashrate = (hashesSinceReport * 1000) / reportElapsed;
    self.postMessage({
      type: 'stats',
      workerId,
      hashes: hashesSinceReport,
      hashrate,
      sliceMs,
      msPerHash: sliceMs / Math.max(1, sliceHashes),
      wasmActive: yespowerWs.isWasmActive,
      simdActive: yespowerWs.isSimdActive,
      cacheMb: isYespowerAlgo(algorithm)
        ? Math.max(9, Math.round(yespowerWs.cacheBytes / (1024 * 1024)) || allocatedCacheMb)
        : 0,
      freeMemMb: estimatedFreeMemMb,
      memoryGuardActive,
    });
    hashesSinceReport = 0;
    lastReportAt = now;
  }

  const clampedDuty = Math.max(15, Math.min(100, dutyCycle));
  const sleepMs =
    clampedDuty >= 98
      ? 0
      : Math.min(120, Math.round(sliceMs * ((100 - clampedDuty) / clampedDuty)));
  timerId = self.setTimeout(runSlice, sleepMs);
}

self.onmessage = (e: MessageEvent<IncomingMessage>) => {
  const msg = e.data;
  if (msg.type === 'start') {
    if (timerId !== null) clearTimeout(timerId);
    workerId = msg.workerId;
    algorithm = msg.algorithm;
    targetZeroBits = msg.targetZeroBits;
    poolDifficulty = typeof msg.poolDifficulty === 'number' ? msg.poolDifficulty : 0;
    rebuildTarget();
    nonce = msg.startNonce >>> 0;
    stride = Math.max(1, msg.stride);
    dutyCycle = msg.dutyCycle;
    jobId = msg.jobId;
    extranonce2 = msg.extranonce2 ?? '00000001';
    ntime = msg.ntime ?? '';
    if (typeof msg.deviceMemoryGb === 'number' && msg.deviceMemoryGb > 0) {
      deviceMemoryHintGb = msg.deviceMemoryGb;
    }
    if (typeof msg.freeHeapMbHint === 'number' && msg.freeHeapMbHint > 0) {
      freeHeapHintMb = msg.freeHeapMbHint;
    }
    wantRamCache = msg.useRamCache !== false;
    oomEmergencyMode = false;

    hexToWords(msg.headerHex);
    if (algorithm === 'sha256d') computeMidstate();

    applyDynamicCachePlan(true);

    hashesSinceReport = 0;
    lastReportAt = performance.now();
    lastMemCheckAt = lastReportAt;
    batchSize = isYespowerAlgo(algorithm)
      ? yespowerWs.isSimdActive
        ? 8
        : yespowerWs.isWasmActive
          ? 5
          : 1
      : 8192;
    running = true;
    runSlice();
  } else if (msg.type === 'config') {
    if (typeof msg.dutyCycle === 'number') dutyCycle = msg.dutyCycle;
    if (typeof msg.freeHeapMbHint === 'number' && msg.freeHeapMbHint > 0) {
      freeHeapHintMb = msg.freeHeapMbHint;
    }
    if (typeof msg.useRamCache === 'boolean') {
      wantRamCache = msg.useRamCache;
      oomEmergencyMode = false;
      applyDynamicCachePlan(true);
    }
    if (typeof msg.targetZeroBits === 'number') targetZeroBits = msg.targetZeroBits;
    if (typeof msg.poolDifficulty === 'number') {
      poolDifficulty = msg.poolDifficulty;
      rebuildTarget();
    }
    if (typeof msg.jobId === 'string') jobId = msg.jobId;
    if (typeof msg.extranonce2 === 'string') extranonce2 = msg.extranonce2;
    if (typeof msg.ntime === 'string') ntime = msg.ntime;
    if (typeof msg.headerHex === 'string') {
      hexToWords(msg.headerHex);
      if (algorithm === 'sha256d') computeMidstate();
    }
  } else if (msg.type === 'stop') {
    running = false;
    if (timerId !== null) {
      clearTimeout(timerId);
      timerId = null;
    }
    yespowerWs.releaseWasmForLowMemory();
  }
};
