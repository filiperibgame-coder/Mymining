import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  Battery,
  BatteryCharging,
  Cpu,
  Gauge,
  HardDrive,
  Moon,
  Play,
  Plug,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  Square,
  Unplug,
  Wallet,
  X,
} from 'lucide-react';
import {
  ALGORITHM_SPECS,
  POWER_PROFILES,
  ZPOOL_COINS,
  createBlockHeader,
  difficultyToZeroBits,
  formatClock,
  formatHashrate,
  getDeviceHardware,
  validateZpoolWalletAddress,
  type PowerProfileId,
  type ZpoolCoinSpec,
} from './lib/ecoEngine';
import type { MiningAlgorithm } from './workers/miner.worker';
import { HashChart, type HashSample } from './components/HashChart';
import {
  PoolsPanel,
  type MarketPrices,
  type PoolLogItem,
  type StratumConnectOverride,
  type StratumJobState,
  type ZpoolWalletInfo,
} from './components/PoolsPanel';
import { AlgorithmsPanel } from './components/AlgorithmsPanel';
import { AndroidExportPanel } from './components/AndroidExportPanel';
import { GoogleDrivePanel } from './components/GoogleDrivePanel';
import { PWAInstallControl } from './components/PWAInstallControl';
import type { ArmhashDriveBackup } from './lib/googleDrive';

type NavTab = 'miner' | 'pools' | 'algorithms' | 'android' | 'drive';

interface ProofRow {
  id: string;
  time: string;
  algorithm: MiningAlgorithm;
  jobId: string;
  headerHex: string;
  nonce: number;
  nonceHex: string;
  digestHex: string;
  zeroBits: number;
  status: 'local' | 'submitted' | 'accepted' | 'rejected';
  verified?: boolean;
}

interface BatteryLike extends EventTarget {
  level: number;
  charging: boolean;
}

export default function App() {
  const hw = useMemo(() => getDeviceHardware(), []);
  const defaultThreads = Math.max(1, Math.round(hw.cores * POWER_PROFILES.balanced.threadRatio));

  const [tab, setTab] = useState<NavTab>('miner');
  const [poolsInitialSubTab, setPoolsInitialSubTab] = useState<'zpool' | 'unmineable' | 'verus' | 'custom'>('zpool');
  const [algorithm, setAlgorithm] = useState<MiningAlgorithm>('yespower_advc');
  const [powerProfile, setPowerProfile] = useState<PowerProfileId>('balanced');
  const [threads, setThreads] = useState<number>(defaultThreads);
  const [dutyCycle, setDutyCycle] = useState<number>(POWER_PROFILES.balanced.dutyCycle);
  const [localDiff, setLocalDiff] = useState<number>(7);

  const [isMining, setIsMining] = useState(false);
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isCharging, setIsCharging] = useState(true);
  const [pauseLowBat, setPauseLowBat] = useState(true);
  const [pausedByBat, setPausedByBat] = useState(false);
  const [keepAwake, setKeepAwake] = useState(true);
  const [amoledMode, setAmoledMode] = useState(false);
  const [autoThermalGuard, setAutoThermalGuard] = useState(true);
  const [thermalCooling, setThermalCooling] = useState(false);
  const [useRamCache, setUseRamCache] = useState(true);
  const [neverDisconnect, setNeverDisconnect] = useState(true);

  const [hashrate, setHashrate] = useState(0);
  const [totalHashes, setTotalHashes] = useState(0);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [samples, setSamples] = useState<HashSample[]>([]);
  const [proofs, setProofs] = useState<ProofRow[]>([]);
  const [blockHeight, setBlockHeight] = useState(1);
  const [headerHex, setHeaderHex] = useState(() => createBlockHeader(1, 7).headerHex);
  const [jobId, setJobId] = useState('blk-1');

  // Direct Wallet & Earnings State (Zpool real payouts)
  const [zCoin, setZCoin] = useState<ZpoolCoinSpec['code']>(() => {
    try {
      const saved = localStorage.getItem('armhash_zpool_coin');
      if (saved && ZPOOL_COINS.some((c) => c.code === saved)) {
        return saved as ZpoolCoinSpec['code'];
      }
    } catch {
      // ignore
    }
    return 'LTC';
  });
  const [zAddress, setZAddress] = useState<string>(() => {
    try {
      return localStorage.getItem('armhash_zpool_address') ?? '';
    } catch {
      return '';
    }
  });
  const [zWallet, setZWallet] = useState<ZpoolWalletInfo | null>(null);
  const [zLoading, setZLoading] = useState(false);
  const [zError, setZError] = useState<string | null>(null);
  const [prices, setPrices] = useState<MarketPrices>({});
  const [zpoolEstimateMbtc, setZpoolEstimateMbtc] = useState<{ advc: number; sugar: number }>({
    advc: 0,
    sugar: 0,
  });

  // Stratum State
  const [stratumHost, setStratumHost] = useState('yespowerADVC.na.mine.zpool.ca');
  const [stratumPort, setStratumPort] = useState('6248');
  const [stratumWorker, setStratumWorker] = useState('');
  const [stratumPass, setStratumPass] = useState('c=LTC,d=0.005');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [connected, setConnected] = useState(false);
  const [subscribed, setSubscribed] = useState(false);
  const [authorized, setAuthorized] = useState(false);
  const [acceptedCount, setAcceptedCount] = useState(0);
  const [rejectedCount, setRejectedCount] = useState(0);
  const [poolError, setPoolError] = useState<string | null>(null);
  const [stratumJob, setStratumJob] = useState<StratumJobState | null>(null);
  const [poolLogs, setPoolLogs] = useState<PoolLogItem[]>([]);
  const [wasmActive, setWasmActive] = useState<boolean>(true);
  const [simdActive, setSimdActive] = useState<boolean>(true);
  const [cacheMbPerThread, setCacheMbPerThread] = useState<number>(16);
  const [memoryGuardActive, setMemoryGuardActive] = useState<boolean>(false);
  const [reconnecting, setReconnecting] = useState<boolean>(false);

  const workersRef = useRef<Worker[]>([]);
  const ratesRef = useRef<Map<number, number>>(new Map());
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);
  const esRef = useRef<EventSource | null>(null);
  const sessionIdRef = useRef<string | null>(null);
  const activeHeaderRef = useRef<string>(headerHex);
  const pendingAutoStartRef = useRef<boolean>(false);
  const pendingAlgoRef = useRef<MiningAlgorithm>('yespower_advc');
  const authLoggedRef = useRef<boolean | null>(null);
  const walletInputRef = useRef<HTMLInputElement | null>(null);
  const manualDisconnectRef = useRef<boolean>(false);
  const lastConnectConfigRef = useRef<StratumConnectOverride | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const reconnectAttemptsRef = useRef<number>(0);
  const msPerHashRef = useRef<Map<number, number>>(new Map());
  const baselineMsPerHashRef = useRef<number | null>(null);
  const throttleStrikesRef = useRef<number>(0);
  const coolRecoverStrikesRef = useRef<number>(0);
  const miningStartedAtRef = useRef<number>(0);
  const neverDisconnectRef = useRef<boolean>(neverDisconnect);
  const isMiningRef = useRef<boolean>(isMining);
  const connectedRef = useRef<boolean>(connected);
  const connectingRef = useRef<boolean>(connecting);
  const wasMiningBeforeDropRef = useRef<boolean>(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const audioOscRef = useRef<OscillatorNode | null>(null);
  const bgLockAbortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    neverDisconnectRef.current = neverDisconnect;
  }, [neverDisconnect]);
  useEffect(() => {
    isMiningRef.current = isMining;
    if (isMining) wasMiningBeforeDropRef.current = true;
  }, [isMining]);
  useEffect(() => {
    connectedRef.current = connected;
  }, [connected]);
  useEffect(() => {
    connectingRef.current = connecting;
  }, [connecting]);

  useEffect(() => {
    try {
      localStorage.setItem('armhash_zpool_coin', zCoin);
    } catch {
      // ignore
    }
  }, [zCoin]);

  useEffect(() => {
    try {
      localStorage.setItem('armhash_zpool_address', zAddress);
    } catch {
      // ignore
    }
  }, [zAddress]);

  useEffect(() => {
    fetch('/api/market-prices')
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d) setPrices(d);
      })
      .catch(() => {});

    fetch('/api/pool/zpool-status')
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d) {
          setZpoolEstimateMbtc({
            advc: Number(d.yespowerADVC?.estimate_current ?? 0),
            sugar: Number(d.yespowerSUGAR?.estimate_current ?? 0),
          });
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    sessionIdRef.current = sessionId;
  }, [sessionId]);

  useEffect(() => {
    activeHeaderRef.current = headerHex;
  }, [headerHex]);

  const addLog = useCallback((kind: PoolLogItem['kind'], message: string) => {
    const time = new Date().toTimeString().slice(0, 8);
    setPoolLogs((prev) => [{ id: `${Date.now()}-${Math.random()}`, time, kind, message }, ...prev.slice(0, 49)]);
  }, []);

  // Battery API
  useEffect(() => {
    const nav = navigator as Navigator & { getBattery?: () => Promise<BatteryLike> };
    if (!nav.getBattery) return;
    let bat: BatteryLike | null = null;
    const sync = () => {
      if (!bat) return;
      setBatteryLevel(Math.round(bat.level * 100));
      setIsCharging(bat.charging);
    };
    nav
      .getBattery()
      .then((b) => {
        bat = b;
        sync();
        b.addEventListener('levelchange', sync);
        b.addEventListener('chargingchange', sync);
      })
      .catch(() => {});
    return () => {
      if (bat) {
        bat.removeEventListener('levelchange', sync);
        bat.removeEventListener('chargingchange', sync);
      }
    };
  }, []);

  // Screen WakeLock + automatic re-acquire on Android visibility return
  useEffect(() => {
    const acquire = async () => {
      if (!isMining || !keepAwake || !('wakeLock' in navigator)) return;
      try {
        wakeLockRef.current = await navigator.wakeLock.request('screen');
      } catch {
        // ignore
      }
    };
    const release = async () => {
      if (wakeLockRef.current) {
        try {
          await wakeLockRef.current.release();
        } catch {
          // ignore
        }
        wakeLockRef.current = null;
      }
    };
    const onVisibility = () => {
      if (document.visibilityState === 'visible' && isMining && keepAwake) {
        void acquire();
      }
    };
    if (isMining && keepAwake) {
      void acquire();
      document.addEventListener('visibilitychange', onVisibility);
    } else {
      void release();
    }
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      void release();
    };
  }, [isMining, keepAwake]);

  // Silent Background Keep-Alive (AudioContext + Web Lock) so mobile OS doesn't suspend mining
  const stopBgKeepAlive = useCallback(() => {
    if (audioOscRef.current) {
      try {
        audioOscRef.current.stop();
        audioOscRef.current.disconnect();
      } catch {
        // ignore
      }
      audioOscRef.current = null;
    }
    if (audioCtxRef.current) {
      try {
        void audioCtxRef.current.close();
      } catch {
        // ignore
      }
      audioCtxRef.current = null;
    }
    if (bgLockAbortRef.current) {
      try {
        bgLockAbortRef.current.abort();
      } catch {
        // ignore
      }
      bgLockAbortRef.current = null;
    }
  }, []);

  const ensureBgKeepAlive = useCallback(() => {
    if (!neverDisconnectRef.current) return;
    if (typeof window !== 'undefined' && !audioCtxRef.current) {
      try {
        const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (Ctx) {
          const ctx = new Ctx();
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.frequency.value = 1;
          gain.gain.value = 0.00001;
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          if (ctx.state === 'suspended') {
            void ctx.resume().catch(() => {});
          }
          audioCtxRef.current = ctx;
          audioOscRef.current = osc;
        }
      } catch {
        // ignore
      }
    }
    if (typeof navigator !== 'undefined' && 'locks' in navigator && !bgLockAbortRef.current) {
      try {
        const ac = new AbortController();
        bgLockAbortRef.current = ac;
        void navigator.locks
          .request('armhash-mining-keepalive', { signal: ac.signal }, () => new Promise(() => {}))
          .catch(() => {});
      } catch {
        // ignore
      }
    }
  }, []);

  useEffect(() => {
    if (isMining && neverDisconnect) {
      ensureBgKeepAlive();
    } else {
      stopBgKeepAlive();
    }
    return () => {
      stopBgKeepAlive();
    };
  }, [isMining, neverDisconnect, ensureBgKeepAlive, stopBgKeepAlive]);

  const stopWorkers = useCallback(() => {
    workersRef.current.forEach((w) => {
      w.postMessage({ type: 'stop' });
      w.terminate();
    });
    workersRef.current = [];
    ratesRef.current.clear();
    setHashrate(0);
  }, []);

  useEffect(() => {
    if (isMining && pauseLowBat && batteryLevel !== null && !isCharging && batteryLevel < 25) {
      stopWorkers();
      setIsMining(false);
      setPausedByBat(true);
    }
  }, [isMining, pauseLowBat, batteryLevel, isCharging, stopWorkers]);

  const startMining = useCallback(
    (opts?: { algorithmOverride?: MiningAlgorithm; jobOverride?: StratumJobState }) => {
      stopWorkers();
      setPausedByBat(false);

      const algoToUse = opts?.algorithmOverride ?? algorithm;
      const activeJob = opts?.jobOverride ?? (connected && stratumJob ? stratumJob : null);
      const targetBits = activeJob ? difficultyToZeroBits(activeJob.difficulty, algoToUse) : localDiff;
      const poolDifficulty = activeJob ? activeJob.difficulty : 0;
      const activeHeader = activeJob ? activeJob.headerHex : headerHex;
      const activeJobId = activeJob ? activeJob.jobId : jobId;
      activeHeaderRef.current = activeHeader;
      const n = Math.max(1, Math.min(hw.cores, threads));

      msPerHashRef.current.clear();
      baselineMsPerHashRef.current = null;
      throttleStrikesRef.current = 0;
      coolRecoverStrikesRef.current = 0;
      miningStartedAtRef.current = Date.now();
      setThermalCooling(false);

      const list: Worker[] = [];
      for (let i = 0; i < n; i++) {
        const w = new Worker(new URL('./workers/miner.worker.ts', import.meta.url), {
          type: 'module',
        });
        w.onmessage = (ev) => {
          const msg = ev.data;
          if (!msg) return;
          if (msg.type === 'stats') {
            if (typeof msg.wasmActive === 'boolean') setWasmActive(msg.wasmActive);
            if (typeof msg.simdActive === 'boolean') setSimdActive(msg.simdActive);
            if (typeof msg.cacheMb === 'number' && msg.cacheMb > 0) setCacheMbPerThread(msg.cacheMb);
            if (typeof msg.memoryGuardActive === 'boolean') setMemoryGuardActive(msg.memoryGuardActive);
            ratesRef.current.set(msg.workerId, Number(msg.hashrate ?? 0));
            if (typeof msg.msPerHash === 'number' && Number.isFinite(msg.msPerHash) && msg.msPerHash > 0) {
              msPerHashRef.current.set(msg.workerId, msg.msPerHash);
            }
            let sum = 0;
            ratesRef.current.forEach((v) => {
              sum += v;
            });
            setHashrate(sum);
            setTotalHashes((prev) => prev + Number(msg.hashes ?? 0));
          } else if (msg.type === 'share') {
            const sid = sessionIdRef.current;
            const time = new Date().toTimeString().slice(0, 8);
            const canSubmit = Boolean(sid && ALGORITHM_SPECS[msg.algorithm as MiningAlgorithm]?.stratumReady);
            setProofs((prev) => [
              {
                id: `${Date.now()}-${msg.nonceHex}`,
                time,
                algorithm: msg.algorithm,
                jobId: msg.jobId,
                headerHex: activeHeaderRef.current,
                nonce: msg.nonce,
                nonceHex: msg.nonceHex,
                digestHex: msg.digestHex,
                zeroBits: msg.leadingZeroBits,
                status: canSubmit ? 'submitted' : 'local',
              },
              ...prev.slice(0, 39),
            ]);

            if (canSubmit && sid) {
              fetch('/api/stratum/submit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  sessionId: sid,
                  jobId: msg.jobId,
                  extranonce2: msg.extranonce2 ?? '00000001',
                  ntime: msg.ntime ?? '',
                  nonceHex: msg.nonceHex,
                }),
              })
                .then(() => addLog('info', `Share submetido: nonce=${msg.nonceHex}`))
                .catch(() => addLog('error', `Erro ao enviar share nonce=${msg.nonceHex}`));
            } else {
              setBlockHeight((prevH) => {
                const nextH = prevH + 1;
                const nextBlk = createBlockHeader(nextH, localDiff);
                activeHeaderRef.current = nextBlk.headerHex;
                setHeaderHex(nextBlk.headerHex);
                setJobId(nextBlk.jobId);
                workersRef.current.forEach((wk) => {
                  wk.postMessage({
                    type: 'config',
                    headerHex: nextBlk.headerHex,
                    jobId: nextBlk.jobId,
                  });
                });
                return nextH;
              });
            }
          }
        };

        const navMem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory;
        const perfMem = (performance as Performance & { memory?: { jsHeapSizeLimit?: number; usedJSHeapSize?: number } }).memory;
        const freeHeapMbHint =
          perfMem?.jsHeapSizeLimit && perfMem?.usedJSHeapSize !== undefined
            ? Math.max(16, Math.round((perfMem.jsHeapSizeLimit - perfMem.usedJSHeapSize) / (1024 * 1024)))
            : undefined;

        w.postMessage({
          type: 'start',
          workerId: i,
          algorithm: algoToUse,
          headerHex: activeHeader,
          targetZeroBits: targetBits,
          poolDifficulty,
          startNonce: i,
          stride: n,
          dutyCycle,
          useRamCache,
          deviceMemoryGb: typeof navMem === 'number' ? navMem : undefined,
          freeHeapMbHint,
          jobId: activeJobId,
          extranonce2: activeJob?.extranonce2 ?? '00000001',
          ntime: activeJob?.ntime ?? '',
        });
        list.push(w);
      }

      workersRef.current = list;
      setIsMining(true);
      wasMiningBeforeDropRef.current = true;
      ensureBgKeepAlive();
    },
    [
      stopWorkers,
      connected,
      stratumJob,
      localDiff,
      headerHex,
      jobId,
      hw.cores,
      threads,
      algorithm,
      dutyCycle,
      useRamCache,
      addLog,
      ensureBgKeepAlive,
    ]
  );

  const stopMining = useCallback(() => {
    wasMiningBeforeDropRef.current = false;
    stopWorkers();
    setIsMining(false);
    setThermalCooling(false);
    stopBgKeepAlive();
  }, [stopWorkers, stopBgKeepAlive]);

  const effectiveDutyCycle = useMemo(
    () => (autoThermalGuard && thermalCooling ? Math.max(45, dutyCycle - 15) : dutyCycle),
    [autoThermalGuard, thermalCooling, dutyCycle]
  );

  useEffect(() => {
    if (!isMining) return;
    const targetBits = connected && stratumJob ? difficultyToZeroBits(stratumJob.difficulty, algorithm) : localDiff;
    const poolDifficulty = connected && stratumJob ? stratumJob.difficulty : 0;
    workersRef.current.forEach((w) => {
      w.postMessage({
        type: 'config',
        dutyCycle: effectiveDutyCycle,
        useRamCache,
        targetZeroBits: targetBits,
        poolDifficulty,
      });
    });
  }, [effectiveDutyCycle, useRamCache, localDiff, isMining, connected, stratumJob, algorithm]);

  useEffect(() => {
    if (pausedByBat && (isCharging || (batteryLevel !== null && batteryLevel >= 28))) {
      setPausedByBat(false);
      addLog('info', 'Bateria restabelecida — retomando mineração automaticamente.');
      startMining();
    }
  }, [pausedByBat, isCharging, batteryLevel, addLog, startMining]);

  // Automatic Thermal Governor: monitors ms/hash drift for Android SoC throttling
  useEffect(() => {
    if (!isMining || !autoThermalGuard) {
      setThermalCooling(false);
      return;
    }
    const id = window.setInterval(() => {
      if (msPerHashRef.current.size === 0) return;
      let sum = 0;
      msPerHashRef.current.forEach((v) => {
        sum += v;
      });
      const avgMs = sum / msPerHashRef.current.size;
      const elapsedMs = Date.now() - miningStartedAtRef.current;

      if (elapsedMs < 8000) {
        baselineMsPerHashRef.current =
          baselineMsPerHashRef.current === null
            ? avgMs
            : baselineMsPerHashRef.current * 0.7 + avgMs * 0.3;
        return;
      }

      const base = baselineMsPerHashRef.current;
      if (!base || base <= 0) {
        baselineMsPerHashRef.current = avgMs;
        return;
      }

      if (avgMs > base * 1.28) {
        throttleStrikesRef.current += 1;
        coolRecoverStrikesRef.current = 0;
        if (throttleStrikesRef.current >= 3 && !thermalCooling) {
          setThermalCooling(true);
          addLog('info', 'Throttling térmico detectado — reduzindo duty-cycle em 15% para resfriar o aparelho.');
        }
      } else if (avgMs < base * 1.15) {
        throttleStrikesRef.current = 0;
        if (thermalCooling) {
          coolRecoverStrikesRef.current += 1;
          if (coolRecoverStrikesRef.current >= 5) {
            setThermalCooling(false);
            coolRecoverStrikesRef.current = 0;
            addLog('info', 'Temperatura estabilizada — restaurando velocidade configurada.');
          }
        } else {
          // Track cool baseline slowly
          baselineMsPerHashRef.current = base * 0.92 + avgMs * 0.08;
        }
      }
    }, 2000);
    return () => window.clearInterval(id);
  }, [isMining, autoThermalGuard, thermalCooling, addLog]);

  const spec = ALGORITHM_SPECS[algorithm];
  const estWatts = useMemo(
    () => (isMining ? Number((threads * spec.wattsPerThread * (effectiveDutyCycle / 100)).toFixed(2)) : 0),
    [isMining, threads, spec.wattsPerThread, effectiveDutyCycle]
  );
  const efficiencyHpW = isMining && estWatts > 0 ? hashrate / estWatts : 0;

  useEffect(() => {
    if (!isMining) return;
    const id = window.setInterval(() => {
      setElapsedSec((s) => s + 1);
      setSamples((prev) => [...prev, { ts: Date.now(), hps: hashrate }].slice(-60));
    }, 1000);
    return () => window.clearInterval(id);
  }, [isMining, hashrate]);

  useEffect(() => {
    return () => {
      stopWorkers();
      if (esRef.current) esRef.current.close();
    };
  }, [stopWorkers]);

  const handleSelectAlgorithm = (next: MiningAlgorithm) => {
    setAlgorithm(next);
    if (!connected) {
      const isYp = next === 'yespower_advc' || next === 'yespower_sugar' || next === 'yespower_arm';
      setLocalDiff(isYp ? 7 : 15);
    }
    if (isMining) {
      stopWorkers();
      setIsMining(false);
    }
  };

  const handleSelectPower = (mode: PowerProfileId) => {
    setPowerProfile(mode);
    const p = POWER_PROFILES[mode];
    setDutyCycle(p.dutyCycle);
    setThreads(Math.max(1, Math.round(hw.cores * p.threadRatio)));
  };

  const connectStratumRef = useRef<(override?: StratumConnectOverride) => Promise<void>>(async () => {});

  const scheduleAutoReconnect = useCallback(
    (reason: string, immediate = false) => {
      if (manualDisconnectRef.current || !lastConnectConfigRef.current) return;
      if (!neverDisconnectRef.current && reconnectAttemptsRef.current >= 5) {
        setReconnecting(false);
        return;
      }
      if (reconnectTimerRef.current !== null) {
        if (!immediate) return;
        window.clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      reconnectAttemptsRef.current += 1;
      const cappedAttempt = Math.min(8, reconnectAttemptsRef.current);
      const delayMs = immediate ? 400 : Math.min(15000, 2000 * cappedAttempt);
      setReconnecting(true);
      addLog('info', `${reason} Reconectando automaticamente em ${Math.max(1, Math.round(delayMs / 1000))}s...`);
      reconnectTimerRef.current = window.setTimeout(() => {
        reconnectTimerRef.current = null;
        if (!manualDisconnectRef.current && lastConnectConfigRef.current) {
          void connectStratumRef.current({
            ...lastConnectConfigRef.current,
            autoStartMining: wasMiningBeforeDropRef.current || isMiningRef.current || Boolean(lastConnectConfigRef.current.autoStartMining),
          });
        }
      }, delayMs);
    },
    [addLog]
  );

  const connectStratum = async (override?: StratumConnectOverride) => {
    const targetHost = (override?.host ?? stratumHost).trim();
    const targetPort = (override?.port ?? stratumPort).trim();
    const targetWorker = (override?.worker ?? stratumWorker).trim();
    const targetPass = override?.password ?? stratumPass;
    const targetAlgo: MiningAlgorithm =
      override?.algorithm ?? (algorithm === 'blake3_eco' ? 'yespower_advc' : algorithm);

    if (override?.host !== undefined) setStratumHost(override.host);
    if (override?.port !== undefined) setStratumPort(override.port);
    if (override?.worker !== undefined) setStratumWorker(override.worker);
    if (override?.password !== undefined) setStratumPass(override.password);

    if (!targetHost) {
      setPoolError('Informe o host do pool Stratum (ex: yespowerADVC.na.mine.zpool.ca).');
      return;
    }
    if (!targetWorker || targetWorker.includes('SeuEnderecoAqui')) {
      setPoolError('Informe o endereço da sua carteira real antes de conectar ao pool.');
      return;
    }

    if (esRef.current) {
      esRef.current.close();
      esRef.current = null;
    }
    if (sessionIdRef.current) {
      fetch('/api/stratum/disconnect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: sessionIdRef.current }),
      }).catch(() => {});
      sessionIdRef.current = null;
    }

    if (reconnectTimerRef.current !== null) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    manualDisconnectRef.current = false;
    lastConnectConfigRef.current = {
      host: targetHost,
      port: targetPort,
      worker: targetWorker,
      password: targetPass,
      algorithm: targetAlgo,
      autoStartMining: override?.autoStartMining ?? true,
    };

    setPoolError(null);
    setSubscribed(false);
    setAuthorized(false);
    if (!override?.autoStartMining) {
      setAcceptedCount(0);
      setRejectedCount(0);
    }
    setStratumJob(null);
    authLoggedRef.current = null;
    pendingAlgoRef.current = targetAlgo;
    pendingAutoStartRef.current = Boolean(override?.autoStartMining);

    if (algorithm !== targetAlgo) {
      setAlgorithm(targetAlgo);
    }

    setConnecting(true);
    try {
      const resp = await fetch('/api/stratum/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          host: targetHost,
          port: Number(targetPort) || 3333,
          worker: targetWorker,
          password: targetPass,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        pendingAutoStartRef.current = false;
        setPoolError(data.error ?? 'Falha ao conectar.');
        setConnecting(false);
        if (neverDisconnectRef.current && !manualDisconnectRef.current) {
          scheduleAutoReconnect(data.error ?? 'Falha ao conectar.');
        }
        return;
      }
      reconnectAttemptsRef.current = 0;
      setReconnecting(false);
      const sid = String(data.sessionId);
      sessionIdRef.current = sid;
      setSessionId(sid);
      setConnected(true);
      setStratumHost(String(data.host ?? targetHost));
      setStratumPort(String(data.port ?? targetPort));
      addLog('info', `Socket TCP conectado em ${data.host}:${data.port} (${ALGORITHM_SPECS[targetAlgo].shortName})`);

      const es = new EventSource(`/api/stratum/stream?sessionId=${encodeURIComponent(sid)}`);
      esRef.current = es;

      es.addEventListener('status', (ev) => {
        const p = JSON.parse((ev as MessageEvent).data);
        if (p.connected === false) {
          pendingAutoStartRef.current = false;
          setConnected(false);
          setSubscribed(false);
          setAuthorized(false);
          setSessionId(null);
          sessionIdRef.current = null;
          setPoolError(p.reason ?? 'Desconectado pelo pool.');
          addLog('error', p.reason ?? 'Desconectado.');
          es.close();
          scheduleAutoReconnect('Conexão encerrada.');
          return;
        }
        setReconnecting(Boolean(p.reconnecting));
        if (typeof p.subscribed === 'boolean') setSubscribed(p.subscribed);
        if (typeof p.authorized === 'boolean') {
          setAuthorized(p.authorized);
          if ((p.authResolved || p.authorized) && authLoggedRef.current !== p.authorized) {
            authLoggedRef.current = p.authorized;
            if (p.authorized) {
              addLog('accepted', 'Worker autorizado pelo pool.');
            } else {
              const reason = p.authError ? ` (${p.authError})` : '';
              setPoolError(`Autorização recusada pelo pool${reason}. Verifique o endereço da carteira.`);
              addLog('error', `Autorização recusada pelo pool${reason}.`);
            }
          }
        }
      });

      es.addEventListener('difficulty', (ev) => {
        const p = JSON.parse((ev as MessageEvent).data);
        addLog('info', `Dificuldade do pool: ${p.difficulty}`);
        setStratumJob((prev) => (prev ? { ...prev, difficulty: p.difficulty } : prev));
        if (workersRef.current.length > 0) {
          workersRef.current.forEach((wk) => {
            wk.postMessage({
              type: 'config',
              poolDifficulty: p.difficulty,
              targetZeroBits: difficultyToZeroBits(p.difficulty, pendingAlgoRef.current),
            });
          });
        }
      });

      es.addEventListener('job', (ev) => {
        const job = JSON.parse((ev as MessageEvent).data) as StratumJobState;
        setStratumJob(job);
        activeHeaderRef.current = job.headerHex;
        setHeaderHex(job.headerHex);
        setJobId(job.jobId);
        addLog('job', `Novo trabalho recebido: ${job.jobId} (diff=${job.difficulty})`);

        if (pendingAutoStartRef.current) {
          pendingAutoStartRef.current = false;
          const algo = pendingAlgoRef.current;
          setAlgorithm(algo);
          startMining({ algorithmOverride: algo, jobOverride: job });
          addLog('info', `Workers ${ALGORITHM_SPECS[algo].shortName} iniciados com o job do pool.`);
        } else if (workersRef.current.length > 0) {
          workersRef.current.forEach((wk) => {
            wk.postMessage({
              type: 'config',
              headerHex: job.headerHex,
              jobId: job.jobId,
              extranonce2: job.extranonce2,
              ntime: job.ntime,
              poolDifficulty: job.difficulty,
              targetZeroBits: difficultyToZeroBits(job.difficulty, pendingAlgoRef.current),
            });
          });
        }
      });

      es.addEventListener('share_result', (ev) => {
        const r = JSON.parse((ev as MessageEvent).data);
        if (r.accepted) setAcceptedCount((c) => c + 1);
        else setRejectedCount((c) => c + 1);
        addLog(r.accepted ? 'accepted' : 'rejected', r.accepted ? `Share ACEITO (${r.nonceHex})` : `Share rejeitado: ${r.error ?? 'inválido'}`);
        setProofs((prev) =>
          prev.map((row) =>
            row.nonceHex === r.nonceHex && row.jobId === r.jobId
              ? { ...row, status: r.accepted ? 'accepted' : 'rejected' }
              : row
          )
        );
      });

      es.onerror = () => {
        if (sessionIdRef.current === sid) {
          setConnected(false);
          setSubscribed(false);
          setAuthorized(false);
          setSessionId(null);
          sessionIdRef.current = null;
          es.close();
          setPoolError('Conexão SSE com o servidor de pool foi interrompida.');
          addLog('error', 'Stream de eventos Stratum interrompido.');
          scheduleAutoReconnect('Stream SSE caiu.');
        }
      };
    } catch {
      pendingAutoStartRef.current = false;
      setPoolError('Não foi possível conectar ao pool Stratum.');
      if (neverDisconnectRef.current && !manualDisconnectRef.current) {
        scheduleAutoReconnect('Erro de rede ao conectar.');
      }
    } finally {
      setConnecting(false);
    }
  };
  connectStratumRef.current = connectStratum;

  // Global Keep-Alive Watchers: recover immediately on network/visibility return & ping server every 20s
  useEffect(() => {
    const tryImmediateRecovery = (label: string) => {
      if (manualDisconnectRef.current || !lastConnectConfigRef.current || !neverDisconnectRef.current) return;
      if (!connectedRef.current && !connectingRef.current) {
        scheduleAutoReconnect(label, true);
      }
    };

    const onOnline = () => tryImmediateRecovery('Rede restabelecida.');
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        tryImmediateRecovery('Tela reativada.');
      }
    };

    window.addEventListener('online', onOnline);
    document.addEventListener('visibilitychange', onVisible);

    const heartbeat = window.setInterval(() => {
      if (!neverDisconnectRef.current || manualDisconnectRef.current) return;
      const sid = sessionIdRef.current;
      if (!sid) {
        if (lastConnectConfigRef.current && !connectedRef.current && !connectingRef.current) {
          scheduleAutoReconnect('Sessão inativa.', true);
        }
        return;
      }
      fetch(`/api/stratum/ping?sessionId=${encodeURIComponent(sid)}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => {
          if (d && !d.active && sessionIdRef.current === sid && !manualDisconnectRef.current) {
            if (esRef.current) {
              esRef.current.close();
              esRef.current = null;
            }
            sessionIdRef.current = null;
            setSessionId(null);
            setConnected(false);
            setSubscribed(false);
            setAuthorized(false);
            scheduleAutoReconnect('Sessão expirou no servidor.', true);
          }
        })
        .catch(() => {
          // ignore transient offline ping failure; SSE onerror or next tick handles recovery
        });
    }, 20_000);

    return () => {
      window.removeEventListener('online', onOnline);
      document.removeEventListener('visibilitychange', onVisible);
      window.clearInterval(heartbeat);
    };
  }, [scheduleAutoReconnect]);

  const disconnectStratum = async () => {
    manualDisconnectRef.current = true;
    lastConnectConfigRef.current = null;
    setReconnecting(false);
    setPoolError(null);
    if (reconnectTimerRef.current !== null) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    pendingAutoStartRef.current = false;
    if (esRef.current) {
      esRef.current.close();
      esRef.current = null;
    }
    const sid = sessionIdRef.current ?? sessionId;
    if (sid) {
      await fetch('/api/stratum/disconnect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: sid }),
      }).catch(() => {});
    }
    sessionIdRef.current = null;
    setSessionId(null);
    setConnected(false);
    setSubscribed(false);
    setAuthorized(false);
    setStratumJob(null);
    addLog('info', 'Desconectado manualmente pelo usuário.');
  };

  const selectedZpoolCoin = useMemo(
    () => ZPOOL_COINS.find((c) => c.code === zCoin) ?? ZPOOL_COINS[0],
    [zCoin]
  );

  const checkZpoolWallet = useCallback(async (addrOverride?: string) => {
    const cleanAddr = (addrOverride ?? zAddress).trim();
    if (!cleanAddr) return;
    setZLoading(true);
    setZError(null);
    try {
      const resp = await fetch(`/api/pool/zpool-wallet/${encodeURIComponent(cleanAddr)}`);
      const data = await resp.json();
      if (!resp.ok) {
        setZError(data.error ?? 'Falha ao consultar Zpool.');
        setZWallet(null);
      } else {
        setZWallet(data);
      }
    } catch {
      setZError('Erro de conexão ao consultar carteira na Zpool.');
    } finally {
      setZLoading(false);
    }
  }, [zAddress]);

  useEffect(() => {
    if (!connected || !zAddress.trim()) return;
    const id = window.setInterval(() => {
      void checkZpoolWallet();
    }, 45_000);
    return () => window.clearInterval(id);
  }, [connected, zAddress, checkZpoolWallet]);

  const connectZpoolAndMine = () => {
    const check = validateZpoolWalletAddress(zCoin, zAddress);
    if (!check.valid) {
      setZError(check.error ?? 'Endereço de carteira inválido.');
      walletInputRef.current?.focus();
      return;
    }
    setZError(null);
    void connectStratum({
      host: selectedZpoolCoin.host,
      port: selectedZpoolCoin.port,
      worker: check.clean,
      password: `c=${selectedZpoolCoin.code},d=0.005`,
      algorithm: selectedZpoolCoin.algo,
      autoStartMining: true,
    });
  };

  const handlePrimaryMineClick = () => {
    if (isMining) {
      stopMining();
      return;
    }
    if (connected) {
      startMining();
      return;
    }
    const check = validateZpoolWalletAddress(zCoin, zAddress);
    if (check.valid) {
      connectZpoolAndMine();
      return;
    }
    setTab('miner');
    setZError(
      check.error ??
        `Informe sua carteira ${zCoin} no campo abaixo para minerar com ganhos reais na Zpool.`
    );
    window.setTimeout(() => walletInputRef.current?.focus(), 60);
  };

  const estDailyUsd = useMemo(() => {
    if (!isMining || hashrate <= 0 || !prices.bitcoin?.usd) return 0;
    const mbtcPerKhDay =
      algorithm === 'yespower_sugar' ? zpoolEstimateMbtc.sugar : zpoolEstimateMbtc.advc;
    if (!mbtcPerKhDay) return 0;
    const btcPerDay = (hashrate / 1000) * mbtcPerKhDay * 0.001;
    return btcPerDay * prices.bitcoin.usd;
  }, [isMining, hashrate, prices.bitcoin, algorithm, zpoolEstimateMbtc]);

  const estDailyBrl = useMemo(() => {
    if (!estDailyUsd || !prices.bitcoin?.usd || !prices.bitcoin?.brl) return 0;
    return estDailyUsd * (prices.bitcoin.brl / prices.bitcoin.usd);
  }, [estDailyUsd, prices.bitcoin]);

  const verifyProof = async (row: ProofRow) => {
    try {
      const resp = await fetch('/api/verify-pow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          headerHex: row.headerHex,
          nonce: row.nonce,
          algorithm: row.algorithm,
        }),
      });
      const data = await resp.json();
      if (data.verified) {
        setProofs((prev) => prev.map((p) => (p.id === row.id ? { ...p, verified: true } : p)));
      }
    } catch {
      // ignore
    }
  };

  const currentDriveBackup = useMemo<ArmhashDriveBackup>(
    () => ({
      app: 'ARMHash',
      schemaVersion: 1,
      savedAt: new Date().toISOString(),
      appUrl: typeof window !== 'undefined' ? window.location.origin : '',
      wallet: {
        coin: zCoin,
        address: zAddress.trim(),
      },
      stratum: {
        host: stratumHost,
        port: stratumPort,
        worker: stratumWorker,
        password: stratumPass,
      },
      minerConfig: {
        algorithm,
        powerProfile,
        threads,
        dutyCycle,
      },
      sessionSummary: {
        acceptedCount,
        rejectedCount,
        totalHashes,
        recentProofs: proofs.slice(0, 20).map((p) => ({
          time: p.time,
          algorithm: p.algorithm,
          jobId: p.jobId,
          nonceHex: p.nonceHex,
          digestHex: p.digestHex,
          status: p.status,
        })),
      },
    }),
    [
      zCoin,
      zAddress,
      stratumHost,
      stratumPort,
      stratumWorker,
      stratumPass,
      algorithm,
      powerProfile,
      threads,
      dutyCycle,
      acceptedCount,
      rejectedCount,
      totalHashes,
      proofs,
    ]
  );

  const handleRestoreDriveBackup = useCallback(
    (backup: ArmhashDriveBackup) => {
      const coinMatch = ZPOOL_COINS.find((c) => c.code === backup.wallet?.coin);
      if (coinMatch) {
        setZCoin(coinMatch.code);
      }
      if (typeof backup.wallet?.address === 'string') {
        setZAddress(backup.wallet.address);
      }
      if (backup.stratum) {
        if (backup.stratum.host) setStratumHost(backup.stratum.host);
        if (backup.stratum.port) setStratumPort(backup.stratum.port);
        if (typeof backup.stratum.worker === 'string') setStratumWorker(backup.stratum.worker);
        if (typeof backup.stratum.password === 'string') setStratumPass(backup.stratum.password);
      }
      if (backup.minerConfig) {
        if (
          backup.minerConfig.algorithm &&
          backup.minerConfig.algorithm in ALGORITHM_SPECS
        ) {
          setAlgorithm(backup.minerConfig.algorithm as MiningAlgorithm);
        }
        if (
          backup.minerConfig.powerProfile &&
          backup.minerConfig.powerProfile in POWER_PROFILES
        ) {
          setPowerProfile(backup.minerConfig.powerProfile as PowerProfileId);
        }
        if (typeof backup.minerConfig.threads === 'number' && backup.minerConfig.threads >= 1) {
          setThreads(Math.min(hw.cores, Math.max(1, Math.round(backup.minerConfig.threads))));
        }
        if (typeof backup.minerConfig.dutyCycle === 'number') {
          setDutyCycle(Math.min(100, Math.max(20, Math.round(backup.minerConfig.dutyCycle))));
        }
      }
      addLog('info', 'Configuração restaurada do backup no Google Drive.');
    },
    [hw.cores, addLog]
  );

  return (
    <div className="min-h-screen bg-[#0B0F14] text-slate-100 pb-20 md:pb-8">
      {/* Desktop Top Bar — 3-Zone Contract */}
      <header className="hidden md:flex items-center justify-between gap-8 px-6 lg:px-10 h-16 border-b border-[#1E293B] bg-[#0B0F14]/95 sticky top-0 z-30 backdrop-blur-md">
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setTab('miner');
          }}
          className="text-lg font-display font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0"
        >
          ARMHash
        </a>

        <nav className="flex items-center gap-7 text-sm font-medium" aria-label="Navegação principal">
          {(
            [
              { id: 'miner', label: 'Minerador' },
              { id: 'pools', label: 'Pools e Ganhos' },
              { id: 'algorithms', label: 'Algoritmos' },
              { id: 'android', label: 'Android Nativo' },
              { id: 'drive', label: 'Google Drive' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`h-16 px-1 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                tab === item.id ? 'border-emerald-500 text-slate-100' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <button
          type="button"
          onClick={handlePrimaryMineClick}
          disabled={connecting}
          className={`min-h-[40px] px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 disabled:opacity-60 ${
            isMining ? 'bg-rose-600 hover:bg-rose-500 text-white' : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          }`}
        >
          {isMining ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          <span>{connecting ? 'Conectando...' : isMining ? 'Pausar Mineração' : 'Iniciar Mineração'}</span>
        </button>
      </header>

      {/* Mobile Header */}
      <header className="md:hidden sticky top-0 z-30 h-[52px] px-4 border-b border-[#1E293B] bg-[#0B0F14]/95 backdrop-blur-md flex items-center justify-between gap-4">
        <span className="text-base font-display font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0">
          ARMHash
        </span>
        <button
          type="button"
          onClick={handlePrimaryMineClick}
          disabled={connecting}
          className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 disabled:opacity-60 ${
            isMining ? 'bg-rose-600 text-white' : 'bg-emerald-600 text-white'
          }`}
        >
          {isMining ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          <span>{connecting ? 'Conectando' : isMining ? 'Pausar' : 'Minerar'}</span>
        </button>
      </header>

      <main id="top" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-6 space-y-6">
        {tab === 'miner' && (
          <>
            <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-100 tracking-tight text-balance">
                  Mineração Eficiente para Android ARM
                </h1>
                <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-400 mt-1.5">
                  <span>{hw.arch}</span>
                  <span aria-hidden="true">·</span>
                  <span>{hw.deviceLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{hw.cores} núcleos</span>
                  {batteryLevel !== null && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        Bateria {batteryLevel}% ({isCharging ? 'Carregando' : 'Bateria'})
                      </span>
                    </>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <PWAInstallControl />
                <button
                  type="button"
                  onClick={() => setTab('drive')}
                  className="min-h-[44px] px-4 py-2 rounded-lg bg-[#121821] hover:bg-[#19212D] border border-[#1E293B] text-xs font-medium text-slate-200 flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <HardDrive className="w-4 h-4 text-emerald-400" />
                  <span>Salvar no Drive</span>
                </button>
                <button
                  type="button"
                  onClick={() => setAmoledMode(true)}
                  className="min-h-[44px] px-4 py-2 rounded-lg bg-[#121821] hover:bg-[#19212D] border border-[#1E293B] text-xs font-medium text-slate-200 flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <Moon className="w-4 h-4 text-slate-400" />
                  <span>Tela Escura AMOLED</span>
                </button>
              </div>
            </div>

            {pausedByBat && (
              <div className="rounded-xl bg-amber-950/30 border border-amber-500/40 p-4 text-sm text-amber-200 flex items-center justify-between gap-4">
                <span>Mineração pausada automaticamente pela proteção de bateria (&lt; 25% fora do carregador).</span>
                <button
                  type="button"
                  onClick={() => setPausedByBat(false)}
                  className="text-xs underline shrink-0"
                >
                  Fechar
                </button>
              </div>
            )}

            {/* Direct Real-Pool Wallet Card on Minerador */}
            <section className="rounded-xl bg-[#121821] border border-[#1E293B] p-4 sm:p-5 space-y-4">
              {!connected ? (
                <>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h2 className="text-base font-semibold text-slate-100">
                        Carteira para Ganhos Reais (Pool Zpool · Hardware CPU)
                      </h2>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Escolha a moeda (BTC, LTC, SUGAR, ADVC, VRSC, DASH ou BCH) e cole sua carteira para receber os pagamentos reais do pool.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setPoolsInitialSubTab('unmineable');
                        setTab('pools');
                      }}
                      className="text-xs text-sky-400 hover:text-sky-300 inline-flex items-center gap-1 shrink-0 self-start sm:self-center"
                    >
                      <span>XMR, TRX, TON ou USDT</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                    <div className="sm:col-span-3">
                      <label className="text-xs text-slate-400 block mb-1.5" htmlFor="home-coin">
                        Moeda
                      </label>
                      <select
                        id="home-coin"
                        value={zCoin}
                        onChange={(e) => {
                          setZCoin(e.target.value as ZpoolCoinSpec['code']);
                          setZWallet(null);
                          setZError(null);
                        }}
                        className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm text-slate-100"
                      >
                        {ZPOOL_COINS.map((c) => (
                          <option key={c.code} value={c.code}>
                            {c.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-6">
                      <label className="text-xs text-slate-400 block mb-1.5" htmlFor="home-wallet">
                        Endereço da Sua Carteira ({zCoin})
                      </label>
                      <input
                        ref={walletInputRef}
                        id="home-wallet"
                        type="text"
                        value={zAddress}
                        onChange={(e) => {
                          setZAddress(e.target.value);
                          if (zError) setZError(null);
                        }}
                        placeholder={selectedZpoolCoin.placeholder}
                        className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm font-mono text-slate-100"
                      />
                    </div>

                    <div className="sm:col-span-3 flex items-end">
                      <button
                        type="button"
                        disabled={connecting}
                        onClick={connectZpoolAndMine}
                        className="w-full min-h-[44px] px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        <Plug className="w-4 h-4" />
                        <span>{connecting ? 'Conectando...' : 'Conectar e Minerar'}</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                    <span>{selectedZpoolCoin.note}</span>
                    {!isMining && (
                      <button
                        type="button"
                        onClick={() => startMining()}
                        className="text-slate-400 hover:text-slate-200 underline shrink-0"
                      >
                        Testar hardware offline (sem carteira)
                      </button>
                    )}
                  </div>

                  {reconnecting && (
                    <div className="text-xs text-amber-200 bg-amber-950/30 border border-amber-500/40 rounded-lg p-3 flex items-center justify-between gap-3">
                      <span>Conexão oscilou — reconectando automaticamente ao pool (só encerra se você clicar em parar)...</span>
                      <button
                        type="button"
                        onClick={disconnectStratum}
                        className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-semibold shrink-0"
                      >
                        Desconectar
                      </button>
                    </div>
                  )}

                  {(zError || poolError) && (
                    <p className="text-xs text-rose-400 bg-rose-950/30 border border-rose-500/30 rounded-lg p-3">
                      {zError ?? poolError}
                    </p>
                  )}
                </>
              ) : (
                <div className="space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`inline-flex items-center gap-1.5 text-xs font-semibold ${
                            reconnecting ? 'text-amber-300' : 'text-emerald-400'
                          }`}
                        >
                          <span
                            className={`w-2 h-2 rounded-full animate-pulse ${
                              reconnecting ? 'bg-amber-400' : 'bg-emerald-400'
                            }`}
                          />
                          {reconnecting
                            ? `Reconectando Zpool (${zCoin})...`
                            : `Minerando Real na Zpool (${zCoin})`}
                        </span>
                        <span className="text-xs font-mono text-slate-400">
                          {stratumHost}:{stratumPort} · {authorized ? 'Autorizado' : subscribed ? 'Subscrito' : 'Conectando'}
                          {neverDisconnect ? ' · Contínuo' : ''}
                        </span>
                      </div>
                      <p className="text-xs font-mono text-slate-300 break-all">
                        Carteira: {stratumWorker}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <button
                        type="button"
                        disabled={zLoading}
                        onClick={() => void checkZpoolWallet()}
                        className="min-h-[40px] px-3 py-1.5 rounded-lg bg-[#1A222E] hover:bg-[#232D3D] border border-[#283344] text-xs font-medium text-slate-200 flex items-center gap-1.5 disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${zLoading ? 'animate-spin' : ''}`} />
                        <span>Atualizar Saldo</span>
                      </button>
                      <button
                        type="button"
                        onClick={disconnectStratum}
                        className="min-h-[40px] px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white flex items-center gap-1.5"
                      >
                        <Unplug className="w-3.5 h-3.5" />
                        <span>Desconectar</span>
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 rounded-lg bg-[#0B0F14] border border-[#1E293B] p-3 text-xs font-mono tabular-nums">
                    <div>
                      <span className="text-slate-400 block">Shares Aceitos</span>
                      <span className="text-emerald-400 font-semibold">{acceptedCount} aceitos</span>
                      <span className="text-slate-500 text-[11px] block">
                        {acceptedCount + rejectedCount > 0
                          ? `${Math.round((acceptedCount / (acceptedCount + rejectedCount)) * 100)}% aceitação · ${rejectedCount} rej.`
                          : simdActive
                            ? `SIMD v128 · ${threads * cacheMbPerThread} MB Cache`
                            : wasmActive
                              ? 'Motor WASM 64-bit'
                              : 'Motor JS'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Não Pago (Zpool)</span>
                      <span className="text-slate-100 font-semibold">
                        {zWallet ? `${zWallet.unpaid.toFixed(8)} ${zWallet.currency || zCoin}` : `0.00000000 ${zCoin}`}
                      </span>
                      <span className="text-slate-500 text-[11px] block">
                        Saque mín: {selectedZpoolCoin.minPayout}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Confirmado / Pago</span>
                      <span className="text-slate-100 font-semibold">
                        {zWallet ? `${zWallet.balance.toFixed(8)}` : '0.00000000'}
                      </span>
                      <span className="text-slate-500 text-[11px] block">
                        Total: {zWallet ? zWallet.total.toFixed(8) : '0.00000000'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Estimativa / 24h</span>
                      <span className="text-emerald-300 font-semibold">
                        {estDailyBrl > 0 ? `~R$ ${estDailyBrl.toFixed(4)}` : 'Calculando...'}
                      </span>
                      <span className="text-slate-500 text-[11px] block">
                        {estDailyUsd > 0 ? `~$${estDailyUsd.toFixed(5)} USD` : `Diff ${stratumJob?.difficulty ?? '—'}`}
                      </span>
                    </div>
                  </div>

                  {(() => {
                    const earned = (zWallet?.balance ?? 0) + (zWallet?.unpaid ?? 0);
                    const pct = Math.min(100, (earned / selectedZpoolCoin.minPayoutNum) * 100);
                    return (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] font-mono text-slate-400 tabular-nums">
                          <span>Progresso até saque automático ({selectedZpoolCoin.minPayout})</span>
                          <span className="text-emerald-400">{pct.toFixed(2)}%</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-[#0B0F14] border border-[#1E293B] overflow-hidden">
                          <div
                            className="h-full bg-emerald-500 transition-all duration-500"
                            style={{ width: `${Math.max(earned > 0 ? 2 : 0, pct)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </section>

            {/* 4-Column KPI Strip */}
            <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="rounded-xl bg-[#121821] border border-[#1E293B] p-4 sm:p-5">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Taxa de Hash Real</span>
                  {isMining && (
                    <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      Ativo
                    </span>
                  )}
                </div>
                <p className="text-2xl sm:text-3xl font-mono font-semibold text-slate-100 mt-2 tabular-nums">
                  {formatHashrate(hashrate)}
                </p>
                <p className="text-xs text-slate-400 mt-1 font-mono tabular-nums">
                  {totalHashes.toLocaleString('pt-BR')} hashes · {threads} thread(s)
                  {isMining && simdActive && useRamCache
                    ? ` · ${threads * cacheMbPerThread} MB Cache${memoryGuardActive ? ' (Auto-OOM)' : ''}`
                    : ''}
                </p>
              </div>

              <div className="rounded-xl bg-[#121821] border border-[#1E293B] p-4 sm:p-5">
                <span className="text-xs text-slate-400 block">Eficiência Energética</span>
                <p className="text-2xl sm:text-3xl font-mono font-semibold text-emerald-400 mt-2 tabular-nums">
                  {isMining ? `${Math.round(efficiencyHpW).toLocaleString('pt-BR')} H/W` : '0 H/W'}
                </p>
                <p className="text-xs text-slate-400 mt-1 font-mono tabular-nums">
                  {estWatts.toFixed(2)} W est. · {effectiveDutyCycle}% duty{thermalCooling ? ' (resfriando)' : ''}
                </p>
              </div>

              <div className="rounded-xl bg-[#121821] border border-[#1E293B] p-4 sm:p-5">
                <span className="text-xs text-slate-400 block">Shares Encontrados</span>
                <p className="text-2xl sm:text-3xl font-mono font-semibold text-slate-100 mt-2 tabular-nums">
                  {proofs.length}
                </p>
                <p className="text-xs text-slate-400 mt-1 font-mono tabular-nums">
                  {connected ? `Aceitos: ${acceptedCount} · ${stratumHost}` : `Alvo local: ${localDiff} bits`}
                </p>
              </div>

              <div className="rounded-xl bg-[#121821] border border-[#1E293B] p-4 sm:p-5">
                <span className="text-xs text-slate-400 block">Sessão & Bateria</span>
                <p className="text-2xl sm:text-3xl font-mono font-semibold text-slate-100 mt-2 tabular-nums">
                  {formatClock(elapsedSec)}
                </p>
                <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                  {isCharging ? (
                    <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Battery className="w-3.5 h-3.5 text-amber-400" />
                  )}
                  <span className="font-mono tabular-nums">
                    {batteryLevel !== null ? `${batteryLevel}%` : 'AC / Monitor'}
                  </span>
                </p>
              </div>
            </section>

            {/* 2-Column Split */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
              <div className="lg:col-span-7 rounded-xl bg-[#121821] border border-[#1E293B] p-5 flex flex-col justify-between">
                <div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                    <div>
                      <h2 className="text-base font-semibold text-slate-100">Telemetria em Tempo Real</h2>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {spec.name} · {connected ? `Stratum (${stratumHost})` : `Bloco local #${blockHeight}`}
                      </p>
                    </div>
                    <span className="text-xs font-mono text-slate-400 tabular-nums">Job {jobId}</span>
                  </div>
                  <HashChart samples={samples} active={isMining} />
                </div>

                <div className="mt-4 pt-4 border-t border-[#1E293B] space-y-2">
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>Cabeçalho PoW (80 bytes)</span>
                    <span className="font-mono tabular-nums">
                      {connected && stratumJob
                        ? `Diff ${stratumJob.difficulty} (~${difficultyToZeroBits(stratumJob.difficulty, algorithm)} bits)`
                        : `≥ ${localDiff} bits zero`}
                    </span>
                  </div>
                  <p className="text-[11px] font-mono text-slate-300 bg-[#0B0F14] border border-[#1E293B] rounded-lg p-2.5 break-all">
                    {headerHex}
                  </p>
                </div>
              </div>

              <div className="lg:col-span-5 rounded-xl bg-[#121821] border border-[#1E293B] p-5 space-y-5">
                <div>
                  <h2 className="text-base font-semibold text-slate-100">Controle Térmico e Energia</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Ajuste o ciclo de trabalho para preservar a bateria e evitar aquecimento no Android.
                  </p>
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-2" htmlFor="algo-sel">
                    Algoritmo
                  </label>
                  <select
                    id="algo-sel"
                    value={algorithm}
                    onChange={(e) => handleSelectAlgorithm(e.target.value as MiningAlgorithm)}
                    className="w-full min-h-[44px] px-3 rounded-lg bg-[#0B0F14] border border-[#243041] text-sm text-slate-100"
                  >
                    <option value="yespower_advc">Yespower-ADVC (CPU Real → LTC/DASH/ADVC)</option>
                    <option value="yespower_sugar">Yespower-SUGAR (Sugarchain CPU Real)</option>
                    <option value="yespower_arm">Yespower 1.0 Genérico (Stratum v1)</option>
                    <option value="blake3_eco">BLAKE3-Eco (Benchmark Local)</option>
                    <option value="sha256d">SHA-256d Midstate (ASIC / unMineable)</option>
                  </select>
                </div>

                <div>
                  <span className="text-xs text-slate-400 block mb-2">Perfil</span>
                  <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#0B0F14] rounded-lg border border-[#1E293B]">
                    {(['eco', 'balanced', 'max'] as const).map((id) => (
                      <button
                        key={id}
                        type="button"
                        onClick={() => handleSelectPower(id)}
                        className={`min-h-[40px] px-2 rounded-md text-xs font-medium transition-colors ${
                          powerProfile === id
                            ? 'bg-[#1C2532] text-emerald-300 border border-emerald-500/30'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {POWER_PROFILES[id].label}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-slate-400 mt-1.5">{POWER_PROFILES[powerProfile].note}</p>
                  {thermalCooling && (
                    <p className="text-xs text-amber-300 bg-amber-950/30 border border-amber-500/30 rounded-lg px-3 py-2 mt-2">
                      Proteção anti-aquecimento ativa: duty-cycle reduzido temporariamente para {effectiveDutyCycle}% para resfriar o processador.
                    </p>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      handleSelectPower('eco');
                      setAutoThermalGuard(true);
                      setAmoledMode(true);
                    }}
                    className="mt-2.5 w-full min-h-[40px] px-3 py-2 rounded-lg bg-[#0B0F14] hover:bg-[#161E29] border border-emerald-500/30 text-xs font-medium text-emerald-300 flex items-center justify-center gap-2"
                  >
                    <Moon className="w-3.5 h-3.5" />
                    <span>Ativar Modo Frio (Eco + Tela Preta AMOLED)</span>
                  </button>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <label htmlFor="threads-sl" className="text-slate-400">
                      Threads
                    </label>
                    <span className="font-mono text-slate-200 tabular-nums">
                      {threads} / {hw.cores}
                    </span>
                  </div>
                  <input
                    id="threads-sl"
                    type="range"
                    min={1}
                    max={hw.cores}
                    value={threads}
                    onChange={(e) => {
                      setThreads(Number(e.target.value));
                      if (isMining) {
                        stopWorkers();
                        setIsMining(false);
                      }
                    }}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <label htmlFor="duty-sl" className="text-slate-400">
                      Duty-Cycle
                    </label>
                    <span className="font-mono text-slate-200 tabular-nums">{dutyCycle}%</span>
                  </div>
                  <input
                    id="duty-sl"
                    type="range"
                    min={20}
                    max={100}
                    step={5}
                    value={dutyCycle}
                    onChange={(e) => setDutyCycle(Number(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                {!connected && (
                  <div>
                    <div className="flex justify-between text-xs mb-1.5">
                      <label htmlFor="diff-sl" className="text-slate-400">
                        Dificuldade Local
                      </label>
                      <span className="font-mono text-slate-200 tabular-nums">{localDiff} bits</span>
                    </div>
                    <input
                      id="diff-sl"
                      type="range"
                      min={4}
                      max={24}
                      value={localDiff}
                      onChange={(e) => setLocalDiff(Number(e.target.value))}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>
                )}

                <div className="pt-2 border-t border-[#1E293B] space-y-2 text-xs">
                  <label className="flex items-center justify-between gap-2 cursor-pointer min-h-[34px]">
                    <span className="text-slate-300">
                      Cache RAM Dinâmico + SIMD ({cacheMbPerThread} MB/thread{memoryGuardActive ? ' · Auto-OOM' : ''})
                    </span>
                    <input
                      type="checkbox"
                      checked={useRamCache}
                      onChange={(e) => setUseRamCache(e.target.checked)}
                      className="w-4 h-4 accent-emerald-500"
                    />
                  </label>
                  <label className="flex items-center justify-between gap-2 cursor-pointer min-h-[34px]">
                    <span className="text-slate-300">Nunca desconectar (reconexão contínua)</span>
                    <input
                      type="checkbox"
                      checked={neverDisconnect}
                      onChange={(e) => setNeverDisconnect(e.target.checked)}
                      className="w-4 h-4 accent-emerald-500"
                    />
                  </label>
                  <label className="flex items-center justify-between gap-2 cursor-pointer min-h-[34px]">
                    <span className="text-slate-300">Anti-aquecimento automático (throttling)</span>
                    <input
                      type="checkbox"
                      checked={autoThermalGuard}
                      onChange={(e) => setAutoThermalGuard(e.target.checked)}
                      className="w-4 h-4 accent-emerald-500"
                    />
                  </label>
                  <label className="flex items-center justify-between gap-2 cursor-pointer min-h-[34px]">
                    <span className="text-slate-300">Pausar com bateria abaixo de 25%</span>
                    <input
                      type="checkbox"
                      checked={pauseLowBat}
                      onChange={(e) => setPauseLowBat(e.target.checked)}
                      className="w-4 h-4 accent-emerald-500"
                    />
                  </label>
                  <label className="flex items-center justify-between gap-2 cursor-pointer min-h-[34px]">
                    <span className="text-slate-300">Manter tela ativa (Wake Lock)</span>
                    <input
                      type="checkbox"
                      checked={keepAwake}
                      onChange={(e) => setKeepAwake(e.target.checked)}
                      className="w-4 h-4 accent-emerald-500"
                    />
                  </label>
                </div>
              </div>
            </section>

            {/* Proofs Table */}
            <section className="rounded-xl bg-[#121821] border border-[#1E293B] overflow-hidden">
              <div className="p-5 border-b border-[#1E293B] flex items-center justify-between">
                <div>
                  <h2 className="text-base font-semibold text-slate-100">Provas e Shares Encontrados</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Nonces reais calculados pelos Web Workers e auditáveis criptograficamente.
                  </p>
                </div>
                {proofs.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setProofs([])}
                    className="text-xs text-slate-400 hover:text-slate-200"
                  >
                    Limpar
                  </button>
                )}
              </div>

              {proofs.length === 0 ? (
                <div className="p-8 text-center space-y-3">
                  <p className="text-sm text-slate-400">
                    {isMining && connected
                      ? `Minerando blocos reais (${stratumJob ? `diff ${stratumJob.difficulty}` : 'Yespower 1.0'}) com ${threads} thread(s)... O primeiro share costuma ser encontrado em 10 a 30 segundos.`
                      : 'Nenhum share encontrado ainda.'}
                  </p>
                  {!isMining && (
                    <button
                      type="button"
                      onClick={handlePrimaryMineClick}
                      className="min-h-[44px] px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold inline-flex items-center gap-2"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Iniciar Mineração Real</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-[#1E293B] text-[11px] text-slate-400 font-medium">
                        <th className="py-3 px-4">Hora</th>
                        <th className="py-3 px-4">Algoritmo</th>
                        <th className="py-3 px-4">Job</th>
                        <th className="py-3 px-4">Nonce</th>
                        <th className="py-3 px-4">Digest</th>
                        <th className="py-3 px-4 text-right">Zeros</th>
                        <th className="py-3 px-4 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1A222E] text-xs font-mono tabular-nums">
                      {proofs.map((row) => (
                        <tr key={row.id} className="hover:bg-[#161E29] h-11">
                          <td className="py-2.5 px-4 text-slate-400 whitespace-nowrap">{row.time}</td>
                          <td className="py-2.5 px-4 text-slate-200 font-sans whitespace-nowrap">
                            {ALGORITHM_SPECS[row.algorithm].shortName}
                          </td>
                          <td className="py-2.5 px-4 text-slate-400 whitespace-nowrap">{row.jobId}</td>
                          <td className="py-2.5 px-4 text-emerald-400 whitespace-nowrap">0x{row.nonceHex}</td>
                          <td className="py-2.5 px-4 text-slate-300 max-w-[240px] truncate">{row.digestHex}</td>
                          <td className="py-2.5 px-4 text-right text-slate-200 whitespace-nowrap">{row.zeroBits} b</td>
                          <td className="py-2.5 px-4 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-2">
                              <span
                                className={`font-sans font-medium ${
                                  row.status === 'accepted'
                                    ? 'text-emerald-400'
                                    : row.status === 'rejected'
                                      ? 'text-rose-400'
                                      : 'text-slate-300'
                                }`}
                              >
                                {row.status === 'accepted'
                                  ? 'Aceito'
                                  : row.status === 'rejected'
                                    ? 'Rejeitado'
                                    : row.status === 'submitted'
                                      ? 'Enviado'
                                      : 'Válido'}
                              </span>
                              {ALGORITHM_SPECS[row.algorithm].stratumReady &&
                                (row.verified ? (
                                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => verifyProof(row)}
                                    className="font-sans text-[11px] text-sky-400 underline"
                                  >
                                    Auditar
                                  </button>
                                ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          </>
        )}

        {tab === 'pools' && (
          <PoolsPanel
            host={stratumHost}
            port={stratumPort}
            worker={stratumWorker}
            password={stratumPass}
            onChangeHost={setStratumHost}
            onChangePort={setStratumPort}
            onChangeWorker={setStratumWorker}
            onChangePassword={setStratumPass}
            connected={connected}
            connecting={connecting}
            subscribed={subscribed}
            authorized={authorized}
            isMining={isMining}
            hashrate={hashrate}
            totalHashes={totalHashes}
            acceptedCount={acceptedCount}
            rejectedCount={rejectedCount}
            poolError={poolError}
            activeJob={stratumJob}
            logs={poolLogs}
            onConnect={connectStratum}
            onDisconnect={disconnectStratum}
            onOpenMiner={() => setTab('miner')}
            activeAlgorithm={algorithm}
            onSelectAlgorithm={handleSelectAlgorithm}
            zCoin={zCoin}
            zAddress={zAddress}
            onChangeZCoin={(c) => {
              setZCoin(c);
              setZWallet(null);
              setZError(null);
            }}
            onChangeZAddress={(a) => {
              setZAddress(a);
              if (zError) setZError(null);
            }}
            zWallet={zWallet}
            zLoading={zLoading}
            zError={zError}
            onCheckZpoolWallet={() => void checkZpoolWallet()}
            onConnectZpool={connectZpoolAndMine}
            prices={prices}
            initialSubTab={poolsInitialSubTab}
          />
        )}

        {tab === 'algorithms' && (
          <AlgorithmsPanel
            activeAlgorithm={algorithm}
            onSelectAlgorithm={(a) => {
              handleSelectAlgorithm(a);
              setTab('miner');
            }}
            threads={threads}
            dutyCycle={dutyCycle}
            isMining={isMining}
          />
        )}

        {tab === 'android' && <AndroidExportPanel />}

        {tab === 'drive' && (
          <GoogleDrivePanel
            currentBackup={currentDriveBackup}
            onRestoreBackup={handleRestoreDriveBackup}
          />
        )}
      </main>

      {/* Mobile Bottom Tab Bar */}
      <nav
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0B0F14]/95 backdrop-blur-md border-t border-[#1E293B] pb-safe"
        aria-label="Navegação mobile"
      >
        <div className="grid grid-cols-5 h-16">
          {(
            [
              { id: 'miner', label: 'Minerador', icon: Cpu },
              { id: 'pools', label: 'Pools', icon: Wallet },
              { id: 'algorithms', label: 'Algoritmos', icon: Gauge },
              { id: 'android', label: 'Android', icon: Smartphone },
              { id: 'drive', label: 'Drive', icon: HardDrive },
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`min-h-[44px] flex flex-col items-center justify-center gap-1 ${
                  tab === item.id ? 'text-emerald-400' : 'text-slate-400'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* AMOLED Dark Mode Overlay */}
      {amoledMode && (
        <div
          className="fixed inset-0 z-50 bg-black text-slate-300 flex flex-col items-center justify-between p-6"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md flex items-center justify-between pt-4">
            <span className="text-xs text-slate-500">Modo AMOLED Econômico</span>
            <button
              type="button"
              onClick={() => setAmoledMode(false)}
              className="min-h-[44px] px-3 py-2 rounded-lg border border-slate-800 text-xs flex items-center gap-1.5"
            >
              <X className="w-4 h-4" />
              <span>Sair</span>
            </button>
          </div>
          <div className="text-center space-y-3">
            <p className="text-xs text-slate-500">{spec.name}</p>
            <p className="text-4xl font-mono font-semibold text-emerald-400 tabular-nums">
              {formatHashrate(hashrate)}
            </p>
            <p className="text-xs font-mono text-slate-400 tabular-nums">
              Shares: {proofs.length} · {formatClock(elapsedSec)}
            </p>
          </div>
          <p className="text-xs text-slate-600 text-center max-w-xs pb-6">
            Pixels pretos economizam bateria em telas OLED/AMOLED durante a mineração.
          </p>
        </div>
      )}
    </div>
  );
}
