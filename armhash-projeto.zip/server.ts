import express from 'express';
import http from 'node:http';
import net from 'node:net';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';
import { YESPOWER_PERS, YespowerWorkspace, countLeadingZeroBitsLE } from './src/lib/yespower.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

interface StratumJob {
  jobId: string;
  prevhash: string;
  coinb1: string;
  coinb2: string;
  merkleBranch: string[];
  version: string;
  nbits: string;
  ntime: string;
  cleanJobs: boolean;
  extranonce2: string;
  headerHex: string;
  difficulty: number;
  receivedAt: number;
}

interface StratumSession {
  id: string;
  host: string;
  port: number;
  worker: string;
  password: string;
  socket: net.Socket;
  extranonce1: string;
  extranonce2Size: number;
  extranonce2Counter: number;
  difficulty: number;
  authorized: boolean;
  authResolved: boolean;
  authError: string | null;
  subscribed: boolean;
  reconnecting: boolean;
  closedByUser: boolean;
  reconnectAttempt: number;
  reconnectTimer: NodeJS.Timeout | null;
  buffer: string;
  msgId: number;
  pendingSubmits: Map<number, { jobId: string; nonceHex: string; submittedAt: number }>;
  clients: Set<express.Response>;
  lastJob: StratumJob | null;
}

const sessions = new Map<string, StratumSession>();

let cachedPrices: {
  fetchedAt: number;
  data: Record<string, { usd: number; brl: number }>;
} | null = null;

function doubleSha256(buf: Buffer): Buffer {
  const first = crypto.createHash('sha256').update(buf).digest();
  return crypto.createHash('sha256').update(first).digest();
}

function swapEndian32(hex: string): string {
  const clean = hex.padStart(8, '0');
  let out = '';
  for (let i = 0; i < clean.length; i += 8) {
    const word = clean.slice(i, i + 8);
    out += word.slice(6, 8) + word.slice(4, 6) + word.slice(2, 4) + word.slice(0, 2);
  }
  return out;
}

function reverseBytesHex(hex: string): string {
  const clean = hex.length % 2 === 0 ? hex : '0' + hex;
  let out = '';
  for (let i = clean.length - 2; i >= 0; i -= 2) {
    out += clean.slice(i, i + 2);
  }
  return out;
}

function buildStratumHeader(session: StratumSession, params: unknown[]): StratumJob {
  const jobId = String(params[0] ?? '');
  const prevhash = String(params[1] ?? '');
  const coinb1 = String(params[2] ?? '');
  const coinb2 = String(params[3] ?? '');
  const merkleBranch = Array.isArray(params[4]) ? params[4].map(String) : [];
  const version = String(params[5] ?? '20000000');
  const nbits = String(params[6] ?? '1d00ffff');
  const ntime = String(params[7] ?? '');
  const cleanJobs = Boolean(params[8]);

  session.extranonce2Counter = (session.extranonce2Counter + 1) >>> 0;
  const en2Bytes = Math.max(1, Math.min(8, session.extranonce2Size || 4));
  const extranonce2 = session.extranonce2Counter
    .toString(16)
    .padStart(en2Bytes * 2, '0')
    .slice(-(en2Bytes * 2));

  const coinbaseHex = coinb1 + session.extranonce1 + extranonce2 + coinb2;
  let merkleRoot = doubleSha256(Buffer.from(coinbaseHex, 'hex'));

  for (const branchHex of merkleBranch) {
    const branchBuf = Buffer.from(branchHex, 'hex');
    merkleRoot = doubleSha256(Buffer.concat([merkleRoot, branchBuf]));
  }

  const versionLE = reverseBytesHex(version.padStart(8, '0'));
  const prevhashLE = swapEndian32(prevhash.padStart(64, '0'));
  const merkleRootLE = merkleRoot.toString('hex');
  const ntimeLE = reverseBytesHex(ntime.padStart(8, '0'));
  const nbitsLE = reverseBytesHex(nbits.padStart(8, '0'));
  const nonceLE = '00000000';

  const headerHex = (
    versionLE +
    prevhashLE +
    merkleRootLE +
    ntimeLE +
    nbitsLE +
    nonceLE
  ).slice(0, 160);

  return {
    jobId,
    prevhash,
    coinb1,
    coinb2,
    merkleBranch,
    version,
    nbits,
    ntime,
    cleanJobs,
    extranonce2,
    headerHex,
    difficulty: session.difficulty,
    receivedAt: Date.now(),
  };
}

function broadcastEvent(session: StratumSession, event: string, payload: unknown) {
  const data = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of session.clients) {
    try {
      res.write(data);
    } catch {
      session.clients.delete(res);
    }
  }
}

function closeSession(sessionId: string, reason = 'Desconectado') {
  const session = sessions.get(sessionId);
  if (!session) return;
  session.closedByUser = true;
  if (session.reconnectTimer) {
    clearTimeout(session.reconnectTimer);
    session.reconnectTimer = null;
  }
  broadcastEvent(session, 'status', { connected: false, reconnecting: false, reason });
  for (const res of session.clients) {
    try {
      res.end();
    } catch {
      // ignore
    }
  }
  session.clients.clear();
  try {
    session.socket.destroy();
  } catch {
    // ignore
  }
  sessions.delete(sessionId);
}

function attachStratumSocket(
  session: StratumSession,
  initial?: {
    onReady: () => void;
    onInitialError: (message: string, status: number) => void;
  }
) {
  if (session.closedByUser) return;
  if (session.reconnectTimer) {
    clearTimeout(session.reconnectTimer);
    session.reconnectTimer = null;
  }

  const socket = new net.Socket();
  session.socket = socket;
  session.buffer = '';
  session.subscribed = false;
  session.authorized = false;
  session.authResolved = false;
  session.authError = null;
  socket.setTimeout(15000);

  let settled = !initial;
  let reconnectScheduled = false;

  const scheduleServerReconnect = (reason: string) => {
    if (session.closedByUser || !sessions.has(session.id) || reconnectScheduled) return;
    reconnectScheduled = true;
    session.reconnecting = true;
    session.reconnectAttempt += 1;
    const delayMs = Math.min(15000, 2000 * session.reconnectAttempt);
    broadcastEvent(session, 'status', {
      connected: true,
      reconnecting: true,
      subscribed: false,
      authorized: false,
      reason: `${reason} Reconectando TCP em ${Math.round(delayMs / 1000)}s...`,
    });
    session.reconnectTimer = setTimeout(() => {
      session.reconnectTimer = null;
      attachStratumSocket(session);
    }, delayMs);
  };

  const connectTimer = setTimeout(() => {
    if (!settled) {
      settled = true;
      closeSession(session.id, 'Tempo limite de conexão TCP esgotado');
      initial?.onInitialError(`Tempo limite esgotado ao conectar em ${session.host}:${session.port}.`, 504);
    } else {
      try {
        socket.destroy();
      } catch {
        // ignore
      }
      scheduleServerReconnect('Tempo limite TCP com o pool.');
    }
  }, 10000);

  socket.connect(session.port, session.host, () => {
    clearTimeout(connectTimer);
    socket.setTimeout(0);
    socket.setKeepAlive(true, 15_000);
    socket.setNoDelay(true);
    session.reconnecting = false;
    session.reconnectAttempt = 0;

    socket.write(JSON.stringify({ id: 1, method: 'mining.subscribe', params: ['ARMHash/2.0'] }) + '\n');
    socket.write(
      JSON.stringify({ id: 2, method: 'mining.authorize', params: [session.worker, session.password] }) + '\n'
    );

    if (!settled) {
      settled = true;
      initial?.onReady();
    } else {
      broadcastEvent(session, 'status', {
        connected: true,
        reconnecting: false,
        subscribed: false,
        authorized: false,
        reason: 'Socket TCP Stratum reconectado.',
      });
    }
  });

  socket.on('data', (chunk) => {
    session.buffer += chunk.toString('utf8');
    let newlineIdx = session.buffer.indexOf('\n');
    while (newlineIdx !== -1) {
      const line = session.buffer.slice(0, newlineIdx).trim();
      session.buffer = session.buffer.slice(newlineIdx + 1);
      newlineIdx = session.buffer.indexOf('\n');
      if (!line) continue;

      try {
        const msg = JSON.parse(line);

        if (msg.id === 1 && Array.isArray(msg.result)) {
          session.subscribed = true;
          session.extranonce1 = String(msg.result[1] ?? '00000000');
          session.extranonce2Size = Number(msg.result[2] ?? 4);
          broadcastEvent(session, 'status', {
            connected: true,
            reconnecting: false,
            subscribed: true,
            authorized: session.authorized,
            authResolved: session.authResolved,
            authError: session.authError,
            extranonce1: session.extranonce1,
          });
        } else if (msg.id === 2) {
          session.authResolved = true;
          session.authorized = Boolean(msg.result);
          session.authError = msg.error ? String(JSON.stringify(msg.error)) : null;
          broadcastEvent(session, 'status', {
            connected: true,
            reconnecting: false,
            subscribed: session.subscribed,
            authorized: session.authorized,
            authResolved: true,
            authError: session.authError,
          });
        } else if (typeof msg.id === 'number' && session.pendingSubmits.has(msg.id)) {
          const meta = session.pendingSubmits.get(msg.id)!;
          session.pendingSubmits.delete(msg.id);
          broadcastEvent(session, 'share_result', {
            jobId: meta.jobId,
            nonceHex: meta.nonceHex,
            accepted: Boolean(msg.result),
            error: msg.error ? String(JSON.stringify(msg.error)) : null,
            latencyMs: Date.now() - meta.submittedAt,
          });
        } else if (msg.method === 'mining.set_difficulty' && Array.isArray(msg.params)) {
          const diff = Number(msg.params[0]);
          if (Number.isFinite(diff) && diff > 0) {
            session.difficulty = diff;
            if (session.lastJob) {
              session.lastJob.difficulty = diff;
            }
            broadcastEvent(session, 'difficulty', { difficulty: diff });
          }
        } else if (msg.method === 'mining.notify' && Array.isArray(msg.params)) {
          const job = buildStratumHeader(session, msg.params);
          session.lastJob = job;
          broadcastEvent(session, 'job', job);
        }
      } catch {
        // ignore malformed pool line
      }
    }
  });

  socket.on('error', (err) => {
    clearTimeout(connectTimer);
    if (!settled) {
      settled = true;
      sessions.delete(session.id);
      initial?.onInitialError(`Falha TCP Stratum: ${err.message}`, 502);
    } else {
      scheduleServerReconnect(`Erro TCP (${err.message}).`);
    }
  });

  socket.on('close', () => {
    clearTimeout(connectTimer);
    if (!settled) {
      settled = true;
      sessions.delete(session.id);
      initial?.onInitialError('Conexão recusada pelo pool antes do handshake.', 502);
    } else if (!session.closedByUser && sessions.has(session.id)) {
      scheduleServerReconnect('Conexão interrompida pelo pool.');
    }
  });
}

function isBlockedHost(host: string): boolean {
  const normalized = host.trim().toLowerCase();
  if (!normalized || /[\s/\\@?#]/.test(normalized)) return true;
  if (normalized === '169.254.169.254' || normalized.startsWith('169.254.')) return true;
  if (normalized === 'metadata.google.internal') return true;
  return false;
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '256kb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, activeStratumSessions: sessions.size });
  });

  app.get('/api/market-prices', async (_req, res) => {
    const now = Date.now();
    if (cachedPrices && now - cachedPrices.fetchedAt < 60_000) {
      res.json(cachedPrices.data);
      return;
    }
    try {
      const resp = await fetch(
        'https://api.coingecko.com/api/v3/simple/price?ids=verus-coin,bitcoin,litecoin,monero,tron,the-open-network,tether,dogecoin,dash,solana&vs_currencies=usd,brl',
        { signal: AbortSignal.timeout(6000) }
      );
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      cachedPrices = { fetchedAt: now, data };
      res.json(data);
    } catch (err) {
      if (cachedPrices) {
        res.json(cachedPrices.data);
        return;
      }
      res.status(502).json({ error: `Falha ao buscar cotações: ${(err as Error).message}` });
    }
  });

  app.get('/api/pool/verus-stats', async (_req, res) => {
    try {
      const resp = await fetch('https://luckpool.net/verus/stats', {
        signal: AbortSignal.timeout(6000),
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      res.json({
        hashrateString: data?.poolStats?.hashrateString ?? '—',
        minerCount: Number(data?.poolStats?.minerCount ?? 0),
        workerCount: Number(data?.poolStats?.workerCount ?? 0),
        estimatedLuck: data?.poolStats?.estimatedLuck ?? '—',
        blockReward: Number(data?.coinStats?.blockReward ?? 6),
      });
    } catch (err) {
      res.status(502).json({ error: `Luckpool indisponível: ${(err as Error).message}` });
    }
  });

  app.get('/api/pool/verus-miner/:address', async (req, res) => {
    const address = String(req.params.address ?? '').trim();
    if (!address || !/^[a-zA-Z0-9]{20,64}$/.test(address)) {
      res.status(400).json({ error: 'Endereço Verus (R...) inválido.' });
      return;
    }
    try {
      const resp = await fetch(
        `https://luckpool.net/verus/miner/${encodeURIComponent(address)}`,
        { signal: AbortSignal.timeout(6000) }
      );
      const data = await resp.json();
      if (!resp.ok || data?.error) {
        res.status(404).json({ error: 'Endereço ainda sem shares registrados no Luckpool.' });
        return;
      }
      res.json(data);
    } catch (err) {
      res.status(502).json({ error: `Erro ao consultar Luckpool: ${(err as Error).message}` });
    }
  });

  app.get('/api/pool/unmineable/:coin/:address', async (req, res) => {
    const coin = String(req.params.coin ?? '').trim().toUpperCase();
    const rawAddr = String(req.params.address ?? '').trim();
    const address = rawAddr.toUpperCase().startsWith(`${coin}:`)
      ? rawAddr.slice(coin.length + 1)
      : rawAddr;

    if (!/^[A-Z0-9]{2,10}$/.test(coin) || !/^[a-zA-Z0-9._:-]{16,128}$/.test(address)) {
      res.status(400).json({ error: 'Moeda ou endereço de carteira inválido.' });
      return;
    }
    try {
      const addrResp = await fetch(
        `https://api.unmineable.com/v4/address/${encodeURIComponent(address)}?coin=${encodeURIComponent(coin)}`,
        { signal: AbortSignal.timeout(6000) }
      );
      const addrJson = await addrResp.json();
      if (!addrJson?.success || !addrJson?.data) {
        res.status(404).json({
          error: addrJson?.msg
            ? `unMineable: ${addrJson.msg}`
            : `Endereço não reconhecido para ${coin} no unMineable.`,
        });
        return;
      }

      const addrData = addrJson.data;
      let statsData: Record<string, unknown> | null = null;
      if (addrData.uuid) {
        try {
          const statsResp = await fetch(
            `https://api.unmineable.com/v4/account/${encodeURIComponent(String(addrData.uuid))}/stats`,
            { signal: AbortSignal.timeout(5000) }
          );
          const statsJson = await statsResp.json();
          if (statsJson?.success && statsJson?.data) {
            statsData = statsJson.data as Record<string, unknown>;
          }
        } catch {
          // fallback to addrData
        }
      }

      const rewarded = (statsData?.rewarded as Record<string, unknown> | undefined) ?? {};
      res.json({
        balance: String(statsData?.balance ?? addrData.balance ?? '0'),
        balance_payable: String(addrData.balance_payable ?? '0'),
        payment_threshold: String(statsData?.payment_threshold ?? addrData.payment_threshold ?? '—'),
        network: String(addrData.network ?? statsData?.network ?? ''),
        paid: String(statsData?.paid ?? '0'),
        past_24h: String(rewarded.past_24h ?? '0'),
        fresh: Boolean(addrData.fresh),
        uuid: addrData.uuid ? String(addrData.uuid) : null,
      });
    } catch (err) {
      res.status(502).json({ error: `Erro ao consultar unMineable: ${(err as Error).message}` });
    }
  });

  app.get('/api/pool/zpool-status', async (_req, res) => {
    try {
      const resp = await fetch('https://www.zpool.ca/api/status', {
        signal: AbortSignal.timeout(6000),
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      res.json({
        yespowerADVC: data?.yespowerADVC ?? null,
        yespowerSUGAR: data?.yespowerSUGAR ?? null,
        yespower: data?.yespower ?? null,
      });
    } catch (err) {
      res.status(502).json({ error: `Zpool indisponível: ${(err as Error).message}` });
    }
  });

  app.get('/api/pool/zpool-wallet/:address', async (req, res) => {
    const address = String(req.params.address ?? '').trim();
    if (!address || !/^[a-zA-Z0-9:]{18,120}$/.test(address)) {
      res.status(400).json({ error: 'Endereço de carteira inválido.' });
      return;
    }
    try {
      const resp = await fetch(
        `https://www.zpool.ca/api/wallet?address=${encodeURIComponent(address)}`,
        { signal: AbortSignal.timeout(6000) }
      );
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      res.json({
        currency: data?.currency ?? '',
        unpaid: Number(data?.unpaid ?? 0),
        balance: Number(data?.balance ?? 0),
        total: Number(data?.total ?? 0),
        paid24h: Number(data?.paid24h ?? 0),
        hasActivity: Boolean(data && Object.keys(data).length > 0),
      });
    } catch (err) {
      res.status(502).json({ error: `Erro ao consultar Zpool: ${(err as Error).message}` });
    }
  });

  const serverYespowerWs = new YespowerWorkspace();

  app.post('/api/verify-pow', (req, res) => {
    const { headerHex, nonce, algorithm } = req.body ?? {};
    if (typeof headerHex !== 'string' || typeof nonce !== 'number') {
      res.status(400).json({ error: 'Parâmetros inválidos.' });
      return;
    }

    if (algorithm === 'sha256d') {
      try {
        const buf = Buffer.from(headerHex.padEnd(160, '0').slice(0, 160), 'hex');
        buf.writeUInt32LE(nonce >>> 0, 76);
        const hash = doubleSha256(buf);
        const digestHex = Buffer.from(hash).reverse().toString('hex');
        let leadingZeroBits = 0;
        for (let i = 0; i < digestHex.length; i++) {
          const nibble = parseInt(digestHex[i], 16);
          if (nibble === 0) {
            leadingZeroBits += 4;
          } else {
            leadingZeroBits += Math.clz32(nibble) - 28;
            break;
          }
        }
        res.json({ verified: true, digestHex, leadingZeroBits });
        return;
      } catch {
        res.status(400).json({ error: 'Header hexadecimal inválido.' });
        return;
      }
    }

    if (algorithm === 'yespower_advc' || algorithm === 'yespower_sugar' || algorithm === 'yespower_arm') {
      try {
        const buf = Buffer.from(headerHex.padEnd(160, '0').slice(0, 160), 'hex');
        buf.writeUInt32LE(nonce >>> 0, 76);
        const pers =
          algorithm === 'yespower_sugar'
            ? YESPOWER_PERS.SUGAR
            : algorithm === 'yespower_advc'
              ? YESPOWER_PERS.ADVC
              : null;
        const out = serverYespowerWs.hash(buf, { version: 10, N: 2048, r: 32, pers });
        const digestHex = Buffer.from(out).reverse().toString('hex');
        const leadingZeroBits = countLeadingZeroBitsLE(out);
        res.json({ verified: true, digestHex, leadingZeroBits });
        return;
      } catch {
        res.status(400).json({ error: 'Header hexadecimal inválido.' });
        return;
      }
    }

    res.json({ verified: true });
  });

  app.post('/api/stratum/connect', (req, res) => {
    const { host, port, worker, password } = req.body ?? {};
    let cleanHost = typeof host === 'string' ? host.trim() : '';
    cleanHost = cleanHost.replace(/^(stratum\+tcp|stratum\+ssl|stratum|tcp):\/\//i, '').replace(/\/+$/, '');
    let parsedPort = Number(port);
    if (cleanHost.includes(':') && !cleanHost.startsWith('[')) {
      const [hPart, pPart] = cleanHost.split(':');
      if (hPart && pPart && /^\d+$/.test(pPart)) {
        cleanHost = hPart.trim();
        if (!Number.isInteger(parsedPort) || parsedPort <= 0) {
          parsedPort = Number(pPart);
        }
      }
    }
    const cleanWorker = typeof worker === 'string' ? worker.trim() : '';
    const cleanPass = typeof password === 'string' && password.length > 0 ? password : 'x';

    if (!cleanHost || isBlockedHost(cleanHost)) {
      res.status(400).json({ error: 'Host Stratum inválido ou não permitido.' });
      return;
    }
    if (!Number.isInteger(parsedPort) || parsedPort < 1 || parsedPort > 65535) {
      res.status(400).json({ error: 'Porta TCP inválida (1–65535).' });
      return;
    }
    if (!cleanWorker || cleanWorker.length > 180) {
      res.status(400).json({ error: 'Informe um endereço de carteira ou worker válido.' });
      return;
    }

    if (sessions.size >= 64) {
      const oldestKey = sessions.keys().next().value;
      if (oldestKey) closeSession(oldestKey, 'Limite de sessões atingido');
    }

    const sessionId = crypto.randomUUID();
    const session: StratumSession = {
      id: sessionId,
      host: cleanHost,
      port: parsedPort,
      worker: cleanWorker,
      password: cleanPass,
      socket: new net.Socket(),
      extranonce1: '00000000',
      extranonce2Size: 4,
      extranonce2Counter: 0,
      difficulty: 1,
      authorized: false,
      authResolved: false,
      authError: null,
      subscribed: false,
      reconnecting: false,
      closedByUser: false,
      reconnectAttempt: 0,
      reconnectTimer: null,
      buffer: '',
      msgId: 3,
      pendingSubmits: new Map(),
      clients: new Set(),
      lastJob: null,
    };

    sessions.set(sessionId, session);
    attachStratumSocket(session, {
      onReady: () => {
        res.json({ sessionId, host: cleanHost, port: parsedPort, worker: cleanWorker });
      },
      onInitialError: (message, status) => {
        if (!res.headersSent) {
          res.status(status).json({ error: message });
        }
      },
    });
  });

  app.get('/api/stratum/ping', (req, res) => {
    const sessionId = String(req.query.sessionId ?? '');
    const session = sessions.get(sessionId);
    res.json({
      ok: true,
      active: Boolean(session && !session.closedByUser),
      reconnecting: Boolean(session?.reconnecting),
      subscribed: Boolean(session?.subscribed),
      authorized: Boolean(session?.authorized),
    });
  });

  app.get('/api/stratum/stream', (req, res) => {
    const sessionId = String(req.query.sessionId ?? '');
    const session = sessions.get(sessionId);
    if (!session || session.closedByUser) {
      res.status(404).json({ error: 'Sessão Stratum não encontrada.' });
      return;
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();

    session.clients.add(res);
    res.write(
      `event: status\ndata: ${JSON.stringify({
        connected: true,
        reconnecting: session.reconnecting,
        subscribed: session.subscribed,
        authorized: session.authorized,
        authResolved: session.authResolved,
        authError: session.authError,
        difficulty: session.difficulty,
      })}\n\n`
    );

    if (session.lastJob) {
      res.write(`event: job\ndata: ${JSON.stringify(session.lastJob)}\n\n`);
    }

    const keepalive = setInterval(() => {
      try {
        res.write(': keepalive\n\n');
      } catch {
        clearInterval(keepalive);
      }
    }, 15_000);

    req.on('close', () => {
      clearInterval(keepalive);
      session.clients.delete(res);
    });
  });

  app.post('/api/stratum/submit', (req, res) => {
    const { sessionId, jobId, extranonce2, ntime, nonceHex } = req.body ?? {};
    const session = sessions.get(String(sessionId ?? ''));
    if (!session || session.closedByUser) {
      res.status(404).json({ error: 'Sessão Stratum inativa.' });
      return;
    }
    if (session.reconnecting || session.socket.destroyed || !session.socket.writable) {
      res.status(503).json({ error: 'Reconectando TCP ao pool, aguarde...' });
      return;
    }

    const id = session.msgId++;
    session.pendingSubmits.set(id, {
      jobId: String(jobId ?? ''),
      nonceHex: String(nonceHex ?? ''),
      submittedAt: Date.now(),
    });

    const payload =
      JSON.stringify({
        id,
        method: 'mining.submit',
        params: [
          session.worker,
          String(jobId ?? ''),
          String(extranonce2 ?? '00000000'),
          String(ntime ?? ''),
          String(nonceHex ?? '00000000'),
        ],
      }) + '\n';

    session.socket.write(payload);
    res.json({ submitted: true, id });
  });

  app.post('/api/stratum/disconnect', (req, res) => {
    const { sessionId } = req.body ?? {};
    closeSession(String(sessionId ?? ''), 'Encerrado pelo usuário');
    res.json({ disconnected: true });
  });

  app.get('/api/export/zip', async (_req, res) => {
    try {
      const zip = new JSZip();
      const allowRootFiles = [
        'package.json',
        'tsconfig.json',
        'vite.config.ts',
        'index.html',
        'metadata.json',
        'server.ts',
        'render.yaml',
        '.env.example',
        'firebase-applet-config.json',
      ];

      for (const rel of allowRootFiles) {
        const abs = path.join(__dirname, rel);
        if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
          zip.file(rel, fs.readFileSync(abs));
        }
      }

      const addDir = (relDir: string) => {
        const absDir = path.join(__dirname, relDir);
        if (!fs.existsSync(absDir)) return;
        for (const entry of fs.readdirSync(absDir, { withFileTypes: true })) {
          if (entry.name.startsWith('.')) continue;
          const relPath = path.posix.join(relDir.replace(/\\/g, '/'), entry.name);
          if (relPath === 'public/assets/aistudio' || relPath.startsWith('public/assets/aistudio/')) {
            continue;
          }
          const fullPath = path.join(absDir, entry.name);
          if (entry.isDirectory()) {
            addDir(relPath);
          } else if (entry.isFile()) {
            zip.file(relPath, fs.readFileSync(fullPath));
          }
        }
      };

      addDir('src');
      addDir('public');

      zip.file(
        'README-TERMUX.txt',
        [
          'ARMHash — Como rodar no Termux (Android) ou em hospedagem Node.js',
          '',
          '1) No Termux (Android):',
          '   pkg update -y && pkg install -y nodejs-lts termux-api',
          '   npm install',
          '   npm run build',
          '   termux-wake-lock',
          '   NODE_ENV=production npx tsx server.ts',
          '   Depois abra http://localhost:3000 no Chrome e toque em Menu -> Instalar aplicativo.',
          '',
          '2) Render / Koyeb / Cloud Run:',
          '   Build: npm install && npm run build',
          '   Start: npm start (com NODE_ENV=production; PORT e lida automaticamente)',
          '',
        ].join('\n')
      );

      const archive = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="armhash-projeto.zip"');
      res.setHeader('Content-Length', String(archive.length));
      res.send(archive);
    } catch (err) {
      res.status(500).json({ error: `Falha ao gerar ZIP: ${(err as Error).message}` });
    }
  });

  const httpServer = http.createServer(app);

  const distDir = path.resolve(__dirname, 'dist');
  let servedViaVite = false;

  if (process.env.NODE_ENV !== 'production') {
    try {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: {
          middlewareMode: true,
          ws: { server: httpServer },
          hmr: process.env.DISABLE_HMR === 'true' ? false : { server: httpServer },
        },
        plugins: [
          {
            name: 'express-hmr-attach',
            config() {
              return {
                server: {
                  ws: { server: httpServer },
                  hmr: process.env.DISABLE_HMR === 'true' ? false : { server: httpServer },
                },
              };
            },
          },
        ],
        appType: 'spa',
      });
      app.use(vite.middlewares);
      servedViaVite = true;
    } catch {
      if (!fs.existsSync(path.join(distDir, 'index.html'))) {
        throw new Error('Vite não disponível e pasta dist/ não encontrada. Execute "npm run build".');
      }
    }
  }

  if (!servedViaVite) {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`ARMHash server listening on http://0.0.0.0:${PORT}`);
  });

  const shutdown = () => {
    for (const sid of [...sessions.keys()]) {
      closeSession(sid, 'Servidor encerrado');
    }
    httpServer.close(() => {
      process.exit(0);
    });
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

startServer();
